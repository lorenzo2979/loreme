#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

for file in kroko-server libonnxruntime.so italian.data websocket.whl; do
    if [[ ! -e "runtime/$file" ]]; then
        echo 'Esegui prima bash prepara.sh.' >&2
        exit 1
    fi
done

namespace=(unshare --net)
if (( EUID != 0 )); then
    namespace+=(--user --map-root-user)
fi
exec "${namespace[@]}" bash -eu -c '
    ip link set lo up
    export LD_LIBRARY_PATH="$PWD/runtime"
    export PYTHONPATH="$PWD/runtime/websocket.whl"
    runtime/kroko-server --model="$PWD/runtime/italian.data" --port=16006 \
        --num-threads=2 --num-work-threads=1 --warm-up=0 --log-file="$PWD/runtime/kroko.log" \
        > runtime/server.log 2>&1 &
    server_pid=$!
    trap '\''kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true'\'' EXIT
    for attempt in {1..240}; do
        if grep -q "Listening on" runtime/server.log; then
            python3 prova.py "$server_pid"
            exit
        fi
        kill -0 "$server_pid" 2>/dev/null || break
        sleep .25
    done
    cat runtime/server.log >&2
    exit 1
'
