"""Replay one reference clip at microphone speed and print the result."""

from array import array
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import sys
import time
import wave

from websocket import create_connection


RATE = 16000
CHUNK = 1600
REFERENCE = "La religione predominante in Moldavia è quella cristiano-ortodossa."


def receive(socket):
    results = []
    while True:
        message = socket.recv()
        if message == "Done!":
            return results
        if not message:
            raise RuntimeError("Kroko ha chiuso la connessione prima della fine.")
        record = json.loads(message)
        if record.get("type") == "final" or record.get("is_final"):
            if record.get("text", "").strip():
                results.append((record["text"].strip(), time.monotonic()))


def main():
    with wave.open("campione.wav", "rb") as clip:
        if (clip.getframerate(), clip.getnchannels(), clip.getsampwidth()) != (RATE, 1, 2):
            raise ValueError("Il campione deve essere WAV PCM16 mono a 16 kHz.")
        pcm = clip.readframes(clip.getnframes())
    expected = "98fbd2bad12ee2b9ab7faf6a95c642c9561458efea39b2dd3d08b2f6d325e032"
    if hashlib.sha256(pcm).hexdigest() != expected:
        raise ValueError("Il campione WAV è diverso da quello del collaudo.")

    samples = array("h")
    samples.frombytes(pcm)
    if sys.byteorder != "little":
        samples.byteswap()

    socket = create_connection("ws://127.0.0.1:16006", timeout=45)
    try:
        with ThreadPoolExecutor(max_workers=1) as threads:
            pending = threads.submit(receive, socket)
            started = time.monotonic()
            for offset in range(0, len(samples), CHUNK):
                block = samples[offset:offset + CHUNK]
                scheduled = started + (offset + len(block)) / RATE
                time.sleep(max(0, scheduled - time.monotonic()))
                floats = array("f", (sample / 32768 for sample in block))
                if sys.byteorder != "little":
                    floats.byteswap()
                socket.send_binary(floats.tobytes())
            last_sample = time.monotonic()
            socket.send("Done")
            results = pending.result(timeout=60)
    finally:
        socket.close(timeout=1)

    if not results:
        raise RuntimeError("Kroko non ha restituito testo.")
    ram = next((line.split(":", 1)[1].strip()
                for line in Path(f"/proc/{sys.argv[1]}/status").read_text().splitlines()
                if line.startswith("VmHWM:")), "non disponibile")
    print("Riferimento:", REFERENCE)
    print("Kroko:", " ".join(text for text, _ in results))
    print("Durata audio:", round(len(samples) / RATE, 2), "s")
    print("Ultima risposta rispetto all'ultimo campione:",
          round((results[-1][1] - last_sample) * 1000), "ms")
    print("RAM di picco processo Kroko:", ram)
    print("Prova di trascrizione completata.")


if __name__ == "__main__":
    main()
