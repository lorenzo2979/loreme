#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

if [[ $(uname -m) != x86_64 ]] || [[ $(getconf LONG_BIT) != 64 ]]; then
    echo "Il pacchetto richiede DietPi x86-64 con userland a 64 bit." >&2
    exit 1
fi

for command in curl sha256sum unzip python3 unshare ip; do
    if ! command -v "$command" >/dev/null; then
        printf 'Comando richiesto assente: %s\n' "$command" >&2
        exit 1
    fi
done

mkdir -p runtime
verify() {
    printf '%s  %s\n' "$2" "$1" | sha256sum --check --status
}
fetch() {
    local target=$1 checksum=$2 url=$3
    if [[ -f "$target" ]] && verify "$target" "$checksum"; then
        return
    fi
    curl --fail --show-error --silent --location --retry 2 --connect-timeout 15 \
        --proto '=https' --output "$target.part" "$url"
    if ! verify "$target.part" "$checksum"; then
        printf 'SHA-256 diverso dal collaudo per %s. Preparazione interrotta.\n' "$target" >&2
        return 1
    fi
    mv -f -- "$target.part" "$target"
}

echo 'Scarico e verifico server, modello italiano e client.'
fetch runtime/kroko-server c2c878f97501f468d4cc06a0242486797acda558d8ce163ae3fa9b7c06acc3e9 \
    https://download.kroko.ai/binaries/kroko-onnx-online-websocket-server
fetch runtime/italian.data e74cd91f89970639476353cfb7ba5044da10e36d8fb99c3a7a41c8b7c253726d \
    https://huggingface.co/Banafo/Kroko-ASR/resolve/4ade228/Kroko-IT-Community-64-L-Streaming-001.data
fetch runtime/websocket.whl e1a673830a9c7bfa47b1cd3d5e4178f4c9651d80a4eab02c9c23a1c3ec6250ce \
    https://files.pythonhosted.org/packages/d5/d2/cc4dc1271e464942db7ee278baae2daa99ee77cb2af744025c04da585a3e/websocket_client-1.9.2-py3-none-any.whl

ort_hash=a34d8c226994dd4af2b2250442fc236ebba97aefc7ec451c35a86216588d2f69
if ! [[ -f runtime/libonnxruntime.so ]] || ! verify runtime/libonnxruntime.so "$ort_hash"; then
    jar=runtime/onnxruntime.jar.part
    curl --fail --show-error --silent --location --retry 2 --connect-timeout 15 \
        --proto '=https' --output "$jar" \
        https://repo.maven.apache.org/maven2/com/microsoft/onnxruntime/onnxruntime/1.17.1/onnxruntime-1.17.1.jar
    unzip -p "$jar" 'ai/onnxruntime/native/linux-x64/libonnxruntime.so' > runtime/libonnxruntime.so.part
    if ! verify runtime/libonnxruntime.so.part "$ort_hash"; then
        echo 'SHA-256 diverso dal collaudo per ONNX Runtime.' >&2
        exit 1
    fi
    mv -f -- runtime/libonnxruntime.so.part runtime/libonnxruntime.so
    rm -f -- "$jar"
fi
chmod u+x runtime/kroko-server
echo 'Preparazione completata. Avvio del collaudo con bash prova.sh.'
