#ifndef GWIR_SDK_AUTH_TASK_H
#define GWIR_SDK_AUTH_TASK_H
#include <stdint.h>
#include "../core/gwir_runtime_owner.h"

/* CP-33: One-shot FreeRTOS/lwIP authenticated listener lifecycle.
 * This function MUST be called only by a board-integrator AFTER trusted
 * key provisioning, an unpredictable fresh boot nonce and owner init.
 * It NEVER sources credentials, enables IR, mounts unknown flash, modifies
 * pinmux or starts automatically from vendor main. No fallback listener.
 * A verified STA-only network and explicit owner are prerequisites.
 * The task owns the initialized owner until it exits, then wipes sessions.
 * Owner and its I/O buffers MUST be statically allocated and must not be
 * reused or freed until the task exits. The caller must safely deliver the
 * nonce to its paired client out of band.
 */
int gwir_sdk_auth_task_start(gwir_runtime_owner *provisioned_owner, uint16_t port);
/* Request shutdown; the task closes its own socket and clears credentials.
 * Never frees owner storage from the caller. */
int gwir_sdk_auth_task_request_stop(void);
#endif
