/* CP33 host test: task lifecycle is fail-closed, never touches real hardware. */
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "../firmware/sdk/gwir_sdk_auth_task.h"
#include "../firmware/realtek/gwir_amebad_auth_server.h"
#include "task_stubs/ameba_soc.h"
#include "task_stubs/wifi/wifi_conf.h"
#include "task_stubs/lwip/netif.h"
#include "task_stubs/lwip_netconf.h"

rtw_mode_t wifi_mode = RTW_MODE_AP;
struct netif xnetif[1]={{1,1}};
static int associated=1, create_rc=pdPASS, created, erased, runs, deleted;
static void (*task_fn)(void *);
static unsigned task_stack;
static uint8_t ip[4]={192,168,2,23};
static gwir_amebad_auth_server_config witnessed;
int wifi_is_connected_to_ap(void){return associated?RTW_SUCCESS:-1;}
int netif_is_up(const struct netif *n){return n->up;}
int netif_is_link_up(const struct netif *n){return n->link;}
uint8_t *LwIP_GetIP(struct netif *n){(void)n;return ip;}
int xTaskCreate(void (*fn)(void *), const char *name, unsigned stack_depth,
                void *arg, unsigned priority, void *handle){
    (void)arg;(void)handle;
    assert(!strcmp(name,"GWIR-AUTH") && priority==1u);
    created++;task_stack=stack_depth;task_fn=fn;return create_rc;
}
void vTaskDelete(void *task){assert(task==NULL);deleted++;}
void gwir_runtime_owner_clear(gwir_runtime_owner *o){erased++;memset(o,0,sizeof(*o));}
int gwir_amebad_auth_server_run(const gwir_amebad_auth_server_config *c){
    assert(c && c->owner && c->owner->initialized);
    witnessed=*c;runs++;
    assert(c->port==32444u && c->check_sta(c->ctx,c->sta_ip_network_order)==1);
    wifi_mode=RTW_MODE_AP;
    assert(c->check_sta(c->ctx,c->sta_ip_network_order)==0);
    wifi_mode=RTW_MODE_STA;
    ip[3]++;
    assert(c->check_sta(c->ctx,c->sta_ip_network_order)==0);
    ip[3]--;
    assert(gwir_sdk_auth_task_request_stop()==0);
    assert(*c->stop==1);
    return -1;
}
int main(void){
    gwir_runtime_owner o={0};
    unsigned char fake[2]={1,2};
    assert(gwir_sdk_auth_task_request_stop()==-1);
    assert(gwir_sdk_auth_task_start(NULL,32444)==-1);
    assert(gwir_sdk_auth_task_start(&o,32444)==-1);
    assert(!created);
    o.initialized=o.rx.active=o.tx.active=1;
    o.engine=(gwir_engine *)fake;
    o.scratch=fake; o.signed_response=fake;
    assert(gwir_sdk_auth_task_start(&o,80)==-1);
    assert(gwir_sdk_auth_task_start(&o,32444)==-1); /* AP forbidden */
    wifi_mode=RTW_MODE_STA_AP;
    assert(gwir_sdk_auth_task_start(&o,32444)==-1); /* STA+AP forbidden */
    wifi_mode=RTW_MODE_STA;
    associated=0;assert(gwir_sdk_auth_task_start(&o,32444)==-1);
    associated=1; xnetif[0].link=0;
    assert(gwir_sdk_auth_task_start(&o,32444)==-1);
    xnetif[0].link=1;
    ip[0]=127;
    assert(gwir_sdk_auth_task_start(&o,32444)==-1); /* loopback forbidden */
    ip[0]=192;
    create_rc=0;
    assert(gwir_sdk_auth_task_start(&o,32444)==-2);
    assert(gwir_sdk_auth_task_request_stop()==-1);
    create_rc=pdPASS;
    assert(gwir_sdk_auth_task_start(&o,32444)==0 && created==2);
    assert(task_stack>=1024u);
    assert(gwir_sdk_auth_task_start(&o,32444)==-1); /* busy forbidden */
    task_fn(NULL);
    assert(runs==1 && erased==1 && deleted==1 && !o.initialized);
    assert(gwir_sdk_auth_task_request_stop()==-1);
    assert(gwir_sdk_auth_task_start(&o,32444)==-1); /* keys erased */
    assert(witnessed.owner==&o);
    puts("PASS CP33: real FreeRTOS task adapter lifecycle, STA-only IP, owner wipe, duplicate task denied (host stubs, NO FLASH)");
    return 0;
}
