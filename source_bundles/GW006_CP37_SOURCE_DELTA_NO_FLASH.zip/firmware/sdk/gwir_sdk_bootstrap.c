#include "gwir_sdk_bootstrap.h"
#include "gwir_sdk_auth_task.h"
#include "ameba_soc.h"

/* Only the GW006 board port can install configuration; NO implementation
 * of a platform secret source is linked into this generic module. */
static const gwir_sdk_boot_config *boot_config;
static unsigned boot_sealed;
static unsigned boot_scheduled;

/* Maximum wait after the scheduler starts: ~30 seconds. No retries that
 * could reuse a boot nonce after a partial authentication handshake. */
#define GWIR_BOOT_WAIT_ITERATIONS 120u
#define GWIR_BOOT_WAIT_MS 250u

int gwir_sdk_boot_register(const gwir_sdk_boot_config *c)
{
    if (boot_sealed || boot_config || !c || !c->provider ||
        !c->provider->trust_verified || !c->provider->load_key ||
        !c->provider->fresh_nonce || !c->provider->nonce_freshness_verified ||
        !c->provider->deliver_nonce || !c->owner || c->owner->initialized ||
        !c->engine || !c->hmac || !c->scratch || !c->response ||
        c->scratch_capacity < GWIR_MAX_MESSAGE ||
        c->response_capacity < GWIR_AUTH_MAX_PACKET ||
        c->port < 1024u)
        return -1;
    boot_config = c;
    return 0;
}

static void gwir_boot_task(void *unused)
{
    const gwir_sdk_boot_config *c = boot_config;
    unsigned i;
    (void)unused;
    for (i = 0; i < GWIR_BOOT_WAIT_ITERATIONS; ++i) {
        /* Check current STA mode + live association + IPv4; never rely on
         * wlan_network() having completed asynchronous association. */
        if (gwir_sdk_auth_network_ready() == 1)
            break;
        vTaskDelay((GWIR_BOOT_WAIT_MS + portTICK_PERIOD_MS - 1u) /
                   portTICK_PERIOD_MS);
    }
    if (i < GWIR_BOOT_WAIT_ITERATIONS && c) {
        /* On failure secure_start wipes local key/nonce and revokes owner.
         * The board port is responsible for any additional hardware state. */
        (void)gwir_sdk_secure_start(c->provider, c->owner, c->engine, c->saved,
                                    c->hmac, c->crypto_ctx, c->scratch,
                                    c->scratch_capacity, c->response,
                                    c->response_capacity, c->port);
    }
    vTaskDelete(NULL);
}

int gwir_sdk_boot_schedule(void)
{
    boot_sealed = 1u;
    if (!boot_config || boot_scheduled || portTICK_PERIOD_MS == 0u)
        return -1;
    /* A failure to register this task never activates any network server. */
    if (xTaskCreate(gwir_boot_task, "GWIR-BOOT", 1024u, NULL,
                    tskIDLE_PRIORITY + 1u, NULL) != pdPASS)
        return -2;
    boot_scheduled = 1u;
    return 0;
}
