#!/usr/bin/env python3
"""Host-only negative tests for CP-21 source-lock. No GitHub or hardware I/O."""
import importlib.util
import json
import shutil
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('source_gate', SRC/'scripts/verify_release_sources.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
manifest = json.loads((SRC/'docs/CP21_SOURCE_MANIFEST.json').read_text())
assert gate.verify(SRC, manifest)[1] == 40
print('PASS: CP35 release integrity, 40 C sources')

with tempfile.TemporaryDirectory(prefix='cp21_source_gate_') as temp:
    root = Path(temp)
    for file in manifest['files']:
        source = SRC/file['path']
        target = root/file['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    assert gate.verify(root, manifest)[0] == len(manifest['files'])
    testfile = root/'firmware/core/gwir_flash_journal.c'
    original = testfile.read_bytes()
    testfile.write_bytes(original + b'\n')
    try:
        gate.verify(root, manifest)
        raise AssertionError('Modified byte not detected')
    except ValueError as e:
        assert 'integrity mismatch' in str(e)
    testfile.write_bytes(original)

    testfile.unlink()
    try:
        gate.verify(root, manifest)
        raise AssertionError('Missing source not detected')
    except ValueError as e:
        assert 'missing=' in str(e)
    testfile.write_bytes(original)

    unknown = root/'firmware/core/unreviewed.c'
    unknown.write_text('int bad(void) {return 0;}')
    try:
        gate.verify(root, manifest)
        raise AssertionError('Unexpected source not detected')
    except ValueError as e:
        assert 'extra=' in str(e)
    unknown.unlink()

    clone = json.loads(json.dumps(manifest))
    clone['files'][1]['path'] = clone['files'][0]['path']
    try:
        gate.verify(root, clone)
        raise AssertionError('Duplicate path not detected')
    except ValueError as e:
        assert 'Unsorted or duplicate' in str(e)

    clone = json.loads(json.dumps(manifest))
    clone['files'][0]['path'] = '../etc/passwd'
    try:
        gate.verify(root, clone)
        raise AssertionError('Path traversal not detected')
    except ValueError:
        pass

    testfile.unlink()
    testfile.symlink_to(root/'firmware/core/gwir_engine.c')
    try:
        gate.verify(root, manifest)
        raise AssertionError('Symlink not detected')
    except ValueError as e:
        assert 'Symlink' in str(e)
    testfile.unlink()
    testfile.write_bytes(original)

    clone = json.loads(json.dumps(manifest))
    clone['files'][0]['sha256'] = 'z'*64
    try:
        gate.verify(root, clone)
        raise AssertionError('Malformed digest not detected')
    except ValueError as e:
        assert 'Invalid SHA-256' in str(e)

    assert gate.verify(root, manifest)[1] == 40
print('PASS: changed bytes, missing/extra C, duplicates, traversal, symlink, invalid hash; NO FLASH')
