#include "../firmware/realtek/gwir_amebad_board_pins.h"
#include <assert.h>
#include <stdio.h>
int main(void)
{
    gwir_board_pins p = gwir_board_pins_candidate();
    assert(gwir_board_pins_validate(&p) == 0);
    assert(gwir_board_pins_validate(NULL) < 0);
    assert(gwir_board_ir_enable_authorized() == 0);
    assert(p.ir_tx != p.red_led && p.ir_rx != p.blue_led);
    p.ir_tx = p.ap_button;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.ir_tx = p.red_led;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.ir_rx = p.blue_led;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.ap_button = p.ir_tx;
    assert(gwir_board_pins_validate(&p) < 0);
    puts("PASS GW006 board pinmap: PB31 TX / PA26 RX, preserve LED/button, fail-closed");
    return 0;
}
