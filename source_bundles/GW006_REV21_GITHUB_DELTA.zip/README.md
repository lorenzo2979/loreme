# GW006 IR Universal — REV21 APConfig TCP transport (offline)

**Source-only: nessuna installazione sul dispositivo.** Test reali su scheda ancora assenti.

REV21 aggiunge un trasporto callback-based limitato per una singola connessione APConfig. La rete AP effettiva, la verifica netif Realtek, DHCP, la memorizzazione Wi-Fi e il pinmux IR non sono implementati/abilitati. I test host, Kotlin, sanitizzatori, mock SDK e ARM compile-only risultano PASS, ma la REV21 non ha ancora una build SDK nativa.

**Dato nuovo importante:** il repository GitHub ha già eseguito con successo una build nativa KM0/KM4 con codice GW006 **REV16**: https://github.com/lorenzo2979/loreme/actions/runs/43073357001. Non confondere la sua riuscita con una certificazione hardware o REV21.

Consultare `docs/REV21_TCP_TRANSPORT_VERIFICATION.md`; preservare OpenBeken 1.18.321, non flashare.

# GW006 IR Universal — REV20 TCP APConfig connection gate

**SOURCE-ONLY, TESTED OFFLINE, NOT A GW006 FIRMWARE IMAGE.**

REV20 builds on the REV19 HTTP validator with a fixed-size per-connection TCP
framing adapter (max 1,536 bytes), split-read assembly, AP/session gate,
2-second idle/10-second total timeout, one-shot status/close, credential wipe,
and rollback handling. No real Realtek TCP listener, DHCP service, STA commit
backend or physical IR pinmux is activated. OpenBeken 1.18.321 is unchanged.

Verification: `make test test-sdk-integration test-web-assets test-kotlin
arm-smoke test-http-sanitized test-stream-sanitized` (host tests/mock SDK,
ARM object compile-only). See `docs/REV20_APCONFIG_HTTP_STREAM.md`.

# GW006 IR Universal — REV19 APConfig HTTP request gate

**SOURCE-ONLY, TESTED OFFLINE, NOT A GW006 FIRMWARE IMAGE.**

REV19 adds strict, allocation-free HTTP/1.1 parsing for the temporary OPEN APConfig network at `192.168.4.1`, with an active-session/AP-interface check and staged Wi-Fi rollback contract. Nothing listens on the network yet; the physical GW006 still runs OpenBeken 1.18.321. See `docs/REV19_APCONFIG_HTTP_GATE.md`.

Verified locally: host regression, SDK mock integration (25 objects), dashboard assets, Kotlin/JVM, ARM Cortex-M23/M33 compile-only, and 30,000 deterministic malformed HTTP inputs under ASan/UBSan. **No Realtek SDK-native REV19 build or hardware test.**

# GW006 IR Universal — REV18 GPIO pin policy, Wi-Fi profile, web dashboard preview

**This is an intermediate source release, NOT flash-ready for the WBRG1.**

- New board pin pair **PB31 → IR TX**, **PA26 → IR RX**. The user has electrically checked both available. Existing red/blue LEDs and APConfig button stay on **PA25/PB22/PB23**.
- The pinmap is checked in portable code and compiled in the vendor SDK. **No PinMux initialization** is enabled, and board IR remains fail-closed until actual 38-kHz TX/RX tests and safe recovery are established.
- Station Wi-Fi profile parser offers **DHCP default and static IPv4, mask, gateway, DNS** with bounds, validation and stage/verify/commit/rollback. The SDK network and nonvolatile implementation are not yet connected.
- `web/dashboard/index.html` is an **offline HTML demo** based on the ESP C3 purple/black interface. TV 36 / Clima 14 / Decoder 32 / Speaker 14 (96 buttons), 3-second long-press menus, Wi-Fi search design, DuckDNS and optional MQTT for Home Assistant only. **It cannot control hardware, store codes, or submit Wi-Fi settings yet**.
- User chose normal LAN command port **TCP 42424** with authenticated commands; this is a specification, not a running listener.
- APConfig SSID `GW006-IR-SETUP`, deliberately open **only for 5 minutes after 5-second physical button press**, no login; only SDK hotspot adapter and state logic developed, not live DHCP/HTTP.
- Maintain OpenBeken 1.18.321 on the original GW006 until image layout, backups, physical GPIO tests and recovery process are verified.

Run `make test test-sdk-integration test-web-assets test-kotlin arm-smoke` for portable checks. See `docs/REV18_BOARD_PINS_DASHBOARD.md`.

# GW006 IR Universal — REV16 Wi-Fi profile provisioning core

REV15 open APConfig has been published for native SDK build. REV16 adds
bounded form decoding and an atomic-profile **backend contract**. The
HTTP AP-only portal, DHCP, verified board pin, persistent storage and
live Wi-Fi association remain to be implemented and physically tested.

- APConfig: OPEN Wi-Fi, no password/login, hold PCB button for 5s, auto-close after 5min.
- STA: keep previous credentials until verification succeeds; never erase on a failed edit.
- Normal IR TCP: fixed port **42424**; HMAC auth, distinct from APConfig.
- DuckDNS: future Android settings integration; no enabled DDNS service here.
- No flash of GW006. Keep OpenBeken 1.18.321.

See docs/REV16_PROVISIONING_VALIDATION.md and CP-07 in GitHub.
