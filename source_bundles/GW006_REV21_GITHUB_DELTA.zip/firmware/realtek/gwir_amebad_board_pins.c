#include "ameba_soc.h"
#include "gwir_amebad_board_pins.h"
#include <stddef.h>

/* These macro IDs are provided by the *official* AmebaD SDK PinMux headers.
   Do not confuse WBRG1 module pad number 20 with PB31 numeric GPIO ID. */
gwir_board_pins gwir_board_pins_candidate(void)
{
    gwir_board_pins pins = {
        (uint8_t)_PB_31, (uint8_t)_PA_26,
        (uint8_t)_PB_23, (uint8_t)_PA_25, (uint8_t)_PB_22
    };
    return pins;
}

int gwir_board_pins_validate(const gwir_board_pins *p)
{
    if (p == NULL) return -1;
    if (p->ir_tx != _PB_31 || p->ir_rx != _PA_26) return -2;
    if (p->ap_button != _PB_23 || p->red_led != _PA_25 ||
        p->blue_led != _PB_22) return -3;
    if (p->ir_tx == p->ir_rx || p->ir_tx == p->ap_button ||
        p->ir_tx == p->red_led || p->ir_tx == p->blue_led ||
        p->ir_rx == p->ap_button || p->ir_rx == p->red_led ||
        p->ir_rx == p->blue_led) return -4;
    return 0;
}

int gwir_board_ir_enable_authorized(void)
{
    /* PB31 and PA26 are confirmed unoccupied by owner, but there is no
       physical 38-kHz/IRQ test, boot image validation or safe rollback yet. */
    return 0;
}
