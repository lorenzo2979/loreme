#ifndef GWIR_AMEBAD_BOARD_PINS_H
#define GWIR_AMEBAD_BOARD_PINS_H
#include <stdint.h>
/* GW006 user's unpowered continuity results, 2026-11-11.
   IR peripheral mapping per Realtek AN0400 Table 25-1.
   THIS MODULE NEVER INITIALIZES OR TOUCHES GPIO/PINMUX. */
typedef struct {
    uint8_t ir_tx, ir_rx;
    uint8_t ap_button;
    uint8_t red_led, blue_led;
} gwir_board_pins;

/* Exactly the proposed GW006 mapping, NOT a claim of operational IR hardware. */
gwir_board_pins gwir_board_pins_candidate(void);
/* Reject reserved collisions or unsupported arbitrary pin assignments. */
int gwir_board_pins_validate(const gwir_board_pins *pins);
/* No approved board activation: fail closed by design. */
int gwir_board_ir_enable_authorized(void);
#endif
