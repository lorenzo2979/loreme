/* CP32 real POSIX socketpair test. Test vectors only: NO board credentials. */
#define _POSIX_C_SOURCE 200809L
#include "gwir_amebad_auth_server.h"
#include <assert.h>
#include <arpa/inet.h>
#include <openssl/hmac.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static gwir_runtime_owner owner;
static gwir_engine engine;
static gwir_saved_play_service saved;
static gwir_fj_store store;
static uint8_t scratch[GWIR_MAX_MESSAGE];
static uint8_t reply[GWIR_AUTH_MAX_PACKET];
static uint32_t pulses[GWIR_MAX_PULSES_PER_FRAME];
static uint8_t key[32], nonce[16];
static int network_ok=1, transmissions=0, stopped=0;
static gwir_auth_session phone_tx,phone_rx;
static gwir_amebad_auth_server_config cfg;
static int fd_worker=-1, worker_result=999;

static int mac(void *ctx,const uint8_t *k,size_t kl,const uint8_t *data,
               size_t len,uint8_t out[32])
{
    unsigned int n=0;
    (void)ctx;
    return !HMAC(EVP_sha256(),k,(int)kl,data,len,out,&n) || n!=32u;
}
static int ir_denied(void *ctx) { (void)ctx; return 0; }
static int ir_send(void *ctx,uint32_t carrier,uint16_t duty,
                   const uint32_t *d,uint16_t count,uint32_t gap)
{
    (void)ctx;(void)carrier;(void)duty;(void)d;(void)count;(void)gap;
    transmissions++;
    return -1;
}
static int check_network(void *ctx,uint32_t ip)
{
    (void)ctx;
    return network_ok && ip == htonl(INADDR_LOOPBACK);
}
static void *service_thread(void *unused)
{
    (void)unused;
    worker_result=gwir_amebad_auth_handle_client(fd_worker,&cfg);
    close(fd_worker);
    return NULL;
}
static int send_all(int fd,const uint8_t *d,size_t n)
{
    size_t p=0;
    while(p<n) {
        ssize_t sent=send(fd,d+p,n-p,0);
        if(sent<=0)return -1;
        p+=(size_t)sent;
    }
    return 0;
}
static size_t signed_button(uint8_t *wire,uint32_t sequence,uint8_t button)
{
    uint8_t inner[GWIR_MAX_MESSAGE];
    size_t n=0,size=0;
    assert(gwir_encode(inner,sizeof(inner),GWIR_TX_SAVED,sequence,
                       &button,1,&n)==0);
    assert(gwir_auth_wrap(&phone_tx,GWIR_AUTH_TO_DEVICE,inner,n,
                          wire,GWIR_AUTH_MAX_PACKET,&size)==0);
    return size;
}
static size_t receive_record(int fd,uint8_t *out,size_t capacity)
{
    size_t size=0,need=GWIR_AUTH_HEADER_BYTES;
    while(size<need) {
        ssize_t n=recv(fd,out+size,need-size,0);
        if(n<=0)return 0;
        size+=(size_t)n;
        if(size==GWIR_AUTH_HEADER_BYTES) {
            need=GWIR_AUTH_HEADER_BYTES+gwir_read_u32be(out+32u)+GWIR_AUTH_TAG_BYTES;
            assert(need<=capacity);
        }
    }
    return size;
}
static void check_response(uint8_t *bytes,size_t n,uint32_t sequence)
{
    const uint8_t *inner=NULL;
    size_t inner_len=0;
    gwir_message msg;
    assert(gwir_auth_unwrap(&phone_rx,GWIR_AUTH_FROM_DEVICE,bytes,n,
                             &inner,&inner_len)==0);
    assert(gwir_decode(inner,inner_len,&msg)==0);
    assert(msg.command==GWIR_SAVED_STATUS && msg.sequence==sequence);
    assert(msg.payload_len==2 && msg.payload[0]==GWIR_NOT_READY);
}
int main(void)
{
    uint8_t wire[GWIR_AUTH_MAX_PACKET],response[GWIR_AUTH_MAX_PACKET];
    int fds[2];
    pthread_t tid;
    size_t len,got;
    gwir_ir_hal hal={0};
    gwir_fj_play_ops ir={NULL,ir_denied,ir_send};
    for(size_t i=0;i<sizeof(key);++i)key[i]=(uint8_t)(i+1u);
    for(size_t i=0;i<sizeof(nonce);++i)nonce[i]=(uint8_t)(i+19u);
    cfg.owner=&owner;
    cfg.sta_ip_network_order=htonl(INADDR_LOOPBACK);
    cfg.port=42424u;
    cfg.stop=&stopped;
    cfg.check_sta=check_network;
    assert(gwir_amebad_auth_server_run(&cfg)==-1); /* no key = no listen */
    gwir_engine_init(&engine,hal);
    assert(gwir_saved_play_init(&saved,&store,&ir,pulses,GWIR_MAX_PULSES_PER_FRAME)==0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,key,nonce,mac,NULL,
                       scratch,sizeof(scratch),reply,sizeof(reply))==0);
    assert(gwir_auth_init(&phone_tx,key,nonce,mac,NULL)==0);
    assert(gwir_auth_init(&phone_rx,key,nonce,mac,NULL)==0);
    network_ok=0;
    assert(gwir_amebad_auth_server_run(&cfg)==-1); /* STA invalid */
    network_ok=1;
    cfg.sta_ip_network_order=0;
    assert(gwir_amebad_auth_server_run(&cfg)==-1); /* NEVER wildcard */
    cfg.sta_ip_network_order=htonl(INADDR_LOOPBACK);
    assert(socketpair(AF_UNIX,SOCK_STREAM,0,fds)==0);
    fd_worker=fds[1];worker_result=999;
    assert(pthread_create(&tid,NULL,service_thread,NULL)==0);
    len=signed_button(wire,1,95);
    assert(send_all(fds[0],wire,len)==0);
    got=receive_record(fds[0],response,sizeof(response));
    assert(got>0);
    check_response(response,got,1);
    shutdown(fds[0],SHUT_WR);
    assert(pthread_join(tid,NULL)==0);
    assert(worker_result==0 && transmissions==0 && !owner.connected);
    close(fds[0]);
    /* Same authenticated counter across a fresh socket => rejected. */
    assert(socketpair(AF_UNIX,SOCK_STREAM,0,fds)==0);
    fd_worker=fds[1];worker_result=999;
    assert(pthread_create(&tid,NULL,service_thread,NULL)==0);
    assert(send_all(fds[0],wire,len)==0);
    shutdown(fds[0],SHUT_WR);
    assert(pthread_join(tid,NULL)==0);
    assert(worker_result==-1 && !owner.connected && transmissions==0);
    close(fds[0]);
    /* Remove STA authorization: do not accept or open authenticated session. */
    assert(socketpair(AF_UNIX,SOCK_STREAM,0,fds)==0);
    network_ok=0;
    assert(gwir_amebad_auth_handle_client(fds[1],&cfg)==-1);
    assert(!owner.connected);
    network_ok=1;
    close(fds[0]);close(fds[1]);
    /* An incomplete authenticated record is NOT a successful request. */
    assert(socketpair(AF_UNIX,SOCK_STREAM,0,fds)==0);
    fd_worker=fds[1];worker_result=999;
    assert(pthread_create(&tid,NULL,service_thread,NULL)==0);
    assert(send_all(fds[0],wire,1)==0);
    shutdown(fds[0],SHUT_WR);
    assert(pthread_join(tid,NULL)==0);
    assert(worker_result==-1 && !owner.connected && transmissions==0);
    close(fds[0]);
    stopped=1;
    assert(gwir_amebad_auth_server_run(&cfg)==-1);
    gwir_runtime_owner_clear(&owner);
    assert(transmissions==0);
    puts("PASS CP32: real socketpair, signed HMAC saved-button denial, replay across sessions, STA-only, no wildcard/no secrets");
    return 0;
}
