#!/usr/bin/env python3
"""CP25 fail-closed ARM ELF KM4 object gate tests using synthetic objects only."""
import json
import os
import shutil
import subprocess
from pathlib import Path
import struct
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from verify_native_km4_objects import inspect, arm_elf_relocatable, SDK_PROJECT, OBJECT_ROOT, VENDOR_C, VENDOR_MAKE


def expect_bad(fn, reason):
    try:
        fn()
    except ValueError as exc:
        assert reason in str(exc), (reason, str(exc))
    else:
        raise AssertionError('Expected failure: ' + reason)


def synthetic_elf_arm():
    """Minimal structurally valid ARM ELF32 ET_REL, NOT executable firmware."""
    header = bytearray(52)
    header[:16] = b'\x7fELF\x01\x01\x01' + b'\x00' * 9
    struct.pack_into('<HHIIIIIHHHHHH', header, 16,
                     1, 40, 1, 0, 0, 112, 0x05000000, 52, 0, 0, 40, 4, 0)
    payload = bytearray(header)
    payload += b'\x00\xbf\x00\xbf'  # 4 synthetic Thumb NOP bytes
    payload += b'\x00test_func\x00'  # string table
    payload += b'\x00' * 16 + struct.pack('<IIIBBH', 1, 0, 4, 0x12, 0, 1)  # a synthetic defined function symbol
    payload += b'\x00' * (112 - len(payload))
    assert len(payload) == 112
    sections = [
        (0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        (0, 1, 0x6, 0, 52, 4, 0, 0, 2, 0),
        (0, 3, 0, 0, 56, 11, 0, 0, 1, 0),
        (0, 2, 0, 0, 67, 32, 2, 0, 4, 16),
    ]
    for s in sections:
        payload += struct.pack('<IIIIIIIIII', *s)
    assert len(payload) == 112 + 4 * 40
    return bytes(payload)


manifest = json.loads((ROOT / 'docs/CP21_SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
sources = [x for x in manifest['files'] if x['path'].startswith('firmware/') and x['path'].endswith('.c')]
assert len(sources) == 35
with tempfile.TemporaryDirectory(prefix='gw006_cp25_km4_') as temp:
    sdk = Path(temp)
    makefile = sdk / VENDOR_MAKE
    makefile.parent.mkdir(parents=True)
    lines = []
    objects = []
    for rec in sources:
        _, grp, name = rec['path'].split('/')
        src = sdk / VENDOR_C / grp / name
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_bytes((ROOT / rec['path']).read_bytes())
        lines.append('CSRC += $(GWIR_DIR)/%s/%s' % (grp, name))
        objects.append(sdk / OBJECT_ROOT / Path(name).with_suffix('.o').name)
    makefile.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    marker = sdk / 'start-marker'
    marker.write_text('begin\n')
    assert inspect(sdk, 'preflight')['makefile_mappings_verified'] == 35
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'missing/unsafe')

    good = synthetic_elf_arm()
    for path in objects:
        path.write_bytes(good)
    old_ns = time.time_ns() - 5_000_000_000
    os.utime(marker, ns=(old_ns, old_ns))
    assert inspect(sdk, 'postbuild', marker)['native_objects_verified'] == 35

    original = objects[0].read_bytes()
    for payload, reason in [
        (b'', 'empty'),
        (b'garbage', 'invalid ELF size'),
        (b'0' * 272, 'not ELF'),
        (good[:4] + b'\x02' + good[5:], 'not 32-bit little-endian'),
        (good[:18] + b'\x03\x00' + good[20:], 'wrong machine'),
        (good[:16] + b'\x02\x00' + good[18:], 'not relocatable'),
        (good[:32] + b'\xff\xff\xff\xff' + good[36:], 'out-of-range section table'),
        (good[:60], 'out-of-range section table'),
    ]:
        objects[0].write_bytes(payload)
        expect_bad(lambda: inspect(sdk, 'postbuild', marker), reason)
    objects[0].write_bytes(original)

    # Remove the SHT_SYMTAB entry's type, then remove SHF_EXECINSTR from .text.
    corrupt = bytearray(good)
    struct.pack_into('<I', corrupt, 112 + 3 * 40 + 4, 0)
    objects[0].write_bytes(corrupt)
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'missing code or defined function symbol')
    corrupt = bytearray(good)
    struct.pack_into('<I', corrupt, 112 + 1 * 40 + 8, 0)
    objects[0].write_bytes(corrupt)
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'missing code or defined function symbol')
    corrupt = bytearray(good)
    # Turn the only function into an undefined reference.
    struct.pack_into('<H', corrupt, 67 + 16 + 14, 0)
    objects[0].write_bytes(corrupt)
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'missing code or defined function')
    corrupt = bytearray(good)
    struct.pack_into('<I', corrupt, 67 + 16, 1000)  # st_name exceeds .strtab
    objects[0].write_bytes(corrupt)
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'invalid symbol name')
    objects[0].write_bytes(original)

    os.utime(objects[0], ns=(old_ns - 1_000_000_000, old_ns - 1_000_000_000))
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'stale')
    os.utime(objects[0], ns=(time.time_ns(), time.time_ns()))
    objects[1].unlink()
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'missing/unsafe')
    objects[1].symlink_to(objects[0])
    expect_bad(lambda: inspect(sdk, 'postbuild', marker), 'missing/unsafe')
    objects[1].unlink()
    objects[1].write_bytes(original)
    src = sdk / VENDOR_C / sources[0]['path'].split('/')[1] / sources[0]['path'].split('/')[2]
    src.write_bytes(b'corrupted')
    expect_bad(lambda: inspect(sdk, 'preflight'), 'differs from locked')
    src.write_bytes((ROOT / sources[0]['path']).read_bytes())
    makefile.write_text('\n'.join(lines[1:]) + '\n', encoding='utf-8')
    expect_bad(lambda: inspect(sdk, 'preflight'), 'not registered exactly once')
    makefile.write_text('\n'.join(lines + [lines[0]]) + '\n', encoding='utf-8')
    expect_bad(lambda: inspect(sdk, 'preflight'), 'not registered exactly once')
    print('PASS CP25: 35 source hashes, 35 Makefile mappings, fresh ARM ELF32 objects; '
          'wrong ISA, ELF, symlink, stale, empty, tampered, stripped and duplicates refused; SYNTHETIC only; NO FLASH')

# A real compiler-produced object is useful to validate our parser, but is NOT
# evidence of a native vendor AmebaD build or of device compatibility.
if shutil.which('clang') and shutil.which('cc'):
    with tempfile.TemporaryDirectory(prefix='gw006_cp25_clang_') as temp:
        d = Path(temp)
        probe = d / 'probe.c'
        probe.write_text('int gwir_gate_probe(int n) { return n + 1; }\n', encoding='utf-8')
        arm = d / 'arm.o'
        subprocess.run(['clang', '--target=armv7m-none-eabi', '-mthumb',
                        '-c', str(probe), '-o', str(arm)], check=True, capture_output=True)
        arm_elf_relocatable(arm)
        host = d / 'host.o'
        subprocess.run(['cc', '-c', str(probe), '-o', str(host)], check=True, capture_output=True)
        try:
            arm_elf_relocatable(host)
        except ValueError:
            pass
        else:
            raise AssertionError('Host-architecture ELF incorrectly accepted as ARM')
    print('PASS CP25: actual Clang ARM32 object accepted, host compiler object rejected; no vendor SDK')
else:
    print('SKIP CP25 optional compiler probe: Clang or cc missing (synthetic gate tests passed)')
