#!/usr/bin/env python3
"""CP29 negative-evidence test suite; no board interaction or firmware build."""
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
script = ROOT / 'scripts/audit_runtime_readiness.py'
spec = importlib.util.spec_from_file_location('cp27_runtime_audit', script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

report = module.inspect(ROOT)
assert report['blocker_count'] >= 9
assert not report['ready_to_flash']
assert not report['ir_tx_rx_enabled']
assert not report['hardware_verified']
assert not report['realtek_native_km0_km4_proven']
assert any('vendor IR bus' in s for s in report['blockers'])
assert any('Board IR pin' in s for s in report['blockers'])
assert any('Wi-Fi station' in s for s in report['blockers'])

with tempfile.TemporaryDirectory(prefix='gwir_cp27_') as temp:
    t = Path(temp)
    for rel in module.FILES.values():
        dest = t / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((ROOT / rel).read_bytes())
    assert module.inspect(t)['ready_to_flash'] is False
    # The audit MUST NOT permit flashing even if source guards change.
    p = t / module.FILES['vendor_bus']
    p.write_text(p.read_text().replace('return 0;\n}', 'return 1;\n}', 1))
    altered = module.inspect(t)
    assert not altered['ready_to_flash']
    assert any('changed' in s for s in altered['blockers'])
    # Reject a symlink redirection outside the requested source tree.
    p.unlink()
    p.symlink_to(ROOT / module.FILES['vendor_bus'])
    try:
        module.inspect(t)
        raise AssertionError('symlink unexpectedly accepted')
    except ValueError as exc:
        assert 'symlink' in str(exc)

with tempfile.TemporaryDirectory(prefix='gwir_cp27_report_') as temp:
    out = Path(temp) / 'report.json'
    cmd = [sys.executable, str(script), '--root', str(ROOT), '--output', str(out)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert json.loads(out.read_text())['ready_to_flash'] is False
    result = subprocess.run(cmd + ['--require-ready'], capture_output=True, text=True)
    assert result.returncode == 3, result.stderr

print('PASS CP29: offline runtime blockers identified, source changes remain fail-closed, symlinks rejected, release gate blocks flash')
