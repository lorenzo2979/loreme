#include "../firmware/realtek/gwir_wbrg1_flash_port.h"
#include "flash_api.h"
#include "device_lock.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uint8_t *disk;
static int lock_state, read_fail, write_fail, erase_fail, corrupt_write;
static uint8_t capacity_id = 0x17;
uint32_t gwir_fj_worst_case_rewrite_bytes(void) { return 4378624u; }
int flash_read_id(flash_t *f, uint8_t *dst, uint8_t n) {
    (void)f;assert(lock_state==1); assert(n==3);
    dst[0]=0xEF;dst[1]=0x40;dst[2]=capacity_id;return 1;
}
void device_mutex_lock(int x){assert(x==RT_DEV_LOCK_FLASH);assert(lock_state==0);lock_state=1;}
void device_mutex_unlock(int x){assert(x==RT_DEV_LOCK_FLASH);assert(lock_state==1);lock_state=0;}
int flash_stream_read(flash_t *f,uint32_t off,uint32_t n,uint8_t *dst){
    (void)f;assert(lock_state==1);assert(off+n<=GWIR_WBRG1_FLASH_BYTES);
    if(read_fail) return 0;
    memcpy(dst,disk+off,n);return 1;
}
int flash_stream_write(flash_t *f,uint32_t off,uint32_t n,uint8_t *src){
    (void)f;assert(lock_state==1);assert(off>=GWIR_WBRG1_IR_START);
    assert(off+n<=GWIR_WBRG1_IR_START+GWIR_WBRG1_IR_BYTES);
    if(write_fail) return 0;
    for(uint32_t i=0;i<n;i++)disk[off+i]&=src[i];
    if(corrupt_write)disk[off]^=0x01;
    return 1;
}
void flash_erase_sector(flash_t *f,uint32_t off){
    (void)f;assert(lock_state==1); assert(off%GWIR_FJ_SECTOR==0);
    assert(off>=GWIR_WBRG1_IR_START);
    assert(off+GWIR_FJ_SECTOR<=GWIR_WBRG1_IR_START+GWIR_WBRG1_IR_BYTES);
    if(!erase_fail)memset(disk+off,0xFF,GWIR_FJ_SECTOR);
}
int main(void){
    gwir_fj_io io;
    assert(gwir_wbrg1_flash_port_attach(NULL)==-1);
#if GWIR_WBRG1_STORAGE_APPROVED == 0
    assert(gwir_wbrg1_flash_port_attach(&io)==-7);
    assert(io.read==NULL && io.program==NULL && io.erase_sector==NULL);
    puts("PASS WBRG1 port fail-closed: no flash access enabled in release");
#else
    disk=malloc(GWIR_WBRG1_FLASH_BYTES);assert(disk);
    memset(disk,0xFF,GWIR_WBRG1_FLASH_BYTES);
    disk[GWIR_WBRG1_IR_START-1]=0x6D;
    disk[GWIR_WBRG1_IR_START+GWIR_WBRG1_IR_BYTES]=0x3C;
    capacity_id=0x18;
    assert(gwir_wbrg1_flash_port_attach(&io)==-3);
    capacity_id=0x17;
    assert(gwir_wbrg1_flash_port_attach(&io)==0);
    assert(io.region_size==GWIR_WBRG1_IR_BYTES);
    uint8_t b[10]={0,1,2,3,4,5,6,7,8,9},out[10];
    assert(io.read(io.ctx,io.region_size-1,out,sizeof(out))==-1);
    assert(io.program(io.ctx,io.region_size-1,b,sizeof(b))==-1);
    assert(io.erase_sector(io.ctx,io.region_size-4095)==-1);
    assert(io.program(io.ctx,0,b,sizeof(b))==0);
    assert(io.read(io.ctx,0,out,sizeof(out))==0 && !memcmp(b,out,sizeof(b)));
    uint8_t one=0xFF;
    assert(io.program(io.ctx,0,&one,1)==-1); /* cannot flip zero to one */
    assert(io.erase_sector(io.ctx,0)==0);
    assert(io.read(io.ctx,0,out,sizeof(out))==0);
    for(int i=0;i<10;i++)assert(out[i]==0xFF);
    read_fail=1;assert(io.read(io.ctx,0,out,sizeof(out))==-1);read_fail=0;
    write_fail=1;assert(io.program(io.ctx,0,b,sizeof(b))==-1);write_fail=0;
    corrupt_write=1;assert(io.program(io.ctx,0,b,sizeof(b))==-1);corrupt_write=0;
    erase_fail=1;assert(io.erase_sector(io.ctx,0)==-1);erase_fail=0;
    assert(io.erase_sector(io.ctx,0)==0);
    assert(disk[GWIR_WBRG1_IR_START-1]==0x6D);
    assert(disk[GWIR_WBRG1_IR_START+GWIR_WBRG1_IR_BYTES]==0x3C);
    assert(lock_state==0);
    free(disk);
    puts("PASS WBRG1 port mock: JEDEC, 5MiB bounds, 1->0, readback, erase, failure paths");
#endif
    return 0;
}
