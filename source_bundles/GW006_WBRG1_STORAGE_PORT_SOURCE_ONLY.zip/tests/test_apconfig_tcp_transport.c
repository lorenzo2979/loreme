#include "gwir_apconfig_tcp_transport.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* Transport shim only: no real Realtek sockets, GPIO, AP, or flash writes. */
typedef struct {
    const uint8_t *request;
    size_t length, read_position, rx_chunk, tx_chunk, sent;
    char response[256];
    uint32_t now;
    int listening, trusted, accepting, close_calls, accept_calls, rx_calls;
    int after_rx_revoke, stop_session_after_rx, fail_send, fail_verify;
    int stage_calls, verify_calls, commit_calls, rollback_calls;
    gwir_apcfg_session *session;
} mock;

static int listener_on_ap(void *ctx) {return ((mock *)ctx)->listening;}
static int accept_one(void *ctx, uint32_t wait_ms)
{
    mock *m = ctx;
    assert(wait_ms <= GWIR_APTCP_ACCEPT_WAIT_MS);
    ++m->accept_calls;
    return m->accepting;
}
static int client_on_ap(void *ctx) {return ((mock *)ctx)->trusted;}
static int recv_some(void *ctx, uint8_t *dst, size_t cap, uint32_t wait_ms)
{
    mock *m = ctx;
    size_t count;
    assert(wait_ms <= GWIR_APTCP_IO_WAIT_MS && cap == GWIR_APTCP_READ_CAP);
    ++m->rx_calls;
    if (m->after_rx_revoke && m->rx_calls >= m->after_rx_revoke) m->trusted = 0;
    if (m->stop_session_after_rx && m->rx_calls >= m->stop_session_after_rx)
        m->session->provisioner_started = 0;
    if (m->read_position >= m->length) {
        m->now += wait_ms;
        return -2; /* bounded timeout */
    }
    count = m->length - m->read_position;
    if (m->rx_chunk && count > m->rx_chunk) count = m->rx_chunk;
    if (count > cap) count = cap;
    memcpy(dst, m->request + m->read_position, count);
    m->read_position += count;
    m->now += 1u;
    return (int)count;
}
static int send_some(void *ctx, const uint8_t *bytes, size_t n, uint32_t wait_ms)
{
    mock *m = ctx;
    assert(wait_ms <= GWIR_APTCP_IO_WAIT_MS);
    if (m->fail_send) return -1;
    if (m->tx_chunk && n > m->tx_chunk) n = m->tx_chunk;
    assert(n && m->sent + n < sizeof(m->response));
    memcpy(m->response + m->sent, bytes, n);
    m->sent += n;
    m->response[m->sent] = '\0';
    m->now += 1u;
    return (int)n;
}
static void close_client(void *ctx) {++((mock *)ctx)->close_calls;}
static uint32_t now_ms(void *ctx) {return ((mock *)ctx)->now;}
static int stage(void *ctx, const gwir_station_profile *p)
{
    mock *m = ctx;
    ++m->stage_calls;
    assert(strcmp(p->wifi.ssid,"My Router") == 0);
    assert(strcmp(p->wifi.password,"12345678") == 0);
    return 0;
}
static int verify(void *ctx)
{
    mock *m = ctx;
    ++m->verify_calls;
    return m->fail_verify ? -1 : 0;
}
static int commit(void *ctx) {++((mock *)ctx)->commit_calls;return 0;}
static void rollback(void *ctx) {++((mock *)ctx)->rollback_calls;}
static void reset(mock *m, gwir_apcfg_session *session, gwir_aptcp_ops *tcp,
                  gwir_station_ops *station, const uint8_t *request, size_t len)
{
    *m = (mock){0};
    *session = (gwir_apcfg_session){0};
    session->wifi_started = 1u;
    session->provisioner_started = 1u;
    m->session = session;
    m->request = request;
    m->length = len;
    m->listening = m->trusted = m->accepting = 1;
    *tcp = (gwir_aptcp_ops){m,listener_on_ap,accept_one,client_on_ap,
                           recv_some,send_some,close_client,now_ms};
    *station = (gwir_station_ops){m,stage,verify,commit,rollback};
}
static size_t make_request(char *dst, size_t cap)
{
    const char *body = "ssid=My+Router&password=12345678";
    int n = snprintf(dst, cap, "POST /api/provision HTTP/1.1\r\n"
            "Host: 192.168.4.1\r\n"
            "Content-Type: application/x-www-form-urlencoded\r\n"
            "Content-Length: %zu\r\nConnection: close\r\n\r\n%s",
            strlen(body), body);
    assert(n > 0 && (size_t)n < cap);
    return (size_t)n;
}
static void check_status(mock *m, unsigned expected)
{
    char expected_prefix[35];
    int n = snprintf(expected_prefix,sizeof(expected_prefix),"HTTP/1.1 %u ",expected);
    assert(n > 0 && strncmp(m->response,expected_prefix,(size_t)n) == 0);
    assert(strstr(m->response,"Cache-Control: no-store\r\n") != NULL);
    assert(strstr(m->response,"Connection: close\r\n") != NULL);
    assert(strstr(m->response,"12345678") == NULL);
    assert(m->close_calls == 1);
}
int main(void)
{
    char request[GWIR_APHTTP_REQUEST_MAX + 80u];
    char oversized[GWIR_APHTTP_REQUEST_MAX + 80u];
    size_t len = make_request(request,sizeof(request));
    mock m;
    gwir_apcfg_session session;
    gwir_aptcp_ops tcp;
    gwir_station_ops station;

    /* Exact read / partial sends, then randomized-looking small chunks. */
    for (unsigned i=0;i<9u;i++) {
        reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
        m.rx_chunk = (size_t)(i*13u+1u);
        m.tx_chunk = (size_t)(i+1u);
        assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
        check_status(&m,204u);
        assert(m.stage_calls == 1 && m.verify_calls == 1 && m.commit_calls == 1);
        assert(m.rollback_calls == 0 && m.read_position == len);
    }

    /* No physical/AP interface proof -> never even accept a socket. */
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.listening = 0;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_UNAVAILABLE);
    assert(m.accept_calls == 0 && m.stage_calls == 0);
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.accepting = 0;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_IDLE);
    assert(m.close_calls == 0);
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.trusted = 0;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REJECTED);
    check_status(&m,403u);
    assert(m.stage_calls == 0);

    /* Netif revocation while reading never provisions credentials. */
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.rx_chunk = 7;
    m.after_rx_revoke = 3;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
    check_status(&m,403u);
    assert(m.stage_calls == 0);
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.rx_chunk = 7;
    m.stop_session_after_rx = 3;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
    check_status(&m,403u);
    assert(m.stage_calls == 0);

    /* Idle read deadline; incomplete request cannot apply passwords. */
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.length = 5u;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
    check_status(&m,408u);
    assert(m.stage_calls == 0);

    /* Bad content, pipelining and oversized reads cannot alter profile. */
    reset(&m,&session,&tcp,&station,(const uint8_t *)"NOT_HTTP\r\n\r\n",12u);
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
    check_status(&m,400u);
    assert(m.stage_calls == 0);
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    memcpy(oversized,request,len);
    memcpy(oversized+len,"GET / HTTP/1.1\r\n\r\n",18u);
    m.request = (const uint8_t *)oversized;
    m.length = len + 18u;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
    check_status(&m,400u);
    assert(m.stage_calls == 0);

    /* Failed verify must roll back, no credentials in response. */
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.fail_verify = 1;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_REPLIED);
    check_status(&m,503u);
    assert(m.stage_calls == 1 && m.verify_calls == 1 && m.rollback_calls == 1);
    assert(m.commit_calls == 0);

    /* I/O failure closes one time; invalid callback sets are refused. */
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    m.fail_send = 1;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_IO_FAILURE);
    assert(m.close_calls == 1);
    reset(&m,&session,&tcp,&station,(const uint8_t *)request,len);
    tcp.client_on_ap = NULL;
    assert(gwir_aptcp_serve_one(&tcp,&session,&station) == GWIR_APTCP_INVALID_CALL);
    assert(m.accept_calls == 0);

    puts("PASS: REV21 AP-only TCP adapter, fragments/partial writes, timeout, revocation, rollback, fail-closed");
    return 0;
}
