from pathlib import Path
import re, gzip, base64, hashlib
root = Path(__file__).resolve().parents[1]
code = (root/'firmware/core/gwir_dashboard_asset.c').read_text()
raw = bytes(int(h,16) for h in re.findall(r'0x([0-9a-f]{2})', code))
html = (root/'web/dashboard/index.html').read_bytes()
assert gzip.decompress(raw) == html, 'Embedded HTML differs from source'
assert len(raw) <= 6144, f'asset too large: {len(raw)}'
assert html.count(b'<style>') == html.count(b'</style>') == 1
assert html.count(b'<script>') == html.count(b'</script>') == 1
for tag in (b'style',b'script'):
    part = html.split(b'<'+tag+b'>',1)[1].split(b'</'+tag+b'>',1)[0]
    digest=base64.b64encode(hashlib.sha256(part).digest()).decode()
    assert f"'sha256-{digest}'" in code
assert b'fetch(' not in html and b'WebSocket(' not in html
print(f'PASS CP13 exact gzip roundtrip, sha256 CSP script/style, budget {len(raw)}/6144, read-only UI')
