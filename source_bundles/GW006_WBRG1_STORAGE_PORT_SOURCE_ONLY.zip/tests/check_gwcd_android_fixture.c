#include "gwir_gwcd_store.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct { FILE *f; uint32_t size; } source;
static int file_reader(void *ctx,uint32_t off,void *data,size_t n) {
    source *s=(source*)ctx;
    if (off > s->size || n > s->size-off) return -1;
    if (fseek(s->f,(long)off,SEEK_SET)!=0) return -1;
    return fread(data,1,n,s->f)==n?0:-1;
}
int main(int argc,char **argv) {
    source src;
    gwir_gwcd_index index;
    uint32_t pulses[GWIR_MAX_PULSES_PER_FRAME];
    long size;
    if(argc!=2) return 2;
    src.f=fopen(argv[1],"rb"); if(!src.f) return 3;
    assert(fseek(src.f,0,SEEK_END)==0);
    size=ftell(src.f); assert(size>0 && size<=(long)GWIR_GWCD_MAX_SIZE);
    src.size=(uint32_t)size;
    assert(gwir_gwcd_scan(file_reader,&src,src.size,7u,&index)==0);
    assert(index.button==7u && index.frame_count==5u);
    for(unsigned f=0;f<5u;++f) {
        const gwir_gwcd_frame_index *fr=&index.frame[f];
        assert(fr->carrier_hz==38000u+f*1000u);
        assert(fr->duty_permille==300u+f*10u);
        assert(fr->gap_after_us==24000u+f*1000u);
        assert(fr->pulse_count==f+2u);
        assert(gwir_gwcd_read_frame(file_reader,&src,&index,(uint8_t)f,pulses,2048u)==0);
        for(unsigned p=0;p<f+2u;++p) assert(pulses[p]==500u+f*10u+p*100u);
    }
    fclose(src.f);
    puts("PASS CP17: Kotlin AndroidCodeStore -> C GWCD decoder interoperability, 5 frames");
    return 0;
}
