#include "gwir_saved_play_command.h"
#include "gwir_auth_stream.h"
#include <openssl/hmac.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* CP29 host-only NOR, real HMAC-SHA256, serialized GWAS, fake IR.
 * Never touches board pins, live network or vendor flash. */
typedef struct {uint8_t *mem; uint32_t size; unsigned reads; int fault;} nor_t;
typedef struct {int allowed; int sent; int fail_at; int revoke_after;} ir_t;
static uint8_t wire[GWIR_GWCD_MAX_SIZE];
static uint32_t wire_size;
static uint32_t pulse_scratch[GWIR_MAX_PULSES_PER_FRAME];
static uint8_t scratch[GWIR_MAX_MESSAGE], signed_response[GWIR_AUTH_MAX_PACKET];
static uint8_t key[32],nonce[16];
static gwir_auth_session phone_tx,phone_rx,device_rx,device_tx;
static gwir_engine engine;
static gwir_saved_play_service service;
static uint8_t emitted[GWIR_AUTH_MAX_PACKET];
static size_t emitted_len;
static int emitted_count;
static int rd(void *ctx,uint32_t off,void *dst,size_t n) {
    nor_t *c=(nor_t*)ctx;
    ++c->reads;
    if(c->fault || off>c->size || n>c->size-off) return -1;
    memcpy(dst,c->mem+off,n);return 0;
}
static int wr(void *ctx,uint32_t off,const void *src,size_t n) {
    nor_t *c=(nor_t*)ctx;const uint8_t *p=(const uint8_t*)src;
    if(off>c->size || n>c->size-off) return -1;
    for(size_t i=0;i<n;i++) {
        if((c->mem[off+i]&p[i])!=p[i]) return -1;
        c->mem[off+i]&=p[i];
    }
    return 0;
}
static int erase(void *ctx,uint32_t off) {
    nor_t *c=(nor_t*)ctx;
    if(off%GWIR_FJ_SECTOR || off>c->size || c->size-off<GWIR_FJ_SECTOR) return -1;
    memset(c->mem+off,0xff,GWIR_FJ_SECTOR);return 0;
}
static int source(void *ctx,uint32_t off,void *dst,size_t n) {
    (void)ctx;
    if(off>wire_size || n>wire_size-off) return -1;
    memcpy(dst,wire+off,n);return 0;
}
static void build_record(uint8_t button) {
    size_t p=0;
    memcpy(wire+p,"GWCD",4);p+=4;
    gwir_write_u32be(wire+p,1);p+=4;
    gwir_write_u32be(wire+p,button);p+=4;
    gwir_write_u32be(wire+p,3);p+=4;
    for(unsigned f=0;f<3;f++) {
        gwir_write_u32be(wire+p,38000u);p+=4;
        gwir_write_u16be(wire+p,333u);p+=2;
        gwir_write_u16be(wire+p,4u);p+=2;
        gwir_write_u32be(wire+p,15000u);p+=4;
        for(unsigned i=0;i<4;i++) {
            gwir_write_u32be(wire+p,560u+i);p+=4;
        }
    }
    gwir_write_u32be(wire+p,gwir_crc32_continue(0xffffffffu,wire,p)^0xffffffffu);p+=4;
    wire_size=(uint32_t)p;
}
static int ready(void *ctx) {
    ir_t *ir=(ir_t*)ctx;
    return ir->allowed && (ir->revoke_after<0 || ir->sent<ir->revoke_after);
}
static int send_ir(void *ctx,uint32_t carrier,uint16_t duty,const uint32_t *dur,
                   uint16_t count,uint32_t gap) {
    ir_t *ir=(ir_t*)ctx;
    if(ir->sent==ir->fail_at) return -1;
    assert(carrier==38000 && duty==333 && count==4 && gap==15000);
    assert(dur[0]==560u && dur[3]==563u);
    ++ir->sent;return 0;
}
static int sha_hmac(void *ctx,const uint8_t *k,size_t kl,const uint8_t *data,
                    size_t n,uint8_t out[32]) {
    unsigned int len=0;
    (void)ctx;
    return !HMAC(EVP_sha256(),k,(int)kl,data,n,out,&len) || len!=32;
}
static void start_auth(void) {
    for(unsigned i=0;i<32;i++) key[i]=(uint8_t)(i+1);
    for(unsigned i=0;i<16;i++) nonce[i]=(uint8_t)(i+0x50);
    assert(gwir_auth_init(&phone_tx,key,nonce,sha_hmac,NULL)==0);
    assert(gwir_auth_init(&phone_rx,key,nonce,sha_hmac,NULL)==0);
    assert(gwir_auth_init(&device_rx,key,nonce,sha_hmac,NULL)==0);
    assert(gwir_auth_init(&device_tx,key,nonce,sha_hmac,NULL)==0);
    gwir_ir_hal hal={0};gwir_engine_init(&engine,hal);
}
static size_t request(uint8_t out[GWIR_AUTH_MAX_PACKET],uint8_t cmd,
                      uint32_t seq,const uint8_t *body,size_t n) {
    uint8_t inner[GWIR_MAX_MESSAGE];size_t len=0,total=0;
    assert(gwir_encode(inner,sizeof(inner),cmd,seq,body,(uint32_t)n,&len)==0);
    assert(gwir_auth_wrap(&phone_tx,GWIR_AUTH_TO_DEVICE,inner,len,
                          out,GWIR_AUTH_MAX_PACKET,&total)==0);
    return total;
}
static void read_status(const uint8_t *signed_bytes,size_t size,
                        uint32_t seq,uint8_t cmd,uint8_t status,uint8_t frames) {
    const uint8_t *inner=NULL;size_t len=0;gwir_message message={0};
    assert(gwir_auth_unwrap(&phone_rx,GWIR_AUTH_FROM_DEVICE,signed_bytes,size,
                            &inner,&len)==0);
    assert(gwir_decode(inner,len,&message)==0);
    assert(message.command==cmd && message.sequence==seq);
    assert(message.payload_len==(cmd==GWIR_SAVED_STATUS?2u:1u));
    assert(message.payload[0]==status);
    if(cmd==GWIR_SAVED_STATUS) assert(message.payload[1]==frames);
}
static void exchange(uint32_t seq,uint8_t cmd,const uint8_t *body,size_t n,
                     uint8_t reply_cmd,uint8_t status,uint8_t frames) {
    uint8_t record[GWIR_AUTH_MAX_PACKET];size_t rec=request(record,cmd,seq,body,n),out=0;
    assert(gwir_auth_dispatch_routed(&device_rx,&device_tx,&engine,record,rec,
        scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        &out,gwir_saved_play_command,&service)==GWIR_AUTH_OK);
    read_status(signed_response,out,seq,reply_cmd,status,frames);
}
static int emit(void *ctx,const uint8_t *data,size_t n) {
    (void)ctx;
    if(n>sizeof(emitted)) return -1;
    memcpy(emitted,data,n);emitted_len=n;emitted_count++;
    return 0;
}
int main(void) {
    nor_t nor={0};ir_t ir={0};gwir_fj_store store;
    uint8_t button=95,empty=94,invalid=96;
    static uint8_t rec[GWIR_AUTH_MAX_PACKET],bad[GWIR_AUTH_MAX_PACKET];
    size_t len,out;
    nor.size=GWIR_FJ_SECTOR*25;
    nor.mem=malloc(nor.size);assert(nor.mem);memset(nor.mem,0xff,nor.size);
    gwir_fj_io io={&nor,rd,wr,erase,nor.size};
    assert(gwir_fj_open(&store,&io)==0);
    build_record(button);
    assert(gwir_fj_put(&store,button,source,NULL,wire_size)==0);
    ir.fail_at=-1;ir.revoke_after=-1;
    gwir_fj_play_ops ops={&ir,ready,send_ir};
    assert(gwir_saved_play_init(&service,&store,&ops,pulse_scratch,2047)==-1);
    assert(gwir_saved_play_init(&service,&store,&ops,pulse_scratch,2048)==0);
    start_auth();

    /* Tampering and preflight small-buffer rejection must never send IR. */
    len=request(rec,GWIR_TX_SAVED,1,&button,1);
    memcpy(bad,rec,len);bad[len-1]^=1;
    out=777;
    assert(gwir_auth_dispatch_routed(&device_rx,&device_tx,&engine,bad,len,
        scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        &out,gwir_saved_play_command,&service)<0 && out==0);
    out=777;
    assert(gwir_auth_dispatch_routed(&device_rx,&device_tx,&engine,rec,len,
        scratch,2,signed_response,sizeof(signed_response),&out,
        gwir_saved_play_command,&service)<0 && out==0);
    unsigned reads_before=nor.reads;
    assert(gwir_auth_dispatch_routed(&device_rx,&device_tx,&engine,rec,len,
        scratch,sizeof(scratch),signed_response,sizeof(signed_response),&out,
        gwir_saved_play_command,&service)==0);
    read_status(signed_response,out,1,GWIR_SAVED_STATUS,GWIR_NOT_READY,0);
    assert(nor.reads==reads_before && ir.sent==0);
    ir.allowed=1;
    exchange(1,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_NOT_READY,0);
    assert(ir.sent==0); /* same GWIR seq even with fresh valid GWAS counter */
    exchange(2,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_OK,3);
    assert(ir.sent==3);
    exchange(2,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_OK,3);
    assert(ir.sent==3);
    exchange(1,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_BAD_REQUEST,0);
    exchange(2,GWIR_TX_SAVED,&empty,1,GWIR_SAVED_STATUS,GWIR_BAD_REQUEST,0);
    exchange(3,GWIR_TX_SAVED,&empty,1,GWIR_SAVED_STATUS,GWIR_NO_SAVED_CODE,0);
    exchange(4,GWIR_TX_SAVED,&invalid,1,GWIR_SAVED_STATUS,GWIR_BAD_REQUEST,0);
    exchange(4,GWIR_TX_SAVED,NULL,0,GWIR_SAVED_STATUS,GWIR_BAD_REQUEST,0);
    exchange(0,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_BAD_REQUEST,0);
    engine.rx_armed=1;
    exchange(4,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_BUSY,0);
    engine.rx_armed=0;
    exchange(4,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_BUSY,0);
    exchange(5,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_OK,3);
    assert(ir.sent==6);

    /* Original authenticated dispatch never routes persisted playback. */
    len=request(rec,GWIR_TX_SAVED,6,&button,1);out=0;
    assert(gwir_auth_dispatch(&device_rx,&device_tx,&engine,rec,len,
        scratch,sizeof(scratch),signed_response,sizeof(signed_response),&out)==0);
    read_status(signed_response,out,6,GWIR_STATUS,GWIR_UNSUPPORTED,0);
    assert(ir.sent==6);
    /* Auth replay in an identical GWAS packet is rejected before any IO. */
    assert(gwir_auth_dispatch_routed(&device_rx,&device_tx,&engine,rec,len,
        scratch,sizeof(scratch),signed_response,sizeof(signed_response),&out,
        gwir_saved_play_command,&service)==GWIR_AUTH_REPLAY && out==0);

    /* Old Rx session still refuses hardware not ready; no silent IR TX. */
    ir.allowed=0;
    exchange(7,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_NOT_READY,0);
    ir.allowed=1;
    /* Partial failure reports accepted frames; replay cached, no retransmit. */
    ir.sent=0;ir.fail_at=1;
    exchange(8,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_IR_FAILED,1);
    assert(ir.sent==1);
    ir.fail_at=-1;
    exchange(8,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_IR_FAILED,1);
    assert(ir.sent==1);
    /* Corrupt persisted bytes; storage error delivered in SIGNED response. */
    uint32_t live=store.entry[95].offset;
    nor.mem[live+40]^=1;
    exchange(9,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_STORAGE_ERROR,0);
    assert(ir.sent==1);
    nor.mem[live+40]^=1;
    nor.fault=1;
    exchange(10,GWIR_TX_SAVED,&button,1,GWIR_SAVED_STATUS,GWIR_STORAGE_ERROR,0);
    nor.fault=0;

    /* Signed stream fragmentation calls handler ONLY after whole GWAS record. */
    gwir_auth_stream stream;gwir_auth_stream_init(&stream);
    ir.sent=0;emitted_count=0;emitted_len=0;
    len=request(rec,GWIR_TX_SAVED,11,&button,1);
    assert(gwir_auth_stream_feed_routed(&stream,rec,13,&device_rx,&device_tx,
        &engine,scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        emit,NULL,gwir_saved_play_command,&service)==0);
    assert(ir.sent==0 && emitted_count==0);
    assert(gwir_auth_stream_feed_routed(&stream,rec+13,len-13,&device_rx,&device_tx,
        &engine,scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        emit,NULL,gwir_saved_play_command,&service)==1);
    assert(ir.sent==3 && emitted_count==1);
    read_status(emitted,emitted_len,11,GWIR_SAVED_STATUS,GWIR_OK,3);

    len=request(rec,GWIR_TX_SAVED,12,&button,1);
    memcpy(bad,rec,len);bad[len-1]^=1;
    assert(gwir_auth_stream_feed_routed(&stream,bad,len,&device_rx,&device_tx,
        &engine,scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        emit,NULL,gwir_saved_play_command,&service)<0);
    assert(stream.failed==1 && ir.sent==3 && emitted_count==1);
    assert(gwir_auth_stream_feed_routed(&stream,rec,len,&device_rx,&device_tx,
        &engine,scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        emit,NULL,gwir_saved_play_command,&service)<0);

    /* Legacy feed() ignores handler and does not reach flash playback. */
    gwir_auth_stream_init(&stream);
    assert(gwir_auth_stream_feed(&stream,rec,len,&device_rx,&device_tx,
        &engine,scratch,sizeof(scratch),signed_response,sizeof(signed_response),
        emit,NULL)==1);
    read_status(emitted,emitted_len,12,GWIR_STATUS,GWIR_UNSUPPORTED,0);
    assert(ir.sent==3);

    free(nor.mem);
    puts("PASS CP29: real HMAC signed saved IR, bounded routing, invalid HMAC, replay, idempotency, 96 button range, RX busy, physical deny, journal CRC/I-O, partial TX, fragmented GWAS; NO FLASH");
    return 0;
}
