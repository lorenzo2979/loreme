#ifndef GWIR_STUB_LOCK_H
#define GWIR_STUB_LOCK_H
#define RT_DEV_LOCK_FLASH 1
void device_mutex_lock(int);
void device_mutex_unlock(int);
#endif
