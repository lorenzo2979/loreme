#ifndef GWIR_STUB_OBJECTS_H
#define GWIR_STUB_OBJECTS_H
typedef struct flash_s { int reserved; } flash_t;
#endif
