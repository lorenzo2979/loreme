#ifndef GWIR_STUB_FLASH_API_H
#define GWIR_STUB_FLASH_API_H
#include <stdint.h>
#include "objects.h"
int flash_read_id(flash_t *, uint8_t *, uint8_t);
int flash_stream_read(flash_t *, uint32_t, uint32_t, uint8_t *);
int flash_stream_write(flash_t *, uint32_t, uint32_t, uint8_t *);
void flash_erase_sector(flash_t *, uint32_t);
#endif
