"""A socket without enforceable timeouts must never listen for HTTP."""
from pathlib import Path
import os
import socket
import subprocess

root = Path(__file__).resolve().parent.parent
with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
env = dict(os.environ, GWIR_TEST_DENY_TIMEOUT="1")
proc = subprocess.run([str(root / "build/dashboard_sta_lwip_harness"), str(port)],
                      env=env, capture_output=True, timeout=4, check=False)
assert proc.returncode != 0, "Server returned success despite failed timeout"
with socket.socket() as s:
    s.settimeout(0.3)
    assert s.connect_ex(("127.0.0.1", port)) != 0, "Unsafe listener left running"
print("PASS CP16: rejected lwIP socket timeout prevents HTTP listener")
