/* Behavioral host test for the task-context physical IR bridge.
   No real pinmux, flash, GPIO, or device credentials. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/realtek/gwir_ir_pipeline.h"

static gwir_amebad_rx_queue *bound_queue;
int gwir_amebad_rx_irq_bind(gwir_amebad_rx_queue *q, uint32_t idle,
                            gwir_amebad_rx_irq_stats *stats) {
    (void)stats;
    if (!q || idle < 1000u || bound_queue) return -1;
    bound_queue=q;return 0;
}
void gwir_amebad_rx_irq_unbind(void) {bound_queue=NULL;}

typedef struct {
    uint32_t ms;
    unsigned polls, tx_stop, rx_on, rx_off, tx_on, tx_prep, words, irq_lock;
    int authorized, revoke_at, stop_fail;
    int transmitting;
    uint32_t queued;
} hw;
static int ready(void *p) {return ((hw*)p)->authorized;}
static uint32_t ms(void *p) {return ((hw*)p)->ms;}
static int rx_start(void *p) {++((hw*)p)->rx_on;return 0;}
static int rx_stop(void *p) {++((hw*)p)->rx_off;return 0;}
static int tx_prepare(void *p, uint32_t carrier,uint16_t duty) {
    hw *h=p;assert(carrier==38000u && duty==333u);
    ++h->tx_prep;h->transmitting=1;return 0;
}
static int tx_stop(void *p) {hw *h=p;++h->tx_stop;h->transmitting=0;return h->stop_fail?-1:0;}
static uint32_t free_slots(void *p) {hw *h=p;return 32u-h->queued;}
static int write_words(void *p,const uint32_t *words,uint32_t n,int last) {
    hw *h=p; (void)words; (void)last;
    assert(n<=free_slots(p));h->queued+=n;h->words+=n;return 0;
}
static int start_tx(void *p) {++((hw*)p)->tx_on;return 0;}
static int running(void *p) {return ((hw*)p)->queued?1:0;}
static int yield(void *p) {
    hw *h=p;h->ms++;h->queued=0;h->polls++;
    if (h->revoke_at>0 && (int)h->polls>=h->revoke_at)
        h->authorized=0;
    return 0;
}
static void lock(void *p) {hw *h=p;assert(h->irq_lock==0u);h->irq_lock=1u;}
static void unlock(void *p) {hw *h=p;assert(h->irq_lock==1u);h->irq_lock=0u;}
static gwir_ir_pipeline_config setup(hw *h) {
    gwir_ir_pipeline_config c={0};
    c.bus.ctx=h;c.bus.board_ir_ready=ready;
    c.bus.rx_start=rx_start;c.bus.rx_stop=rx_stop;
    c.bus.tx_prepare=tx_prepare;c.bus.tx_stop=tx_stop;
    c.bus.monotonic_ms=ms;c.bus.tx.ctx=h;
    c.bus.tx.free_slots=free_slots;c.bus.tx.write_words=write_words;
    c.bus.tx.start_tx=start_tx;c.bus.tx.is_running=running;
    c.irq_lock.ctx=h;c.irq_lock.lock_ir_irq=lock;c.irq_lock.unlock_ir_irq=unlock;
    c.sample_hz=10000000u;c.carrier_guess_hz=38000u;
    c.duty_guess_permille=333u;c.gap_threshold_us=30000u;
    c.active_mark_level=0u;c.yield_one_ms=yield;c.yield_ctx=h;
    return c;
}
static void test_refuse_then_tx_and_revocation(void) {
    static gwir_ir_pipeline p;
    static gwir_engine e;
    hw h={0};
    gwir_ir_pipeline_config c=setup(&h);
    assert(gwir_ir_pipeline_init(&p,&e,&c)==-1);
    assert(!h.rx_on && !h.tx_prep);
    h.authorized=1;
    assert(gwir_ir_pipeline_init(&p,&e,&c)==0);
    uint32_t durations[]={9000u,4500u,560u,560u};
    assert(e.hal.tx(e.hal.ctx,38000u,333u,durations,4u,1000u)==0);
    assert(h.words==4u && h.tx_on==1u && h.tx_stop==1u && !h.transmitting);
    h.revoke_at=(int)h.polls+1;
    assert(e.hal.tx(e.hal.ctx,38000u,333u,durations,4u,1000u)==-1);
    assert(h.tx_stop>=2u && !h.transmitting);
    assert(gwir_ir_pipeline_stop(&p)==0);
    assert(e.hal.tx==NULL);
}
static void test_rx_capture(void) {
    static gwir_ir_pipeline p;
    static gwir_engine e;
    hw h={0};h.authorized=1;
    gwir_ir_pipeline_config c=setup(&h);
    assert(gwir_ir_pipeline_init(&p,&e,&c)==0);
    assert(e.hal.rx_arm(e.hal.ctx)==0);
    e.rx_armed=1u;
    assert(bound_queue==&p.rx_queue && h.rx_on==1u);
    assert(gwir_amebad_rx_irq_word(bound_queue,90000u)==0); /* 9ms mark */
    assert(gwir_amebad_rx_irq_word(bound_queue,0x80000000u|45000u)==0);
    assert(gwir_amebad_rx_irq_word(bound_queue,5600u)==0);
    assert(gwir_amebad_rx_irq_word(bound_queue,0x80000000u|5600u)==0);
    assert(gwir_amebad_rx_irq_idle(bound_queue,30000u)==0);
    assert(gwir_ir_pipeline_pump(&p,10u)==1);
    assert(e.rx_count==1u && e.rx_queue[0].count==4u);
    assert(e.hal.rx_disarm(e.hal.ctx)==0 && h.rx_off==1u);
    e.rx_armed=0u;
    assert(bound_queue==NULL && e.rx_count==1u); /* ACK required */
    assert(gwir_ir_pipeline_stop(&p)==0);
    assert(!p.ready && e.rx_count==1u);
}
int main(void) {
    test_refuse_then_tx_and_revocation();test_rx_capture();
    puts("PASS CP38 IR pipeline: board gate, real bus TX, mid-TX revoke, IRQ RX decode, persistent RX until ACK");
    return 0;
}
