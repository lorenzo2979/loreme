#include "gwir_apconfig_http_stream.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static const char body[] = "ssid=My+Router&password=12345678";
static const char header[] = "POST /api/provision HTTP/1.1\r\n"
    "Host: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\n"
    "Content-Length: 32\r\nConnection: close\r\n\r\n";

typedef struct {
    int writes, closes, failed, staged, verified, committed, rolled_back;
    int fail_write, fail_verify;
    char response[200];
} mock;

static int write_all(void *ctx, const uint8_t *p, size_t size)
{
    mock *m = ctx;
    assert(size < sizeof(m->response));
    ++m->writes;
    memcpy(m->response, p, size);
    m->response[size] = 0;
    return m->fail_write ? -1 : 0;
}
static void close_client(void *ctx) { ++((mock *)ctx)->closes; }
static int stage(void *ctx, const gwir_station_profile *profile)
{
    mock *m=ctx;
    ++m->staged;
    assert(strcmp(profile->wifi.ssid,"My Router") == 0);
    assert(strcmp(profile->wifi.password,"12345678") == 0);
    return 0;
}
static int verify(void *ctx) {mock *m=ctx; ++m->verified; return m->fail_verify ? -1 : 0;}
static int commit(void *ctx) {++((mock *)ctx)->committed; return 0;}
static void rollback(void *ctx) {++((mock *)ctx)->rolled_back;}
static void prepare(gwir_apstream *s, mock *m, gwir_apcfg_session *session,
                    gwir_station_ops *ops, gwir_apstream_io *io, unsigned now)
{
    memset(m, 0, sizeof(*m));
    *session = (gwir_apcfg_session){0};
    session->wifi_started = session->provisioner_started = 1u;
    *ops = (gwir_station_ops){m,stage,verify,commit,rollback};
    *io = (gwir_apstream_io){m,write_all,close_client};
    assert(gwir_apstream_init(s,now,1) == 0);
}
static size_t make_request(char *out, size_t cap, const char *prefix, const char *data)
{
    size_t h = strlen(prefix), b = strlen(data);
    assert(h+b < cap);
    memcpy(out,prefix,h); memcpy(out+h,data,b);
    return h+b;
}
static void wiped(const gwir_apstream *s)
{
    assert(s->len == 0u && s->header_end == 0u && s->expected_total == 0u);
    for (size_t i=0u; i<sizeof(s->request); ++i) assert(s->request[i] == 0u);
}
static void check_reply(const mock *m, unsigned expected)
{
    char prefix[32];
    snprintf(prefix,sizeof(prefix),"HTTP/1.1 %u ",expected);
    assert(strncmp(m->response,prefix,strlen(prefix)) == 0);
    assert(strstr(m->response,"Connection: close\r\n") != NULL);
    assert(strstr(m->response,"Cache-Control: no-store\r\n") != NULL);
    assert(strstr(m->response,"Content-Length: 0\r\n") != NULL);
    assert(strstr(m->response,"My Router") == NULL);
    assert(strstr(m->response,"12345678") == NULL);
    assert(m->writes == 1 && m->closes == 1);
}
static void test_fragmentation(void)
{
    char request[GWIR_APHTTP_REQUEST_MAX + 32u];
    size_t n = make_request(request,sizeof(request),header,body);
    const size_t chunks[] = {1u,2u,3u,4u,7u,31u,n};
    for (size_t c=0; c<sizeof(chunks)/sizeof(chunks[0]); ++c) {
        gwir_apstream s;
        mock m;
        gwir_apcfg_session session;
        gwir_station_ops ops;
        gwir_apstream_io io;
        size_t offset = 0u;
        prepare(&s,&m,&session,&ops,&io,100u);
        while (offset < n) {
            size_t portion = chunks[c];
            if (portion > n-offset) portion = n-offset;
            int status = gwir_apstream_feed(&s,(const uint8_t *)request+offset,
                                             portion,101u+((uint32_t)offset/20u),
                                             &session,&ops,&io);
            offset += portion;
            assert(status == (offset == n ? GWIR_APSTREAM_CLOSED : GWIR_APSTREAM_MORE));
        }
        assert(m.staged == 1 && m.verified == 1 && m.committed == 1 && !m.rolled_back);
        check_reply(&m,204u); wiped(&s);
        assert(gwir_apstream_feed(&s,(const uint8_t *)request,1u,200u,&session,&ops,&io)
               == GWIR_APSTREAM_INVALID_CALL);
        assert(m.writes == 1 && m.closes == 1);
    }
}
static void test_chunk_pipelining(void)
{
    char request[GWIR_APHTTP_REQUEST_MAX+200u];
    size_t n = make_request(request,sizeof(request),header,body);
    const char *extra="GET / HTTP/1.1\r\n\r\n";
    memcpy(request+n,extra,strlen(extra));
    gwir_apstream s;
    mock m;
    gwir_apcfg_session session;
    gwir_station_ops ops;
    gwir_apstream_io io;
    prepare(&s,&m,&session,&ops,&io,0u);
    assert(gwir_apstream_feed(&s,(const uint8_t *)request,n+strlen(extra),1u,
                              &session,&ops,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,400u); assert(m.staged == 0); wiped(&s);
}
static void test_trust_and_session(void)
{
    gwir_apstream s;
    mock m;
    gwir_apcfg_session session;
    gwir_station_ops ops;
    gwir_apstream_io io;
    prepare(&s,&m,&session,&ops,&io,0u);
    assert(gwir_apstream_init(&s,0u,0) == 0);
    assert(gwir_apstream_feed(&s,(const uint8_t *)header,strlen(header),100u,
                              &session,&ops,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,403u); assert(m.staged == 0); wiped(&s);
    prepare(&s,&m,&session,&ops,&io,0u);
    assert(gwir_apstream_feed(&s,(const uint8_t *)header,9u,1u,&session,&ops,&io)
           == GWIR_APSTREAM_MORE);
    session.provisioner_started = 0u;
    assert(gwir_apstream_poll(&s,2u,&session,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,403u); wiped(&s);
}
static void test_timeouts(void)
{
    gwir_apstream s;
    mock m;
    gwir_apcfg_session session;
    gwir_station_ops ops;
    gwir_apstream_io io;
    prepare(&s,&m,&session,&ops,&io,0u);
    assert(gwir_apstream_poll(&s,1999u,&session,&io) == GWIR_APSTREAM_MORE);
    assert(gwir_apstream_poll(&s,2000u,&session,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,408u); wiped(&s);
    prepare(&s,&m,&session,&ops,&io,0u);
    for (unsigned now=1000u;now<10000u;now+=1000u) {
        assert(gwir_apstream_feed(&s,(const uint8_t *)"a",1u,now,&session,&ops,&io)
               == GWIR_APSTREAM_MORE);
    }
    assert(gwir_apstream_poll(&s,10000u,&session,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,408u); wiped(&s);
    prepare(&s,&m,&session,&ops,&io,UINT32_MAX-100u);
    assert(gwir_apstream_poll(&s,1100u,&session,&io) == GWIR_APSTREAM_MORE);
    assert(gwir_apstream_poll(&s,1900u,&session,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,408u);
}
static void test_incomplete_and_errors(void)
{
    gwir_apstream s;
    mock m;
    gwir_apcfg_session session;
    gwir_station_ops ops;
    gwir_apstream_io io;
    char request[GWIR_APHTTP_REQUEST_MAX+100u];
    char oversized[GWIR_APHTTP_REQUEST_MAX+10u];
    size_t n = make_request(request,sizeof(request),header,body);
    prepare(&s,&m,&session,&ops,&io,0u);
    assert(gwir_apstream_feed(&s,(const uint8_t *)request,n-5u,1u,&session,&ops,&io)
           == GWIR_APSTREAM_MORE);
    assert(gwir_apstream_poll(&s,2002u,&session,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,408u); assert(m.staged == 0); wiped(&s);
    prepare(&s,&m,&session,&ops,&io,0u);
    memset(oversized,'A',sizeof(oversized));
    assert(gwir_apstream_feed(&s,(const uint8_t *)oversized,sizeof(oversized),1u,
                              &session,&ops,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,413u); wiped(&s);
    prepare(&s,&m,&session,&ops,&io,0u);
    char invalid[]="POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Length: 0\r\n\r\n";
    assert(gwir_apstream_feed(&s,(const uint8_t *)invalid,strlen(invalid),1u,
                              &session,&ops,&io) == GWIR_APSTREAM_CLOSED);
    check_reply(&m,400u); assert(m.staged == 0);
    prepare(&s,&m,&session,&ops,&io,0u);
    m.fail_verify = 1;
    assert(gwir_apstream_feed(&s,(const uint8_t *)request,n,1u,&session,&ops,&io)
           == GWIR_APSTREAM_CLOSED);
    check_reply(&m,503u); assert(m.staged == 1 && m.rolled_back == 1 && m.committed == 0);
    prepare(&s,&m,&session,&ops,&io,0u);
    m.fail_write = 1;
    assert(gwir_apstream_feed(&s,(const uint8_t *)request,n,1u,&session,&ops,&io)
           == GWIR_APSTREAM_IO_FAILURE);
    assert(m.closes == 1); wiped(&s);
    prepare(&s,&m,&session,&ops,&io,0u);
    assert(gwir_apstream_feed(&s,(const uint8_t *)header,strlen(header),1u,
                              &session,&ops,&io) == GWIR_APSTREAM_MORE);
    gwir_apstream_discard(&s);
    wiped(&s); assert(s.terminated);
    assert(m.closes == 0 && m.writes == 0);
}
static uint32_t test_rng = 0x9e3779b9u;
static uint32_t next_random(void)
{
    test_rng ^= test_rng << 13;
    test_rng ^= test_rng >> 17;
    test_rng ^= test_rng << 5;
    return test_rng;
}
static void test_random_chunk_boundaries(void)
{
    char request[GWIR_APHTTP_REQUEST_MAX + 16u];
    size_t len = make_request(request,sizeof(request),header,body);
    for (unsigned trial = 0u; trial < 3000u; ++trial) {
        gwir_apstream s;
        mock m;
        gwir_apcfg_session session;
        gwir_station_ops ops;
        gwir_apstream_io io;
        size_t position = 0u;
        prepare(&s,&m,&session,&ops,&io,0u);
        while (position < len) {
            size_t take = 1u + (next_random() % 37u);
            if (take > len - position) take = len - position;
            int result = gwir_apstream_feed(&s,(const uint8_t*)request+position,take,
                    (uint32_t)position, &session,&ops,&io);
            position += take;
            assert(result == (position == len ? GWIR_APSTREAM_CLOSED : GWIR_APSTREAM_MORE));
        }
        assert(m.staged == 1 && m.committed == 1);
        check_reply(&m,204u);
        wiped(&s);
    }
}
static void test_duplicate_length_fragmented(void)
{
    const char *dup = "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\n"
                      "Content-Type: application/x-www-form-urlencoded\r\n"
                      "Content-Length: 32\r\nContent-Length: 32\r\n\r\n";
    gwir_apstream s;
    mock m;
    gwir_apcfg_session session;
    gwir_station_ops ops;
    gwir_apstream_io io;
    prepare(&s,&m,&session,&ops,&io,0u);
    size_t n = strlen(dup);
    for (size_t i=0u;i<n;++i) {
        int result = gwir_apstream_feed(&s,(const uint8_t*)dup+i,1u,1u,
                                         &session,&ops,&io);
        if (i+1u == n) assert(result == GWIR_APSTREAM_CLOSED);
        else assert(result == GWIR_APSTREAM_MORE);
    }
    assert(!m.staged);
    check_reply(&m,400u);
    wiped(&s);
}
int main(void)
{
    test_random_chunk_boundaries();
    test_duplicate_length_fragmented();
    test_fragmentation();
    test_chunk_pipelining();
    test_trust_and_session();
    test_timeouts();
    test_incomplete_and_errors();
    puts("PASS REV20: AP-only bounded HTTP TCP reassembly, close, timeout, rollback and data wipe");
    return 0;
}
