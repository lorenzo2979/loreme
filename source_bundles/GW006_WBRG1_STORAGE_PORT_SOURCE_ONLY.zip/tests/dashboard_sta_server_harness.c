#include "../firmware/realtek/gwir_dashboard_sta_server.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
static volatile int stop_flag;
static volatile sig_atomic_t sta_allowed = 1;
static void on_ap_transition(int s) {(void)s;sta_allowed=0;}
static void on_sig(int s) {(void)s;stop_flag=1;}
static int check(void *ctx, uint32_t ip) {(void)ctx;return sta_allowed && ip == inet_addr("127.0.0.1");}
int main(int argc, char **argv) {
    gwir_dashboard_server_config cfg;
    if (argc != 2) return 2;
    signal(SIGTERM, on_sig);
    signal(SIGUSR1, on_ap_transition);
    cfg.sta_ip_network_order=inet_addr("127.0.0.1");
    cfg.port=(uint16_t)atoi(argv[1]);
    cfg.stop=&stop_flag;
    cfg.check_sta=check;
    cfg.ctx=NULL;
    return gwir_dashboard_server_run(&cfg);
}
