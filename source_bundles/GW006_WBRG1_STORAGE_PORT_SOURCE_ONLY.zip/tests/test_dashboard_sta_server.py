import gzip, pathlib, socket, subprocess, time, signal, os
root=pathlib.Path(__file__).resolve().parent.parent
def port():
    with socket.socket() as s:
        s.bind(("127.0.0.1",0))
        return s.getsockname()[1]
p=port()
server=subprocess.Popen([str(root/os.environ.get("GWIR_TEST_SERVER", "build/dashboard_sta_server_harness")),str(p)])
try:
    for _ in range(100):
        try:
            sock=socket.create_connection(("127.0.0.1",p),timeout=.2)
            break
        except OSError: time.sleep(.02)
    else: raise AssertionError("server not listening")
    with sock:
        sock.settimeout(3)
        for part in (b"GET / HTTP/1.1\r\n",b"Host: 127.0.0.1\r\n",b"\r\n"):
            sock.sendall(part)
        data=b""
        while True:
            block=sock.recv(4096)
            if not block: break
            data+=block
    header,body=data.split(b"\r\n\r\n",1)
    assert b"HTTP/1.1 200 OK" in header
    assert b"Content-Encoding: gzip" in header
    assert b"Connection: close" in header
    assert b"TV" in gzip.decompress(body)
    with socket.create_connection(("127.0.0.1",p),timeout=2) as sock:
        sock.sendall(b"POST /api/ir HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n")
        assert b"405 Method Not Allowed" in sock.recv(1024)
    # Connect and start an incomplete request. Transition to an AP-like state
    # before the headers complete: no HTML should be sent on that connection.
    with socket.create_connection(("127.0.0.1",p),timeout=2) as sock:
        sock.settimeout(3)
        sock.sendall(b"GET / HTTP/1.1\r\nHost: 127.0.0.1\r\n")
        time.sleep(.2)  # allow the server to accept/read partial headers
        server.send_signal(signal.SIGUSR1)
        time.sleep(.1)
        try: sock.sendall(b"\r\n")
        except OSError: pass
        try: blocked=sock.recv(4096)
        except (ConnectionResetError, BrokenPipeError): blocked=b""
        assert not blocked, repr(blocked[:100])
    print("PASS CP15: STA read-only GET + POST rejected + AP transition closes partial request")
finally:
    server.terminate()
    server.wait(timeout=5)
