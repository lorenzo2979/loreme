#ifndef GWIR_TEST_LWIP_SOCKETS_H
#define GWIR_TEST_LWIP_SOCKETS_H
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <unistd.h>
#define LWIP_SO_SNDRCVTIMEO_NONSTANDARD 1
#define lwip_close close
int gwir_test_lwip_setsockopt(int fd, int level, int option,
                             const void *optval, socklen_t optlen);
#define setsockopt gwir_test_lwip_setsockopt
#endif
