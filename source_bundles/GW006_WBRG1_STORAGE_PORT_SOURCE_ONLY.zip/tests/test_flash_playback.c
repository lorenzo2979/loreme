#include "gwir_flash_journal.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Host-only NOR + IR mock; never touches physical pins, flash or network. */
typedef struct {uint8_t *mem; uint32_t size; int fail_reads;} chip_t;
typedef struct {int approve; int sent; int fail_at; int revoke_after; uint32_t total_pulses;} ir_t;
static uint8_t wire[GWIR_GWCD_MAX_SIZE];
static uint32_t length;
static uint32_t scratch[GWIR_MAX_PULSES_PER_FRAME];

static int rd(void *ctx, uint32_t off, void *dst, size_t n) {
    chip_t *c=(chip_t*)ctx;
    if(c->fail_reads || off>c->size || n>c->size-off) return -1;
    memcpy(dst,c->mem+off,n); return 0;
}
static int wr(void *ctx, uint32_t off, const void *src, size_t n) {
    chip_t *c=(chip_t*)ctx; const uint8_t *p=(const uint8_t*)src;
    if(off>c->size || n>c->size-off) return -1;
    for(size_t i=0;i<n;i++) {
        if((c->mem[off+i]&p[i])!=p[i]) return -1;
        c->mem[off+i]&=p[i];
    }
    return 0;
}
static int erase(void *ctx, uint32_t off) {
    chip_t *c=(chip_t*)ctx;
    if((off%GWIR_FJ_SECTOR)||off>c->size||c->size-off<GWIR_FJ_SECTOR) return -1;
    memset(c->mem+off,0xff,GWIR_FJ_SECTOR); return 0;
}
static int source(void *ctx, uint32_t off, void *dst, size_t n) {
    (void)ctx;
    if(off>length || n>length-off) return -1;
    memcpy(dst,wire+off,n); return 0;
}
static void build(uint8_t button, uint16_t pulses, uint8_t frames) {
    uint32_t p=0;
    memcpy(wire+p,"GWCD",4);p+=4;
    gwir_write_u32be(wire+p,1);p+=4;
    gwir_write_u32be(wire+p,button);p+=4;
    gwir_write_u32be(wire+p,frames);p+=4;
    for(uint8_t f=0;f<frames;f++) {
        gwir_write_u32be(wire+p,38000u+f*1000u);p+=4;
        gwir_write_u16be(wire+p,333u);p+=2;
        gwir_write_u16be(wire+p,pulses);p+=2;
        gwir_write_u32be(wire+p,40000u+f*100u);p+=4;
        for(uint16_t i=0;i<pulses;i++) {
            gwir_write_u32be(wire+p,560u+f*5u+i);p+=4;
        }
    }
    gwir_write_u32be(wire+p,gwir_crc32_continue(0xffffffffu,wire,p)^0xffffffffu);p+=4;
    length=p;
}
static int ready(void *ctx) {
    ir_t *ir=(ir_t*)ctx;
    return ir->approve && (ir->revoke_after<0 || ir->sent<ir->revoke_after);
}
static int send(void *ctx,uint32_t carrier,uint16_t duty,const uint32_t *pulses,
                uint16_t count,uint32_t gap) {
    ir_t *ir=(ir_t*)ctx;
    if(ir->fail_at == ir->sent) return -1;
    assert(carrier==38000u+(uint32_t)ir->sent*1000u);
    assert(duty==333u && count>=1u);
    assert(gap==40000u+(uint32_t)ir->sent*100u);
    assert(pulses[0]==560u+(uint32_t)ir->sent*5u);
    ir->total_pulses+=count; ir->sent++; return 0;
}
int main(void) {
    chip_t c={0};ir_t ir={0};gwir_fj_store st,boot;
    uint8_t done=99;
    c.size=GWIR_FJ_SECTOR*25u;
    c.mem=malloc(c.size);assert(c.mem);memset(c.mem,0xff,c.size);
    gwir_fj_io io={&c,rd,wr,erase,c.size};
    gwir_fj_play_ops ops={&ir,ready,send};
    assert(gwir_fj_open(&st,&io)==0);
    build(95,8,5);
    assert(gwir_fj_put(&st,95,source,NULL,length)==0);
    /* Deny BEFORE any flash read or transmission (hardware not approved). */
    ir.approve=0;ir.fail_at=-1;ir.revoke_after=-1;
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==-6 && done==0 && ir.sent==0);
    c.fail_reads=1;
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==-6 && ir.sent==0);
    c.fail_reads=0;
    ir.approve=1;
    assert(gwir_fj_play(&st,94,&ops,scratch,2048,&done)==1 && done==0);
    assert(gwir_fj_play(&st,95,&ops,scratch,7,&done)==-4 && ir.sent==0);
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==0 && done==5);
    assert(ir.sent==5 && ir.total_pulses==40);
    ir.sent=0;ir.revoke_after=2;
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==-6 && done==2 && ir.sent==2);
    ir.revoke_after=-1;
    ir.sent=0;ir.total_pulses=0;ir.fail_at=2;
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==-5 && done==2);
    ir.fail_at=-1;ir.sent=0;
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==0 && done==5);
    assert(gwir_fj_open(&boot,&io)==0);
    ir.sent=0;
    assert(gwir_fj_play(&boot,95,&ops,scratch,2048,&done)==0 && done==5);
    assert(gwir_fj_play(&boot,96,&ops,scratch,2048,&done)==-1 && done==0);
    assert(gwir_fj_play(&boot,95,&ops,NULL,0,&done)==-1 && done==0);
    uint32_t live=boot.entry[95].offset;
    c.mem[live+40]^=1u;
    ir.sent=0;
    assert(gwir_fj_play(&boot,95,&ops,scratch,2048,&done)==-3 && done==0 && ir.sent==0);
    c.mem[live+40]^=1u;
    c.fail_reads=1;
    assert(gwir_fj_play(&boot,95,&ops,scratch,2048,&done)==-2 && done==0);
    c.fail_reads=0;
    /* New maximum-size persisted record: all 5 x 2048 timings on button 95. */
    build(95,2048,5);
    assert(gwir_fj_put(&boot,95,source,NULL,length)==0);
    assert(gwir_fj_open(&st,&io)==0);
    ir.sent=0;ir.total_pulses=0;
    assert(gwir_fj_play(&st,95,&ops,scratch,2047,&done)==-4 && done==0 && ir.sent==0);
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==0 && done==5);
    assert(ir.sent==5 && ir.total_pulses==10240u);
    assert(gwir_fj_delete(&st,95)==0);
    ir.sent=0;
    assert(gwir_fj_play(&st,95,&ops,scratch,2048,&done)==1 && done==0);
    free(c.mem);
    puts("PASS CP28: 5-frame playback at button 95 and 5x2048 maximum, reboot, revocation, denied hardware, missing/invalid/CRC/I-O/TX, delete");
    return 0;
}
