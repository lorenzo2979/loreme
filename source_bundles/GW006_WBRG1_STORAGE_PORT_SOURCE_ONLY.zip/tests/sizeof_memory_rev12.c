#include <stdio.h>
#include "gwir_engine.h"
#include "gwir_auth.h"
#include "gwir_amebad_bus.h"
#include "gwir_amebad_rx_fifo.h"
int main(void){printf("gwir_engine=%zu\ngwir_amebad_bus=%zu\ngwir_auth_session=%zu\ngwir_amebad_rx_queue=%zu\n",sizeof(gwir_engine),sizeof(gwir_amebad_bus),sizeof(gwir_auth_session),sizeof(gwir_amebad_rx_queue));}
