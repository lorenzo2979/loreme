#include "../firmware/core/gwir_sta_gate.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
int main(void)
{
    uint32_t ip = 0xfeedcafeu, expected;
    gwir_sta_snapshot s = {1, 1, 1, 1, {192,168,1,57}};
    uint8_t good[] = {192,168,1,57};
    memcpy(&expected, good, 4);
    assert(gwir_sta_gate_ip(&s, &ip) && ip == expected);
    assert(gwir_sta_gate_match(&s,expected));
    assert(!gwir_sta_gate_match(&s,0));
    s.sta_only=0;assert(!gwir_sta_gate_ip(&s,&ip));
    s.sta_only=1;s.associated=0;assert(!gwir_sta_gate_ip(&s,&ip));
    s.associated=1;s.netif_up=0;assert(!gwir_sta_gate_ip(&s,&ip));
    s.netif_up=1;s.link_up=0;assert(!gwir_sta_gate_ip(&s,&ip));
    s.link_up=1;
    s.ipv4[0]=0;assert(!gwir_sta_gate_ip(&s,&ip));
    s.ipv4[0]=127;assert(!gwir_sta_gate_ip(&s,&ip));
    s.ipv4[0]=224;assert(!gwir_sta_gate_ip(&s,&ip));
    s.ipv4[0]=255;assert(!gwir_sta_gate_ip(&s,&ip));
    s.ipv4[0]=169;s.ipv4[1]=254;assert(!gwir_sta_gate_ip(&s,&ip));
    s.ipv4[0]=10;s.ipv4[1]=0;s.ipv4[2]=0;s.ipv4[3]=2;
    assert(gwir_sta_gate_ip(&s,&ip));
    assert(!gwir_sta_gate_ip(NULL,&ip));
    assert(!gwir_sta_gate_ip(&s,NULL));
    puts("PASS CP15: STA-only, association/link/IP fail-closed gating");
    return 0;
}
