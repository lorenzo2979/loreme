#include "gwir_dashboard_http.h"
#include "gwir_dashboard_asset.h"
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static uint8_t output[16384];
static size_t used;
static int fail_writer;
static int short_writer(void *unused, const uint8_t *data, size_t len)
{
    size_t take = len > 7 ? 7 : len;
    (void)unused;
    if (fail_writer) return 0;
    if (used + take > sizeof(output)) return -1;
    memcpy(output + used, data, take);
    used += take;
    return (int)take;
}
static int send_one(const char *request, int step)
{
    gwir_dash_http_connection state;
    size_t i, size = strlen(request);
    int status = 0;
    gwir_dash_http_init(&state);
    for (i = 0; i < size; i += (size_t)step) {
        size_t n = (size_t)step;
        if (n > size - i) n = size - i;
        status = gwir_dash_http_feed(&state, (const uint8_t*)request + i, n);
        if (status < 0) return status;
        if (status == 1 && i + n != size) return -1;
    }
    if (status != 1) return -1;
    used = 0;
    return gwir_dash_http_respond(&state, short_writer, 0);
}
static size_t body_pos(void)
{
    size_t i;
    for (i = 0; i + 3 < used; i++)
        if (!memcmp(output + i, "\r\n\r\n", 4)) return i + 4;
    return 0;
}
static void check_page(void)
{
    size_t at = body_pos();
    char content_length[80];
    assert(at && at < used);
    assert(!memcmp(output, "HTTP/1.1 200 OK\r\n", 17));
    assert(strstr((char*)output, "Content-Encoding: gzip\r\n") != NULL);
    assert(strstr((char*)output, "Cache-Control: no-store\r\n") != NULL);
    assert(strstr((char*)output, "script-src 'sha256-") != NULL);
    assert(strstr((char*)output, "connect-src 'none'") != NULL);
    assert(strstr((char*)output, "Connection: close\r\n") != NULL);
    assert(at + gwir_dashboard_gzip_len == used);
    assert(!memcmp(output + at, gwir_dashboard_gzip_html, gwir_dashboard_gzip_len));
    (void)snprintf(content_length, sizeof(content_length), "Content-Length: %lu\r\n", (unsigned long)gwir_dashboard_gzip_len);
    assert(strstr((char*)output, content_length) != NULL);
}
static void exercise_socket(void)
{
    int sv[2];
    uint8_t read_buf[16384];
    size_t read_size = 0;
    ssize_t got;
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == 0);
    assert(send_one("GET / HTTP/1.1\r\nHost: gw006\r\n\r\n", 1) == 0);
    assert(write(sv[0], output, used) == (ssize_t)used);
    close(sv[0]);
    while ((got = read(sv[1], read_buf + read_size, sizeof(read_buf) - read_size)) > 0) {
        read_size += (size_t)got;
        assert(read_size < sizeof(read_buf));
    }
    close(sv[1]);
    assert(read_size == used && !memcmp(read_buf, output, used));
}
int main(void)
{
    const char *req = "GET / HTTP/1.1\r\nHost: gw006.local\r\nAccept: text/html\r\n\r\n";
    const char *head = "HEAD / HTTP/1.1\r\nHost: gw006\r\n\r\n";
    gwir_dash_http_connection c;
    int i;
    assert(gwir_dashboard_gzip_len < 6144u); /* flash budget for static asset */
    for(i=1;i<=25;i++) {
        assert(send_one(req,i) == 0);
        check_page();
    }
    assert(send_one("GET /index.html HTTP/1.0\r\n\r\n", 17) == 0);
    check_page();
    assert(send_one(head, 2) == 0);
    assert(body_pos() == used);
    assert(send_one("GET /private HTTP/1.1\r\nHost: gw006\r\n\r\n", 2) == 0);
    assert(!memcmp(output, "HTTP/1.1 404", 12));
    assert(send_one("POST /api/ir HTTP/1.1\r\nHost: gw006\r\n\r\n", 3) == 0);
    assert(!memcmp(output, "HTTP/1.1 405", 12));
    assert(send_one("GET / HTTP/1.1\r\nHost: gw006\r\nContent-Length: 0\r\n\r\n", 3) == 0);
    assert(!memcmp(output, "HTTP/1.1 400", 12));
    assert(send_one("GET / HTTP/1.1\r\nHost: gw006\r\nHost: other\r\n\r\n", 5) == 0);
    assert(!memcmp(output, "HTTP/1.1 400", 12));
    assert(send_one("GET / HTTP/1.1\r\nHost: \r\n\r\n", 5) == 0);
    assert(!memcmp(output, "HTTP/1.1 400", 12));
    assert(send_one("GET / HTTP/1.1\r\n\r\n", 5) == 0);
    assert(!memcmp(output, "HTTP/1.1 400", 12));
    assert(send_one("GET / HTTP/1.1\r\nHost: gw006\r\n\r\nGET / HTTP/1.1\r\n", 256) == -1);
    assert(send_one("GET / HTTP/1.1\nHost: gw006\r\n\r\n", 11) == -1);
    gwir_dash_http_init(&c);
    {uint8_t large[1050]; memset(large,'A',sizeof large); assert(gwir_dash_http_feed(&c,large,sizeof large) == -1);}
    fail_writer=1;
    assert(send_one(req,13) == -1);
    fail_writer=0;
    exercise_socket();
    puts("PASS CP13 dashboard: static gzip, 96-button UI asset, 25 fragmentations, strict read-only methods, CSP, partial writes and real socketpair");
    return 0;
}
