/* Compile-only declarations for freestanding ARM source syntax check.
 * Not for linking, flashing or SDK integration. */
#ifndef GWIR_ARM_STRING_ONLY_H
#define GWIR_ARM_STRING_ONLY_H
#include <stddef.h>
void *memcpy(void *, const void *, size_t);
void *memset(void *, int, size_t);
int memcmp(const void *, const void *, size_t);
#endif
