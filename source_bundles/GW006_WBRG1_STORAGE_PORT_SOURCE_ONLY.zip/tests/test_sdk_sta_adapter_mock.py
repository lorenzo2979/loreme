#!/usr/bin/env python3
"""Compilation guard for opt-in REALTEK task adapter (mock headers ONLY)."""
from pathlib import Path
import subprocess
import tempfile
root = Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix="gwir_sta_adapter_") as td:
    cmd = ["cc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-pedantic",
           "-DGWIR_ENABLE_STA_DASHBOARD_TRIAL=1", "-DGWIR_USE_LWIP=1",
           "-I"+str(root/"tests/stubs_sta"),
           "-I"+str(root/"firmware/core"),
           "-I"+str(root/"firmware/realtek"),
           "-c", str(root/"firmware/sdk/gwir_sdk_sta_dashboard.c"),
           "-o", str(Path(td)/"sta.o")]
    subprocess.run(cmd, check=True)
print("PASS CP15: opt-in Realtek STA task adapter compiles against vendor-API mock")
