#ifndef GWIR_STA_SDK_TEST_LWIP_NETIF_H
#define GWIR_STA_SDK_TEST_LWIP_NETIF_H
struct netif {int mock;};
int netif_is_up(struct netif *n);
int netif_is_link_up(struct netif *n);
#endif
