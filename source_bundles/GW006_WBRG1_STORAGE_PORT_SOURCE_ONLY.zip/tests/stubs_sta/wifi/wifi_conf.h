#ifndef GWIR_STA_SDK_TEST_WIFI_CONF_H
#define GWIR_STA_SDK_TEST_WIFI_CONF_H
typedef enum { RTW_MODE_STA=1, RTW_MODE_AP=2, RTW_MODE_STA_AP=3 } rtw_mode_t;
#define RTW_SUCCESS 0
int wifi_is_connected_to_ap(void);
#endif
