#ifndef GWIR_STA_SDK_TEST_AMEBA_SOC_H
#define GWIR_STA_SDK_TEST_AMEBA_SOC_H
#include <stdint.h>
typedef uint32_t TickType_t;
#define portTICK_PERIOD_MS 1u
#define tskIDLE_PRIORITY 0u
#define pdPASS 1
int xTaskCreate(void (*fn)(void *), const char *name, unsigned stack,
                void *context, unsigned priority, void *handle);
void vTaskDelay(TickType_t ticks);
void vTaskDelete(void *handle);
#endif
