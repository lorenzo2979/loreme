#ifndef GWIR_STA_SDK_TEST_LWIP_NETCONF_H
#define GWIR_STA_SDK_TEST_LWIP_NETCONF_H
#include "lwip/netif.h"
#include <stdint.h>
extern struct netif xnetif[];
uint8_t *LwIP_GetIP(struct netif *netif);
#endif
