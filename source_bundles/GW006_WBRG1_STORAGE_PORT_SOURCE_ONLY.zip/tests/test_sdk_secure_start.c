/* CP35: all trust providers in this file are HOST MOCKS, never GW006 ports. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/sdk/gwir_sdk_secure_start.h"

static unsigned call_id, started, cleared, inited, delivery, freshness;
static int fail_at, good_trust=1, task_result;
static uint8_t key_in[GWIR_AUTH_KEY_BYTES], nonce_in[GWIR_AUTH_NONCE_BYTES];
static uint8_t seen_key[GWIR_AUTH_KEY_BYTES], seen_nonce[GWIR_AUTH_NONCE_BYTES];

static int trust(void *ctx) { (void)ctx; call_id=1; return good_trust; }
static int load_key(void *ctx, uint8_t key[GWIR_AUTH_KEY_BYTES]) {
    (void)ctx; assert(call_id==1);call_id=2;
    memcpy(key,key_in,sizeof(key_in));
    return fail_at==2?-1:0;
}
static int fresh(void *ctx,uint8_t nonce[GWIR_AUTH_NONCE_BYTES]){
    (void)ctx; assert(call_id==2); call_id=3;
    memcpy(nonce,nonce_in,sizeof(nonce_in));
    return fail_at==3?-1:0;
}
static int attest_nonce(void *ctx,const uint8_t nonce[GWIR_AUTH_NONCE_BYTES]){
    (void)ctx; assert(call_id==3);call_id=4; freshness++;
    assert(!memcmp(nonce,nonce_in,sizeof(nonce_in)));
    return fail_at==4?0:1;
}
static int deliver(void *ctx,const uint8_t nonce[GWIR_AUTH_NONCE_BYTES]){
    (void)ctx; assert(call_id==5);call_id=6; delivery++;
    assert(!memcmp(nonce,nonce_in,sizeof(nonce_in)));
    return fail_at==6?-1:0;
}
static int hmac_stub(void *ctx,const uint8_t *k,size_t kl,const uint8_t *d,size_t dl,uint8_t *out){
    (void)ctx;(void)k;(void)kl;(void)d;(void)dl;(void)out;return 0;
}
int gwir_runtime_owner_init(gwir_runtime_owner *o,gwir_engine *engine,gwir_saved_play_service *saved,
    const uint8_t key[GWIR_AUTH_KEY_BYTES],const uint8_t nonce[GWIR_AUTH_NONCE_BYTES],
    gwir_auth_hmac_fn hmac,void *ctx,uint8_t *scratch,size_t sc,uint8_t *resp,size_t rc){
    (void)saved;(void)ctx;(void)scratch;(void)sc;(void)resp;(void)rc;
    assert(o && !o->initialized && engine && hmac && call_id==4);
    call_id=5;inited++;memcpy(seen_key,key,sizeof(seen_key));memcpy(seen_nonce,nonce,sizeof(seen_nonce));
    if (fail_at==5 || key[0]==0 || nonce[0]==0) return -1;
    o->initialized=1;return 0;
}
void gwir_runtime_owner_clear(gwir_runtime_owner *o){cleared++;memset(o,0,sizeof(*o));}
int gwir_sdk_auth_task_start(gwir_runtime_owner *o,uint16_t port){
    assert(o && o->initialized && call_id==6 && port==32444); started++;
    return task_result;
}
static gwir_sdk_secure_provider provider={trust,load_key,fresh,attest_nonce,deliver,NULL};
static void reset(void){
    call_id=0;started=cleared=inited=delivery=freshness=0;fail_at=0;good_trust=1;task_result=0;
    memset(seen_key,0,sizeof(seen_key));memset(seen_nonce,0,sizeof(seen_nonce));
    memset(key_in,0x42,sizeof(key_in));memset(nonce_in,0x25,sizeof(nonce_in));
}
static int execute(gwir_runtime_owner *o,const gwir_sdk_secure_provider *p){
    uint8_t scratch[16]={0},response[16]={0};
    return gwir_sdk_secure_start(p,o,(gwir_engine*)scratch,NULL,hmac_stub,NULL,
                                 scratch,sizeof(scratch),response,sizeof(response),32444);
}
int main(void){
    gwir_runtime_owner owner={0};
    reset();assert(execute(&owner,NULL)<0 && call_id==0 && !started);
    reset();good_trust=0;assert(execute(&owner,&provider)<0 && call_id==1 && !inited);
    for (int f=2;f<=6;f++){
        reset();fail_at=f;assert(execute(&owner,&provider)<0);
        assert(started==0 && !owner.initialized);
        assert(cleared==(f==6));
        assert(inited==(unsigned)(f>=5));
    }
    reset();task_result=-2;assert(execute(&owner,&provider)<0);
    assert(started==1 && cleared==1 && !owner.initialized);
    reset();assert(execute(&owner,&provider)==0);
    assert(started==1 && !cleared && owner.initialized);
    assert(!memcmp(seen_key,key_in,sizeof(key_in)));
    assert(!memcmp(seen_nonce,nonce_in,sizeof(nonce_in)));
    reset();assert(execute(&owner,&provider)<0 && !started && !inited); /* no reinit */
    gwir_runtime_owner_clear(&owner);
    reset();gwir_sdk_secure_provider invalid=provider;invalid.nonce_freshness_verified=NULL;
    assert(execute(&owner,&invalid)<0 && !started);
    puts("PASS CP35 secure startup: missing trust / partial credentials / freshness / nonce channel / task failure all deny, no fallback or hardcoded key");
    return 0;
}
