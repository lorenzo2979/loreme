#include "gwir_auth_stream.h"
#include <openssl/hmac.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint8_t key[32], nonce[16];
static gwir_auth_session phone_tx, phone_rx, device_rx, device_tx;
static gwir_auth_stream stream;
static gwir_engine engine;
static uint8_t scratch[GWIR_MAX_MESSAGE], response[GWIR_AUTH_MAX_PACKET];
static uint8_t outgoing[GWIR_AUTH_MAX_PACKET];
static size_t outgoing_size;
static unsigned tx_count, send_count, fail_send;

static int hmac(void *ctx, const uint8_t *k, size_t kl, const uint8_t *data,
                size_t n, uint8_t out[32])
{
    unsigned int written = 0u;
    (void)ctx;
    return HMAC(EVP_sha256(), k, (int)kl, data, n, out, &written) == NULL || written != 32u;
}
static int tx(void *ctx, uint32_t hz, uint16_t duty,
              const uint32_t *durations, uint16_t n, uint32_t gap)
{
    (void)ctx;
    (void)gap;
    assert(hz == 38000u && duty == 333u && n >= 2u);
    assert(durations[0] == 9000u && durations[1] == 4500u);
    ++tx_count;
    return 0;
}
static int send_record(void *ctx, const uint8_t *bytes, size_t n)
{
    (void)ctx;
    if (fail_send || n > sizeof(outgoing)) return -1;
    memcpy(outgoing, bytes, n);
    outgoing_size = n;
    ++send_count;
    return 0;
}
static void setup(void)
{
    gwir_ir_hal hal = {0};
    for (size_t i=0u; i<32u; ++i) key[i]=(uint8_t)(i+1u);
    for (size_t i=0u; i<16u; ++i) nonce[i]=(uint8_t)(0xA0u+i);
    assert(gwir_auth_init(&phone_tx,key,nonce,hmac,NULL)==0);
    assert(gwir_auth_init(&phone_rx,key,nonce,hmac,NULL)==0);
    assert(gwir_auth_init(&device_rx,key,nonce,hmac,NULL)==0);
    assert(gwir_auth_init(&device_tx,key,nonce,hmac,NULL)==0);
    hal.tx = tx;
    gwir_engine_init(&engine,hal);
    gwir_auth_stream_init(&stream);
    outgoing_size=0u; tx_count=0u; send_count=0u; fail_send=0u;
}
static size_t request(uint8_t *out, uint8_t command, uint32_t seq,
                      const uint8_t *payload, uint32_t plen)
{
    static uint8_t inner[GWIR_MAX_MESSAGE];
    size_t n=0u, total=0u;
    assert(gwir_encode(inner,sizeof(inner),command,seq,payload,plen,&n)==0);
    assert(gwir_auth_wrap(&phone_tx,GWIR_AUTH_TO_DEVICE,inner,n,out,
                          GWIR_AUTH_MAX_PACKET,&total)==0);
    return total;
}
static int feed(const uint8_t *bytes, size_t n)
{
    return gwir_auth_stream_feed(&stream, bytes,n, &device_rx,&device_tx,
                                 &engine,scratch,sizeof(scratch),
                                 response,sizeof(response),send_record,NULL);
}
static void check_reply(uint8_t command)
{
    const uint8_t *inner = NULL;
    size_t n=0u;
    gwir_message parsed;
    assert(gwir_auth_unwrap(&phone_rx,GWIR_AUTH_FROM_DEVICE,outgoing,
                            outgoing_size,&inner,&n)==0);
    assert(gwir_decode(inner,n,&parsed)==0);
    assert(parsed.command==command);
}
int main(void)
{
    static uint8_t packet[GWIR_AUTH_MAX_PACKET], packet2[GWIR_AUTH_MAX_PACKET];
    size_t n,n2;
    uint8_t payload[20] = {0};
    setup();
    n=request(packet,GWIR_PING,7u,NULL,0u);
    /* All fragments, including inside the authentication header and tag. */
    for (size_t i=0u; i<n; ++i)
        assert(feed(packet+i,1u)==(i+1u==n ? 1 : 0));
    assert(stream.packets_ok==1u && send_count==1u && tx_count==0u);
    check_reply(GWIR_PONG);
    assert(feed(NULL,0)==0);

    /* Coalesced authenticated records; server replies separately, without
     * bypassing HMAC or accepting an unsigned GWIR message. */
    n=request(packet,GWIR_PING,8u,NULL,0u);
    n2=request(packet2,GWIR_PING,9u,NULL,0u);
    static uint8_t joined[2u*GWIR_AUTH_MAX_PACKET];
    memcpy(joined,packet,n);memcpy(joined+n,packet2,n2);
    assert(feed(joined,n+n2)==2);
    assert(stream.packets_ok==3u && send_count==3u);
    check_reply(GWIR_PONG);
    assert(feed(packet,n)<0 && stream.failed);
    assert(stream.packets_invalid==1u);
    assert(feed(packet2,n2)<0);

    /* Malformed header/length fails before dispatch and can never arm IR. */
    setup();
    n=request(packet,GWIR_PING,1u,NULL,0u);
    packet[5]=GWIR_AUTH_FROM_DEVICE;
    assert(feed(packet,8u)<0 && tx_count==0u);
    setup();
    n=request(packet,GWIR_PING,1u,NULL,0u);
    gwir_write_u32be(packet+32,GWIR_MAX_MESSAGE+1u);
    assert(feed(packet,GWIR_AUTH_HEADER_BYTES)<0 && tx_count==0u);
    setup();
    n=request(packet,GWIR_PING,1u,NULL,0u);
    packet[n-1u]^=1u;
    assert(feed(packet,n)<0 && send_count==0u);
    setup();
    n=request(packet,GWIR_PING,1u,NULL,0u);
    packet[8u]^=1u;
    assert(feed(packet,GWIR_AUTH_HEADER_BYTES)<0);
    setup();
    n=request(packet,GWIR_PING,1u,NULL,0u);
    assert(feed(packet,4u)==0);
    gwir_auth_stream_discard(&stream);
    assert(stream.failed && stream.filled==0u && stream.expected==0u);
    for (size_t i=0;i<sizeof(stream.buffer);++i) assert(stream.buffer[i]==0u);

    /* One authenticated TX, tampered and repeated records must NEVER transmit. */
    setup();
    gwir_write_u32be(payload,38000u);
    gwir_write_u16be(payload+4,333u);
    gwir_write_u16be(payload+6,2u);
    gwir_write_u32be(payload+8,0u);
    gwir_write_u32be(payload+12,9000u);
    gwir_write_u32be(payload+16,4500u);
    n=request(packet,GWIR_TX_FRAME,22u,payload,sizeof(payload));
    memcpy(packet2,packet,n);packet2[n-1u]^=0x80u;
    assert(feed(packet2,n)<0 && tx_count==0u);
    setup();
    n=request(packet,GWIR_TX_FRAME,22u,payload,sizeof(payload));
    assert(feed(packet,n)==1 && tx_count==1u);
    check_reply(GWIR_STATUS);
    assert(feed(packet,n)<0 && tx_count==1u);

    /* Failure to write a signed response closes the session: no subsequent
     * packets may trigger a second transmit without a fresh session. */
    setup();
    n=request(packet,GWIR_TX_FRAME,23u,payload,sizeof(payload));
    fail_send=1u;
    assert(feed(packet,n)<0 && tx_count==1u && stream.failed);
    assert(feed(packet,n)<0 && tx_count==1u);

    /* Maximum 2,048-duration frame, ensure bounded parser buffers. */
    setup();
    static uint8_t max_payload[GWIR_FRAME_FIXED_BYTES+GWIR_MAX_PULSES_PER_FRAME*4u];
    gwir_write_u32be(max_payload,38000u);
    gwir_write_u16be(max_payload+4,333u);
    gwir_write_u16be(max_payload+6,GWIR_MAX_PULSES_PER_FRAME);
    gwir_write_u32be(max_payload+8,0u);
    for (unsigned i=0u;i<GWIR_MAX_PULSES_PER_FRAME;++i)
        gwir_write_u32be(max_payload+12u+(size_t)i*4u,i==0u ? 9000u : (i==1u ? 4500u : 560u));
    n=request(packet,GWIR_TX_FRAME,24u,max_payload,sizeof(max_payload));
    assert(n==GWIR_AUTH_MAX_PACKET - (GWIR_RX_FIXED_BYTES - GWIR_FRAME_FIXED_BYTES));
    for(size_t offset=0;offset<n;) {
        size_t chunk=(offset%103u)+1u;
        if(chunk>n-offset)chunk=n-offset;
        int result=feed(packet+offset,chunk);
        assert(result==(offset+chunk==n ? 1 : 0));
        offset+=chunk;
    }
    assert(tx_count==1u && stream.packets_ok==1u && !stream.failed);
    check_reply(GWIR_STATUS);
    puts("PASS GWAS TCP framing: 1-byte/large/coalesced, HMAC, anti-replay, tamper, fail closed");
    return 0;
}
