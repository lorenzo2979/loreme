/* Host POSIX TCP integration of signed GWAS framing, NOT an embedded listener.
 * Uses an ephemeral 127.0.0.1 port. All auth keys are test vectors only. */
#define _POSIX_C_SOURCE 200809L
#include "gwir_auth_stream.h"
#include <openssl/hmac.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

static uint8_t scratch[GWIR_MAX_MESSAGE], reply[GWIR_AUTH_MAX_PACKET];
static uint8_t message[GWIR_AUTH_MAX_PACKET], received[GWIR_AUTH_MAX_PACKET];
static gwir_auth_session phone_tx,phone_rx,device_rx,device_tx;
static gwir_engine engine;
static gwir_auth_stream server_stream;
static unsigned ir_tx_count=0u;
static int socket_for_reply=-1;

static int hmac(void *ctx,const uint8_t *key,size_t key_len,
                const uint8_t *data,size_t len,uint8_t out[GWIR_AUTH_TAG_BYTES])
{
    unsigned int n=0u;
    (void)ctx;
    return HMAC(EVP_sha256(),key,(int)key_len,data,len,out,&n)==NULL || n!=32u;
}
static int ir_tx(void *ctx,uint32_t carrier,uint16_t duty,
                 const uint32_t *pulses,uint16_t count,uint32_t gap)
{
    (void)ctx;(void)gap;
    assert(carrier==38000u && duty==333u && count==2u);
    assert(pulses[0]==9000u && pulses[1]==4500u);
    ++ir_tx_count;
    return 0;
}
static int send_bounded(void *ctx,const uint8_t *bytes,size_t size)
{
    size_t i=0u;
    (void)ctx;
    while(i<size) {
        size_t want=size-i;
        if(want>5u)want=5u;
        ssize_t n=send(socket_for_reply,bytes+i,want,0);
        if(n<=0 || (size_t)n>want)return -1;
        i+=(size_t)n;
    }
    return 0;
}
static int listener(void)
{
    int fd=socket(AF_INET,SOCK_STREAM,0);
    struct sockaddr_in addr={0};
    assert(fd>=0);
    addr.sin_family=AF_INET;addr.sin_port=htons(0);
    addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
    assert(bind(fd,(struct sockaddr *)&addr,sizeof(addr))==0);
    assert(listen(fd,1)==0);
    return fd;
}
static size_t signed_tx(void)
{
    static uint8_t inner[GWIR_MAX_MESSAGE];
    uint8_t payload[20]={0};
    size_t n=0u,out_len=0u;
    gwir_write_u32be(payload,38000u);
    gwir_write_u16be(payload+4,333u);
    gwir_write_u16be(payload+6,2u);
    gwir_write_u32be(payload+12,9000u);
    gwir_write_u32be(payload+16,4500u);
    assert(gwir_encode(inner,sizeof(inner),GWIR_TX_FRAME,23u,payload,sizeof(payload),&n)==0);
    assert(gwir_auth_wrap(&phone_tx,GWIR_AUTH_TO_DEVICE,inner,n,
                          message,sizeof(message),&out_len)==0);
    return out_len;
}
static int send_fragments(int fd,const uint8_t *bytes,size_t n)
{
    size_t off=0u;
    while(off<n) {
        size_t cap=n-off;
        if(cap>7u)cap=7u;
        ssize_t got=send(fd,bytes+off,cap,0);
        if(got<=0 || (size_t)got>cap)return -1;
        off+=(size_t)got;
    }
    return 0;
}
static void service_one(int server,size_t want,int success)
{
    size_t done=0u;
    unsigned replied=0u;
    socket_for_reply=accept(server,NULL,NULL);
    assert(socket_for_reply>=0);
    while(done<want) {
        uint8_t chunk[5];
        ssize_t got=recv(socket_for_reply,chunk,sizeof(chunk),0);
        assert(got>0 && (size_t)got<=want-done);
        int result=gwir_auth_stream_feed(&server_stream,chunk,(size_t)got,
                    &device_rx,&device_tx,&engine,scratch,sizeof(scratch),
                    reply,sizeof(reply),send_bounded,NULL);
        done+=(size_t)got;
        if(result<0) {
            assert(!success);
            break;
        }
        if(result==1) { assert(success); ++replied; }
    }
    assert(replied==(unsigned)success);
    close(socket_for_reply);
    socket_for_reply=-1;
}
int main(void)
{
    uint8_t key[32],nonce[16];
    size_t count=0u,received_size=0u;
    for(size_t i=0u;i<sizeof(key);++i)key[i]=(uint8_t)(i+1u);
    for(size_t i=0u;i<sizeof(nonce);++i)nonce[i]=(uint8_t)(i+42u);
    assert(gwir_auth_init(&phone_tx,key,nonce,hmac,NULL)==0);
    assert(gwir_auth_init(&phone_rx,key,nonce,hmac,NULL)==0);
    assert(gwir_auth_init(&device_rx,key,nonce,hmac,NULL)==0);
    assert(gwir_auth_init(&device_tx,key,nonce,hmac,NULL)==0);
    gwir_ir_hal hal={0};hal.tx=ir_tx;
    gwir_engine_init(&engine,hal);
    gwir_auth_stream_init(&server_stream);
    int server=listener();
    struct sockaddr_in addr={0};socklen_t alen=sizeof(addr);
    assert(getsockname(server,(struct sockaddr *)&addr,&alen)==0);
    int client=socket(AF_INET,SOCK_STREAM,0);
    assert(client>=0 && connect(client,(struct sockaddr *)&addr,alen)==0);
    count=signed_tx();
    assert(send_fragments(client,message,count)==0);
    service_one(server,count,1);
    /* TCP reply can arrive as arbitrary fragments: read until GWAS record
     * length, never assume one recv == one message. */
    while(received_size<GWIR_AUTH_HEADER_BYTES) {
        ssize_t got=recv(client,received+received_size,5,0);
        assert(got>0);received_size+=(size_t)got;
    }
    size_t length=GWIR_AUTH_HEADER_BYTES+(size_t)gwir_read_u32be(received+32u)+GWIR_AUTH_TAG_BYTES;
    assert(length<=sizeof(received));
    while(received_size<length) {
        ssize_t got=recv(client,received+received_size,length-received_size,0);
        assert(got>0);received_size+=(size_t)got;
    }
    assert(ir_tx_count==1u);
    const uint8_t *inner=NULL;size_t n=0;
    assert(gwir_auth_unwrap(&phone_rx,GWIR_AUTH_FROM_DEVICE,received,length,&inner,&n)==0);
    gwir_message decoded;assert(gwir_decode(inner,n,&decoded)==0);
    assert(decoded.command==GWIR_STATUS && decoded.payload[0]==GWIR_OK);
    close(client);
    /* A replay on a second connection fails BEFORE IR; service state remains
     * globally per-boot rather than reset for each TCP socket. */
    gwir_auth_stream_init(&server_stream);
    client=socket(AF_INET,SOCK_STREAM,0);
    assert(client>=0 && connect(client,(struct sockaddr *)&addr,alen)==0);
    assert(send_fragments(client,message,count)==0);
    service_one(server,count,0);
    assert(ir_tx_count==1u && server_stream.failed);
    close(client);close(server);
    puts("PASS real TCP 127.0.0.1: signed IR request, fragmented I/O, signed reply, replay blocked");
    return 0;
}
