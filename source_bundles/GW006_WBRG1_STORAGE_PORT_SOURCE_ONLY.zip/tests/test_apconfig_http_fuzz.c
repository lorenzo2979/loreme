#include "gwir_apconfig_http.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* Deterministic parser stress: random bytes and mutations of valid requests.
   Intended for ASan/UBSan on host; never exercises a network listener. */
static uint32_t state = 0x91ac37deu;
static uint32_t rnd(void)
{
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
}
int main(void)
{
    uint8_t request[GWIR_APHTTP_REQUEST_MAX + 2u];
    gwir_station_profile profile;
    static const char good[] = "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n"
        "ssid=My+Router&password=12345678";
    for (unsigned iteration=0u;iteration<30000u;++iteration) {
        size_t len;
        if ((iteration & 1u) == 0u) {
            len = (size_t)(rnd() % sizeof(request));
            for (size_t i=0u;i<len;++i) request[i] = (uint8_t)rnd();
        } else {
            len = sizeof(good) - 1u;
            memcpy(request, good, len);
            unsigned edits = 1u + (unsigned)(rnd() % 8u);
            for (unsigned j=0u;j<edits;++j)
                request[rnd()%len] = (uint8_t)rnd();
            if ((iteration % 7u)==0u) len = rnd()%(len+1u);
        }
        memset(&profile, 0xa5, sizeof(profile));
        int rc = gwir_aphttp_parse(request, len, &profile);
        assert(rc == GWIR_APHTTP_OK || rc == GWIR_APHTTP_BAD_REQUEST);
        if (rc != GWIR_APHTTP_OK) {
            const uint8_t *p = (const uint8_t *)&profile;
            for (size_t j=0u;j<sizeof(profile);++j) assert(p[j] == 0u);
        }
        gwir_station_wipe(&profile);
    }
    puts("PASS REV19: 30,000 deterministic malformed HTTP parser stress inputs");
    return 0;
}
