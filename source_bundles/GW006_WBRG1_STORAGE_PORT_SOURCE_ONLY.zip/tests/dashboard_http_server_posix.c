/* HOST-ONLY one-shot dashboard socket server to verify real browser HTTP path.
 * NOT a Realtek/lwIP task. Never bind public interfaces. */
#define _POSIX_C_SOURCE 200809L
#include "gwir_dashboard_http.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>

static int write_tcp(void *ctx, const uint8_t *data, size_t count)
{
    int fd=*(int*)ctx;
    ssize_t n=send(fd,data,count,0);
    return n<=0?-1:(int)n;
}
int main(void)
{
    int srv=-1, cli=-1, ok=0;
    struct sockaddr_in a;
    socklen_t len=sizeof(a);
    struct timeval timeout={2,0};
    gwir_dash_http_connection conn;
    uint8_t input[32];
    ssize_t got;
    srv=socket(AF_INET,SOCK_STREAM,0);
    if(srv<0) return 2;
    memset(&a,0,sizeof(a)); a.sin_family=AF_INET;
    a.sin_addr.s_addr=htonl(INADDR_LOOPBACK); a.sin_port=0;
    if(bind(srv,(struct sockaddr*)&a,sizeof(a)) || listen(srv,1)) goto done;
    if(getsockname(srv,(struct sockaddr*)&a,&len)) goto done;
    printf("PORT=%u\n",(unsigned)ntohs(a.sin_port)); fflush(stdout);
    cli=accept(srv,NULL,NULL);
    if(cli<0) goto done;
    (void)setsockopt(cli,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    (void)setsockopt(cli,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    gwir_dash_http_init(&conn);
    while((got=recv(cli,input,sizeof(input),0))>0) {
        int status=gwir_dash_http_feed(&conn,input,(size_t)got);
        if(status<0) goto done;
        if(status==1) {ok=(gwir_dash_http_respond(&conn,write_tcp,&cli)==0);goto done;}
    }
done:
    if(cli>=0) close(cli);
    if(srv>=0) close(srv);
    return ok?0:1;
}
