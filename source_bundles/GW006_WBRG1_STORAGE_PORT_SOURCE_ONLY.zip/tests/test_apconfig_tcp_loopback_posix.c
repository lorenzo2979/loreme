#define _POSIX_C_SOURCE 200809L
#include "gwir_apconfig_tcp_transport.h"
#include <arpa/inet.h>
#include <assert.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

/* Host integration against ACTUAL kernel TCP loopback, NOT a Realtek/AP
 * implementation. The attestation flag represents a trusted AP-netif API
 * which is unavailable here; never use loopback as the proof on hardware. */
typedef struct {
    int listener, accepted, client;
    struct sockaddr_in address;
    int trusted, close_count, staged, verified, committed, rolled_back;
    int fail_verify;
} fixture;

static int wait_fd(int fd, short events, uint32_t deadline_ms)
{
    struct pollfd p = {fd, events, 0};
    int ret;
    do { ret = poll(&p, 1u, (int)deadline_ms); }
    while (ret < 0 && errno == EINTR);
    if (ret < 0) return -1;
    if (!ret) return 0;
    if (p.revents & (POLLERR | POLLNVAL)) return -1;
    return 1;
}
static int listening_ap(void *context)
{
    fixture *f = context;
    struct sockaddr_in local;
    socklen_t len = sizeof(local);
    if (!f->trusted || f->listener < 0 ||
        getsockname(f->listener, (struct sockaddr *)&local, &len) != 0)
        return 0;
    return local.sin_family == AF_INET &&
        local.sin_addr.s_addr == htonl(INADDR_LOOPBACK) &&
        local.sin_port == f->address.sin_port;
}
static int accept_one(void *context, uint32_t wait_ms)
{
    fixture *f = context;
    if (wait_fd(f->listener, POLLIN, wait_ms) != 1) return 0;
    f->accepted = accept(f->listener, NULL, NULL);
    return f->accepted < 0 ? -1 : 1;
}
static int client_ap(void *context)
{
    fixture *f = context;
    struct sockaddr_in local;
    socklen_t len = sizeof(local);
    if (!f->trusted || f->accepted < 0 ||
        getsockname(f->accepted, (struct sockaddr *)&local, &len) != 0)
        return 0;
    return local.sin_family == AF_INET &&
        local.sin_addr.s_addr == f->address.sin_addr.s_addr &&
        local.sin_port == f->address.sin_port;
}
static int recv_some(void *context, uint8_t *dest, size_t cap,
                     uint32_t wait_ms)
{
    fixture *f = context;
    ssize_t n;
    int ready = wait_fd(f->accepted, POLLIN, wait_ms);
    if (ready == 0) return -2;
    if (ready < 0) return -1;
    if (cap > 7u) cap = 7u; /* enforce many TCP receive fragments */
    n = recv(f->accepted, dest, cap, 0);
    return n < 0 ? -1 : (int)n;
}
static int send_some(void *context, const uint8_t *buf, size_t n,
                     uint32_t wait_ms)
{
    fixture *f = context;
    ssize_t sent;
    if (wait_fd(f->accepted, POLLOUT, wait_ms) != 1) return -1;
    if (n > 5u) n = 5u; /* force partial sends */
    sent = send(f->accepted, buf, n, 0);
    return sent > 0 ? (int)sent : -1;
}
static void close_client(void *context)
{
    fixture *f = context;
    f->close_count++;
    if (f->accepted >= 0) { close(f->accepted); f->accepted = -1; }
}
static uint32_t now_ms(void *unused)
{
    struct timespec ts;
    (void)unused;
    assert(clock_gettime(CLOCK_MONOTONIC, &ts) == 0);
    return (uint32_t)((uint64_t)ts.tv_sec * 1000u +
                      (uint64_t)ts.tv_nsec / 1000000u);
}
static int stage(void *ctx, const gwir_station_profile *profile)
{
    fixture *f = ctx;
    assert(strcmp(profile->wifi.ssid, "LAN-test") == 0);
    assert(strcmp(profile->wifi.password, "FakePass123") == 0);
    f->staged++;
    return 0;
}
static int verify(void *ctx)
{
    fixture *f = ctx;
    f->verified++;
    return f->fail_verify ? -1 : 0;
}
static int commit(void *ctx)
{
    fixture *f = ctx;
    f->committed++;
    return 0;
}
static void rollback(void *ctx) { ((fixture *)ctx)->rolled_back++; }

static void create_pair(fixture *f)
{
    socklen_t len;
    f->listener = socket(AF_INET, SOCK_STREAM, 0);
    assert(f->listener >= 0);
    memset(&f->address, 0, sizeof(f->address));
    f->address.sin_family = AF_INET;
    f->address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    f->address.sin_port = 0; /* OS-chosen ephemeral port, no LAN exposure */
    assert(bind(f->listener, (struct sockaddr *)&f->address,
                sizeof(f->address)) == 0);
    len = sizeof(f->address);
    assert(getsockname(f->listener,(struct sockaddr *)&f->address,&len) == 0);
    assert(listen(f->listener, 1) == 0);
    f->client = socket(AF_INET, SOCK_STREAM, 0);
    assert(f->client >= 0);
    assert(connect(f->client, (struct sockaddr *)&f->address,
                   sizeof(f->address)) == 0);
}
static void send_request(int fd, const char *request, size_t count)
{
    size_t pos = 0u;
    while (pos < count) {
        ssize_t n = send(fd, request + pos, count - pos, 0);
        assert(n > 0);
        pos += (size_t)n;
    }
    assert(shutdown(fd, SHUT_WR) == 0);
}
static size_t collect_response(int fd, char *dest, size_t cap)
{
    size_t n = 0u;
    while (n + 1u < cap) {
        int ready = wait_fd(fd, POLLIN, 1000u);
        ssize_t bytes;
        assert(ready == 1);
        bytes = recv(fd, dest + n, cap - n - 1u, 0);
        assert(bytes >= 0);
        if (bytes == 0) break;
        n += (size_t)bytes;
    }
    dest[n] = 0;
    return n;
}
static void run_case(const char *req, int expected_status, int fail_verify,
                     int trusted)
{
    char response[512];
    char prefix[32];
    fixture f = {0};
    gwir_aptcp_ops ops;
    gwir_apcfg_session session = {0};
    gwir_station_ops station;
    int result;
    f.listener = f.accepted = f.client = -1;
    f.trusted = trusted;
    f.fail_verify = fail_verify;
    session.wifi_started = 1u;
    session.provisioner_started = 1u;
    create_pair(&f);
    send_request(f.client, req, strlen(req));
    ops = (gwir_aptcp_ops){&f, listening_ap, accept_one, client_ap,
                           recv_some, send_some, close_client, now_ms};
    station = (gwir_station_ops){&f, stage, verify, commit, rollback};
    result = gwir_aptcp_serve_one(&ops, &session, &station);
    if (!trusted) {
        assert(result == GWIR_APTCP_UNAVAILABLE && f.close_count == 0);
    } else {
        assert(result == GWIR_APTCP_REPLIED);
        assert(f.close_count == 1);
        assert(collect_response(f.client, response, sizeof(response)) > 0);
        assert(snprintf(prefix, sizeof(prefix), "HTTP/1.1 %d ",
                        expected_status) > 0);
        assert(strncmp(response, prefix, strlen(prefix)) == 0);
        assert(strstr(response, "FakePass123") == NULL);
        if (expected_status == 204) {
            assert(f.staged == 1 && f.verified == 1 && f.committed == 1);
            assert(f.rolled_back == 0);
        } else if (expected_status == 503) {
            assert(f.staged == 1 && f.verified == 1 && f.committed == 0);
            assert(f.rolled_back == 1);
        } else {
            assert(f.staged == 0 && f.verified == 0 && f.committed == 0);
        }
    }
    close(f.client);
    close(f.listener);
}
int main(void)
{
    static const char body[] = "ssid=LAN-test&password=FakePass123";
    char request[512];
    int n = snprintf(request, sizeof(request),
         "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\n"
         "Content-Type: application/x-www-form-urlencoded\r\n"
         "Content-Length: %zu\r\nConnection: close\r\n\r\n%s",
         strlen(body), body);
    assert(n > 0 && (size_t)n < sizeof(request));
    run_case(request, 204, 0, 1);
    run_case(request, 503, 1, 1);
    run_case("GET /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\n\r\n",
             400, 0, 1);
    run_case(request, 0, 0, 0);
    puts("PASS: real POSIX TCP loopback, fragmented reads, partial writes, HTTP provisioning/rollback, rejected untrusted listener");
    return 0;
}
