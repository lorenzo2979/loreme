/* Host-only FreeRTOS startup bridge tests; all credentials are mock objects. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/sdk/gwir_sdk_bootstrap.h"
#include "task_stubs/ameba_soc.h"

static void (*pending_task)(void *);
static unsigned task_count, delete_count, polls, delays, starts;
static int task_ok = pdPASS;
static int connected_after = 2;
static int trust_check(void *ctx) { (void)ctx; return 1; }
static int load(void *ctx,uint8_t k[GWIR_AUTH_KEY_BYTES]) { (void)ctx; memset(k,1,GWIR_AUTH_KEY_BYTES); return 0; }
static int nonce(void *ctx,uint8_t n[GWIR_AUTH_NONCE_BYTES]) { (void)ctx; memset(n,2,GWIR_AUTH_NONCE_BYTES); return 0; }
static int fresh(void *ctx,const uint8_t n[GWIR_AUTH_NONCE_BYTES]) { (void)ctx;(void)n;return 1; }
static int deliver(void *ctx,const uint8_t n[GWIR_AUTH_NONCE_BYTES]) { (void)ctx;(void)n;return 0; }
static int hmac(void *ctx,const uint8_t *k,size_t n,const uint8_t *d,size_t m,uint8_t *out)
{ (void)ctx;(void)k;(void)n;(void)d;(void)m;(void)out;return 0; }
static gwir_runtime_owner owner;
static gwir_engine engine;
static uint8_t scratch[GWIR_MAX_MESSAGE];
static uint8_t response[GWIR_AUTH_MAX_PACKET];
static gwir_sdk_secure_provider provider={trust_check,load,nonce,fresh,deliver,NULL};
static gwir_sdk_boot_config config={&provider,&owner,&engine,NULL,hmac,NULL,scratch,sizeof(scratch),response,sizeof(response),32444,NULL,NULL};

int xTaskCreate(void (*fn)(void *),const char *name,unsigned stack,void *arg,unsigned prio,void *handle)
{
    (void)arg;(void)handle;
    assert(!strcmp(name,"GWIR-BOOT") && stack>=1024u && prio==1u);
    task_count++;
    if (task_ok==pdPASS) pending_task=fn;
    return task_ok;
}
void vTaskDelay(unsigned ticks) { assert(ticks>0u);delays++; }
void vTaskDelete(void *x) { assert(x==NULL);delete_count++; }
int gwir_sdk_auth_network_ready(void) { polls++;return connected_after>=0 && (int)polls>connected_after; }
/* The host bootstrap exercises linkage without enabling any physical IR. */
static int ir_init_calls;
int gwir_ir_pipeline_init(gwir_ir_pipeline *pipe,gwir_engine *eng,
                          const gwir_ir_pipeline_config *c)
{
    (void)pipe; (void)eng; (void)c;
    ++ir_init_calls;
    return -1; /* No verified hardware may pass the host mock. */
}
int gwir_sdk_auth_task_bind_ir_pipeline(gwir_ir_pipeline *p) { (void)p; return -1; }
int gwir_ir_pipeline_stop(gwir_ir_pipeline *p) { (void)p; return 0; }
int gwir_sdk_secure_start(const gwir_sdk_secure_provider *p,gwir_runtime_owner *o,
                         gwir_engine *e,gwir_saved_play_service *saved,
                         gwir_auth_hmac_fn fn,void *ctx,uint8_t *s,size_t sc,
                         uint8_t *r,size_t rc,uint16_t port)
{
    (void)saved;(void)ctx;
    assert(p==&provider && o==&owner && e==&engine && fn==hmac);
    assert(s==scratch && sc==sizeof(scratch));
    assert(r==response && rc==sizeof(response) && port==32444u);
    starts++;
    return -1; /* mock trusted port always refuses; never open a real TCP socket */
}

int main(int argc,char **argv)
{
    assert(argc==2);
    if (!strcmp(argv[1],"absent")) {
        assert(gwir_sdk_boot_schedule()==-1 && !task_count);
        assert(gwir_sdk_boot_register(&config)==-1); /* registration sealed */
    } else if (!strcmp(argv[1],"invalid")) {
        gwir_sdk_boot_config bad=config;
        bad.provider=NULL;
        assert(gwir_sdk_boot_register(&bad)==-1);
        bad=config; bad.port=80;
        assert(gwir_sdk_boot_register(&bad)==-1);
        bad=config; bad.scratch_capacity=1;
        assert(gwir_sdk_boot_register(&bad)==-1);
        assert(!task_count && !starts);
        bad=config; bad.ir_pipeline=(gwir_ir_pipeline *)&owner;
        assert(gwir_sdk_boot_register(&bad)==-1);
    } else if (!strcmp(argv[1],"success")) {
        assert(gwir_sdk_boot_register(&config)==0);
        assert(gwir_sdk_boot_register(&config)==-1);
        assert(gwir_sdk_boot_schedule()==0 && task_count==1);
        assert(gwir_sdk_boot_schedule()==-1 && task_count==1);
        assert(pending_task);
        pending_task(NULL);
        assert(polls==3 && delays==2 && starts==1 && delete_count==1);
    } else if (!strcmp(argv[1],"ir-refuse")) {
        config.ir_pipeline=(gwir_ir_pipeline *)&owner;
        config.ir_config=(const gwir_ir_pipeline_config *)&engine;
        connected_after=0;
        assert(gwir_sdk_boot_register(&config)==0);
        assert(gwir_sdk_boot_schedule()==0);
        pending_task(NULL);
        assert(ir_init_calls==1 && !starts && delete_count==1);
    } else if (!strcmp(argv[1],"offline")) {
        connected_after=-1;
        assert(gwir_sdk_boot_register(&config)==0);
        assert(gwir_sdk_boot_schedule()==0);
        pending_task(NULL);
        assert(polls==120 && delays==120 && !starts && delete_count==1);
    } else if (!strcmp(argv[1],"task-fail")) {
        task_ok=0;
        assert(gwir_sdk_boot_register(&config)==0);
        assert(gwir_sdk_boot_schedule()==-2 && task_count==1);
        assert(!starts && !pending_task);
    } else return 2;
    printf("PASS CP37 bootstrap host case %s (no board provisioning / no flash)\n",argv[1]);
    return 0;
}
