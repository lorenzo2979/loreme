#include "gwir_network_profile.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int stage_count, verify_count, commit_count, rollback_count;
static int reject_at;
static int stage(void *c, const gwir_station_profile *p)
{
    (void)c;
    stage_count++;
    assert(p && !strcmp(p->wifi.ssid, "Casa"));
    return reject_at == 1 ? -1 : 0;
}
static int verify(void *c)
{
    (void)c;
    verify_count++;
    return reject_at == 2 ? -1 : 0;
}
static int commit(void *c)
{
    (void)c;
    commit_count++;
    return reject_at == 3 ? -1 : 0;
}
static void rollback(void *c) { (void)c; rollback_count++; }
static int form(const char *s, gwir_station_profile *p)
{ return gwir_station_parse_form((const uint8_t *)s, strlen(s), p); }
int main(void)
{
    const char *valid = "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1&dns2=8.8.8.8";
    uint8_t ip[4] = {11u, 11u, 11u, 11u};
    gwir_station_profile p;
    gwir_station_ops ops = {NULL, stage, verify, commit, rollback};
    assert(gwir_ipv4_parse("192.168.1.100", ip) == 0 && ip[0] == 192u && ip[3] == 100u);
    const char *bad_ips[] = {"", ".1.2.3", "1.2.3", "1.2.3.4.5", "256.1.1.1", "01.2.3.400", "1..2.3", "1.2.3.-4", "1.2.3.4 ", "1.2.3.%34"};
    for (size_t i = 0; i < sizeof(bad_ips)/sizeof(bad_ips[0]); ++i)
        assert(gwir_ipv4_parse(bad_ips[i], ip) != 0);
    assert(form("ssid=Casa&password=supersecret", &p) == 0 && p.network.mode == GWIR_IP_DHCP);
    assert(form("ssid=Casa&password=supersecret&ip_mode=dhcp", &p) == 0);
    assert(form(valid, &p) == 0);
    assert(p.network.mode == GWIR_IP_STATIC && p.network.address[3] == 20u && p.network.dns2_present == 1u);
    assert(gwir_station_apply(&p, &ops) == 0);
    assert(stage_count == 1 && verify_count == 1 && commit_count == 1 && rollback_count == 0);
    for (int i = 1; i <= 3; ++i) {
        reject_at = i;
        int before = rollback_count;
        assert(gwir_station_apply(&p, &ops) < 0);
        assert(rollback_count == before + 1);
    }
    reject_at = 0;
    assert(form("ssid=Casa&password=&ip_mode=static&ip=10.0.0.20&mask=255.255.255.0&gateway=10.0.0.1&dns1=8.8.8.8", &p) == 0);
    const char *bad[] = {
        "ssid=Casa&password=x&ip_mode=dhcp", /* WPA pass too short */
        "ssid=Casa&password=supersecret&ip_mode=weird",
        "ssid=Casa&password=supersecret&ip_mode=dhcp&ip=1.2.3.4",
        "ssid=Casa&password=supersecret&ip_mode=static",
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.4.10&mask=255.255.255.0&gateway=192.168.4.1&dns1=1.1.1.1", /* AP overlap */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.64&gateway=192.168.1.1&dns1=1.1.1.1", /* non-contiguous */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.0&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1", /* network */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.255&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1", /* broadcast */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.2.1&dns1=1.1.1.1", /* gateway mismatch */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.20&dns1=1.1.1.1", /* gateway same IP */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=127.0.0.2&mask=255.0.0.0&gateway=127.0.0.1&dns1=1.1.1.1",
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=224.0.0.1", /* invalid dns */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.255&gateway=192.168.1.1&dns1=1.1.1.1", /* /32 */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=0.0.0.0&gateway=192.168.1.1&dns1=1.1.1.1", /* /0 */
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1&dns1=2.2.2.2",
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1&junk=3",
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.%31",
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1&",
        "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1&dns2=0.0.0.0"
    };
    for (size_t i = 0; i < sizeof(bad)/sizeof(bad[0]); ++i) {
        memset(&p, 0x5a, sizeof p);
        assert(form(bad[i], &p) < 0);
        const uint8_t *bytes = (const uint8_t *)&p;
        for (size_t j = 0; j < sizeof p; ++j) assert(bytes[j] == 0u);
    }
    assert(form("ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1", &p) == 0);
    p.network.mode = (gwir_ip_mode)77;
    assert(gwir_station_apply(&p, &ops) == -2);
    gwir_station_wipe(&p);
    puts("PASS REV17: DHCP/static parser, strict IPv4/mask/gateway/DNS, AP collision, rollback");
    return 0;
}
