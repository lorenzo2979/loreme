#include "gwir_apconfig_http.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static int stages, verifications, commits, rollbacks, fail_stage, fail_verify, fail_commit;
static int stage(void *ctx, const gwir_station_profile *p) {
    (void)ctx;
    ++stages;
    assert(strcmp(p->wifi.ssid, "My Router") == 0);
    assert(strcmp(p->wifi.password, "12345678") == 0);
    assert(p->network.mode == GWIR_IP_DHCP);
    return fail_stage ? -1 : 0;
}
static int verify(void *ctx) {(void)ctx; ++verifications; return fail_verify ? -1 : 0;}
static int commit(void *ctx) {(void)ctx; ++commits; return fail_commit ? -1 : 0;}
static void rollback(void *ctx) {(void)ctx; ++rollbacks;}
static void clear_counts(void) {stages=verifications=commits=rollbacks=0;fail_stage=fail_verify=fail_commit=0;}
static const char body[] = "ssid=My+Router&password=12345678";
static const char prefix[] = "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\n"
                             "Content-Type: application/x-www-form-urlencoded\r\n"
                             "Content-Length: 32\r\nConnection: close\r\n\r\n";
static void build(char *dst, size_t cap, const char *head, const char *data) {
    size_t n = strlen(head), m = strlen(data);
    assert(n+m+1u <= cap);
    memcpy(dst, head, n);
    memcpy(dst+n, data, m+1u);
}
static void must_reject(const char *wire) {
    gwir_station_profile out;
    memset(&out, 0xA5, sizeof(out));
    assert(gwir_aphttp_parse((const uint8_t *)wire, strlen(wire), &out) == GWIR_APHTTP_BAD_REQUEST);
    for (size_t i=0;i<sizeof(out);i++) assert(((const unsigned char *)&out)[i] == 0u);
}
static void test_http_parse(void) {
    char wire[GWIR_APHTTP_REQUEST_MAX + 64u];
    gwir_station_profile parsed;
    assert(strlen(body) == 32u);
    build(wire, sizeof(wire), prefix, body);
    assert(gwir_aphttp_parse((const uint8_t *)wire, strlen(wire), &parsed) == GWIR_APHTTP_OK);
    assert(strcmp(parsed.wifi.ssid, "My Router") == 0);
    assert(strcmp(parsed.wifi.password, "12345678") == 0);
    assert(parsed.network.mode == GWIR_IP_DHCP);
    gwir_station_wipe(&parsed);
    const char *broken_heads[] = {
        "GET /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision?admin=1 HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: evil.local\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/json\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 33\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 31\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 999999999999999999999999\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\nTransfer-Encoding: chunked\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\nExpect: 100-continue\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\nContent-Encoding: gzip\r\n\r\n",
        "POST /api/provision HTTP/1.1\r\nHost : 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n\r\n",
        "POST /api/provision HTTP/1.1\nHost: 192.168.4.1\nContent-Type: application/x-www-form-urlencoded\nContent-Length: 32\n\n",
        "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 32\r\n Bad: folded\r\n\r\n"
    };
    for (size_t i=0;i<sizeof(broken_heads)/sizeof(broken_heads[0]);i++) {
        build(wire, sizeof(wire), broken_heads[i], body);
        must_reject(wire);
    }
    build(wire, sizeof(wire), prefix, "ssid=My+Router&password=12345678&bad=2");
    must_reject(wire);
    build(wire, sizeof(wire), prefix, "ssid=My+Router&password=12345678");
    strcat(wire, "GET / HTTP/1.1\r\n\r\n");
    must_reject(wire);
    /* Case insensitive header names and media type; host port 80. */
    const char *alt = "POST /api/provision HTTP/1.1\r\nhOsT: 192.168.4.1:80\r\n"
                      "cOnTeNt-TyPe: APPLICATION/X-WWW-FORM-URLENCODED\r\n"
                      "CONTENT-LENGTH: 32\r\n\r\n";
    build(wire, sizeof(wire), alt, body);
    assert(gwir_aphttp_parse((const uint8_t *)wire, strlen(wire), &parsed) == GWIR_APHTTP_OK);
    /* Static IPv4 configuration is accepted through the same HTTP gate. */
    const char *static_body = "ssid=Casa&password=supersecret&ip_mode=static&ip=192.168.1.20&mask=255.255.255.0&gateway=192.168.1.1&dns1=1.1.1.1";
    char static_head[256];
    int head_n = snprintf(static_head, sizeof(static_head),
                          "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: %zu\r\n\r\n",
                          strlen(static_body));
    assert(head_n > 0 && (size_t)head_n < sizeof(static_head));
    build(wire, sizeof(wire), static_head, static_body);
    assert(gwir_aphttp_parse((const uint8_t *)wire, strlen(wire), &parsed) == GWIR_APHTTP_OK);
    assert(parsed.network.mode == GWIR_IP_STATIC && parsed.network.address[3] == 20u);
    assert(parsed.network.dns1[0] == 1u && parsed.network.dns1[3] == 1u);
    gwir_station_wipe(&parsed);
    /* Open home Wi-Fi is permitted; setup AP always has its own open policy. */
    const char *open_body = "ssid=Guest&password=";
    head_n = snprintf(static_head, sizeof(static_head),
                      "POST /api/provision HTTP/1.1\r\nHost: 192.168.4.1\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: %zu\r\n\r\n",
                      strlen(open_body));
    assert(head_n > 0 && (size_t)head_n < sizeof(static_head));
    build(wire, sizeof(wire), static_head, open_body);
    assert(gwir_aphttp_parse((const uint8_t *)wire, strlen(wire), &parsed) == GWIR_APHTTP_OK);
    assert(parsed.wifi.is_open == 1u && strcmp(parsed.wifi.ssid,"Guest") == 0);
    gwir_station_wipe(&parsed);
    /* Oversize request and NUL injection. */
    char oversized[GWIR_APHTTP_REQUEST_MAX + 2u];
    memset(oversized, 'A', sizeof(oversized));
    assert(gwir_aphttp_parse((const uint8_t *)oversized, sizeof(oversized), &parsed) == GWIR_APHTTP_BAD_REQUEST);
    build(wire, sizeof(wire), prefix, body);
    wire[5] = '\0';
    assert(gwir_aphttp_parse((const uint8_t *)wire, strlen(prefix)+strlen(body), &parsed) == GWIR_APHTTP_BAD_REQUEST);
}
static void test_gate_and_rollback(void) {
    gwir_apcfg_session session = {0};
    session.wifi_started = session.provisioner_started = 1u;
    gwir_station_ops ops = {NULL, stage, verify, commit, rollback};
    char wire[GWIR_APHTTP_REQUEST_MAX + 8u];
    build(wire, sizeof(wire), prefix, body);
    clear_counts();
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), NULL, 1, &ops) == GWIR_APHTTP_FORBIDDEN);
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), &session, 0, &ops) == GWIR_APHTTP_FORBIDDEN);
    session.provisioner_started = 0u;
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), &session, 1, &ops) == GWIR_APHTTP_FORBIDDEN);
    assert(stages == 0 && verifications == 0 && commits == 0);
    session.provisioner_started = 1u;
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), &session, 1, &ops) == GWIR_APHTTP_OK);
    assert(stages == 1 && verifications == 1 && commits == 1 && rollbacks == 0);
    clear_counts(); fail_stage = 1;
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), &session, 1, &ops) == GWIR_APHTTP_BACKEND_FAILURE);
    assert(stages == 1 && verifications == 0 && commits == 0 && rollbacks == 1);
    clear_counts(); fail_verify = 1;
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), &session, 1, &ops) == GWIR_APHTTP_BACKEND_FAILURE);
    assert(stages == 1 && verifications == 1 && commits == 0 && rollbacks == 1);
    clear_counts(); fail_commit = 1;
    assert(gwir_aphttp_apply((const uint8_t *)wire, strlen(wire), &session, 1, &ops) == GWIR_APHTTP_BACKEND_FAILURE);
    assert(stages == 1 && verifications == 1 && commits == 1 && rollbacks == 1);
}
int main(void) {
    test_http_parse();
    test_gate_and_rollback();
    puts("PASS REV19: bounded AP-only HTTP parser, rejects smuggling/malformed data, staged rollback");
    return 0;
}
