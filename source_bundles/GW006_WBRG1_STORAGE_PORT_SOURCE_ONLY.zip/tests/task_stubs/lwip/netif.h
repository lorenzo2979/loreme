#ifndef GWIR_CP33_TASK_NETIF_STUB_H
#define GWIR_CP33_TASK_NETIF_STUB_H
struct netif { int up, link; };
int netif_is_up(const struct netif *n);
int netif_is_link_up(const struct netif *n);
#endif
