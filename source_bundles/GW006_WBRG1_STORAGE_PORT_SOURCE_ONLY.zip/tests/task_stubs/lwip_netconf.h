#ifndef GWIR_CP33_TASK_LWIP_NETCONF_STUB_H
#define GWIR_CP33_TASK_LWIP_NETCONF_STUB_H
#include <stdint.h>
#include "lwip/netif.h"
extern struct netif xnetif[];
uint8_t *LwIP_GetIP(struct netif *p);
#endif
