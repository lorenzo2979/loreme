#ifndef GWIR_CP33_TASK_AMEBA_STUB_H
#define GWIR_CP33_TASK_AMEBA_STUB_H
#include <stdint.h>
#include <stddef.h>
#define tskIDLE_PRIORITY 0u
#define portTICK_PERIOD_MS 1u
#define pdPASS 1
int xTaskCreate(void (*fn)(void *), const char *name, unsigned stack_depth,
                void *arg, unsigned priority, void *handle);
void vTaskDelete(void *task);
void vTaskDelay(unsigned ticks);
#endif
