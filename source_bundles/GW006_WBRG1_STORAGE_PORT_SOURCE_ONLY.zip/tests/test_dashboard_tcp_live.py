"""Live host-only browser-style roundtrip over IPv4, never contacts GW006."""
from pathlib import Path
import subprocess,urllib.request,gzip
root=Path(__file__).resolve().parents[1]
p=subprocess.Popen([str(root/'build/dashboard_http_server_posix')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
    line=p.stdout.readline().strip()
    assert line.startswith('PORT='),line
    port=int(line.split('=',1)[1]);assert 1<=port<=65535
    req=urllib.request.Request(f'http://127.0.0.1:{port}/',headers={'Accept-Encoding':'gzip'})
    with urllib.request.urlopen(req, timeout=4) as resp:
        assert resp.status==200
        assert resp.headers['Content-Encoding']=='gzip'
        assert resp.headers['Cache-Control']=='no-store'
        assert "connect-src 'none'" in resp.headers['Content-Security-Policy']
        assert gzip.decompress(resp.read())==(root/'web/dashboard/index.html').read_bytes()
    assert p.wait(timeout=4)==0, p.stderr.read()
    print('PASS CP13 real IPv4 localhost HTTP GET, compressed dashboard exact, CSP and browser headers')
finally:
    if p.poll() is None: p.kill();p.wait()
