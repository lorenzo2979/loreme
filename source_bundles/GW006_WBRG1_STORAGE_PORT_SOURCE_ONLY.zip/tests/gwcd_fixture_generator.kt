package org.gw006.ir

import java.io.File

/** Test fixture emitted by the REAL AndroidCodeStore serializer. */
fun main(args: Array<String>) {
    require(args.size == 1)
    val target = File(args[0]); require(target.isDirectory || target.mkdirs())
    val frames = (0 until 5).map { f ->
        IrFrame(38000 + f*1000, 300 + f*10, 24000 + f*1000,
            List(f+2) { p -> 500 + 10*f + 100*p })
    }
    AndroidCodeStore(target).saveButton(7,frames)
    check(AndroidCodeStore(target).loadButton(7)==frames)
    println("PASS AndroidCodeStore emitted 5-frame GWCD file")
}
