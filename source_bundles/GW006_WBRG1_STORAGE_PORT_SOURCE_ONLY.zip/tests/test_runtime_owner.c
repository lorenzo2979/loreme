#include "gwir_runtime_owner.h"
#include <assert.h>
#include <openssl/hmac.h>
#include <stdio.h>
#include <string.h>

/* CP31: no sockets, flash driver, hardware or OpenBeken touched. */
static gwir_runtime_owner owner;
static gwir_engine engine;
static gwir_saved_play_service saved;
static gwir_fj_store store;
static uint32_t ir_scratch[GWIR_MAX_PULSES_PER_FRAME];
static uint8_t scratch[GWIR_MAX_MESSAGE], signed_response[GWIR_AUTH_MAX_PACKET];
static uint8_t sent[GWIR_AUTH_MAX_PACKET];
static size_t sent_len;
static unsigned send_count, ir_transmissions;
static uint8_t key[32],nonce[16];
static gwir_auth_session phone_tx,phone_rx;

static int mac(void *ctx, const uint8_t *key_p, size_t key_len,
               const uint8_t *data, size_t len, uint8_t digest[32])
{
    unsigned int n = 0;
    (void)ctx;
    return !HMAC(EVP_sha256(), key_p, (int)key_len, data, len, digest, &n) || n != 32u;
}
static int board_ready(void *unused) { (void)unused; return 0; }
static int ir_send(void *ctx, uint32_t c, uint16_t d,
                   const uint32_t *p, uint16_t n, uint32_t gap)
{
    (void)ctx;(void)c;(void)d;(void)p;(void)n;(void)gap;
    ++ir_transmissions;
    return -1; /* This should NEVER be called by an unauthorized owner. */
}
static int send_ok(void *ctx,const uint8_t *data,size_t n)
{
    (void)ctx;
    if (n > sizeof(sent)) return -1;
    memcpy(sent, data, n);
    sent_len = n;
    ++send_count;
    return 0;
}
static int send_fail(void *ctx,const uint8_t *data,size_t n)
{
    (void)ctx; (void)data; (void)n;
    return -1;
}
static size_t request(uint8_t *out, uint32_t seq, uint8_t command,
                      const uint8_t *payload,size_t n)
{
    uint8_t inner[GWIR_MAX_MESSAGE];
    size_t inner_len = 0, total = 0;
    assert(gwir_encode(inner,sizeof(inner),command,seq,payload,(uint32_t)n,&inner_len) == 0);
    assert(gwir_auth_wrap(&phone_tx,GWIR_AUTH_TO_DEVICE,inner,inner_len,
                          out,GWIR_AUTH_MAX_PACKET,&total) == 0);
    return total;
}
static void verify_response(uint32_t seq,uint8_t cmd,uint8_t status)
{
    const uint8_t *inner = NULL;
    size_t n = 0;
    gwir_message m = {0};
    assert(gwir_auth_unwrap(&phone_rx,GWIR_AUTH_FROM_DEVICE,sent,sent_len,&inner,&n) == 0);
    assert(gwir_decode(inner,n,&m) == 0);
    assert(m.sequence == seq && m.command == cmd);
    if (cmd == GWIR_SAVED_STATUS) {
        assert(m.payload_len == 2 && m.payload[0] == status && m.payload[1] == 0);
    }
}
int main(void)
{
    static uint8_t wire[GWIR_AUTH_MAX_PACKET];
    uint8_t bad_key[GWIR_AUTH_KEY_BYTES] = {0};
    uint8_t bad_nonce[GWIR_AUTH_NONCE_BYTES] = {0};
    size_t n;
    uint8_t button=95;
    gwir_ir_hal hal = {0};
    gwir_fj_play_ops ir = {NULL,board_ready,ir_send};
    for(unsigned i=0;i<sizeof(key);i++) key[i]=(uint8_t)(i+1);
    for(unsigned i=0;i<sizeof(nonce);i++) nonce[i]=(uint8_t)(i+32);
    gwir_engine_init(&engine,hal);
    assert(gwir_saved_play_init(&saved,&store,&ir,ir_scratch,
                                GWIR_MAX_PULSES_PER_FRAME) == 0);
    assert(gwir_runtime_owner_connect(&owner) != 0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,bad_key,nonce,mac,NULL,
               scratch,sizeof(scratch),signed_response,sizeof(signed_response)) != 0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,key,bad_nonce,mac,NULL,
               scratch,sizeof(scratch),signed_response,sizeof(signed_response)) != 0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,key,nonce,NULL,NULL,
               scratch,sizeof(scratch),signed_response,sizeof(signed_response)) != 0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,key,nonce,mac,NULL,
               scratch,sizeof(scratch),scratch,sizeof(scratch)) != 0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,key,nonce,mac,NULL,
               scratch,sizeof(scratch),signed_response,sizeof(signed_response)) == 0);
    assert(gwir_runtime_owner_init(&owner,&engine,&saved,key,nonce,mac,NULL,
               scratch,sizeof(scratch),signed_response,sizeof(signed_response)) != 0);
    assert(gwir_runtime_owner_connect(&owner) == 0);
    assert(gwir_runtime_owner_connect(&owner) != 0); /* only one owner socket */
    assert(gwir_auth_init(&phone_tx,key,nonce,mac,NULL) == 0);
    assert(gwir_auth_init(&phone_rx,key,nonce,mac,NULL) == 0);
    n=request(wire,1u,GWIR_TX_SAVED,&button,1);
    assert(gwir_runtime_owner_feed(&owner,wire,5,send_ok,NULL) == 0);
    assert(send_count == 0 && ir_transmissions == 0);
    assert(gwir_runtime_owner_feed(&owner,wire+5,n-5,send_ok,NULL) == 1);
    assert(send_count == 1 && ir_transmissions == 0);
    verify_response(1,GWIR_SAVED_STATUS,GWIR_NOT_READY);
    /* Connection reopen must retain the GWAS counter. */
    gwir_runtime_owner_disconnect(&owner);
    assert(gwir_runtime_owner_connect(&owner) == 0);
    assert(gwir_runtime_owner_feed(&owner,wire,n,send_ok,NULL) < 0);
    assert(owner.connected == 0 && ir_transmissions == 0);
    assert(gwir_runtime_owner_connect(&owner) == 0);
    n=request(wire,1,GWIR_TX_SAVED,&button,1); /* new GWAS counter, same saved seq */
    assert(gwir_runtime_owner_feed(&owner,wire,n,send_ok,NULL) == 1);
    assert(send_count == 2 && ir_transmissions == 0);
    verify_response(1,GWIR_SAVED_STATUS,GWIR_NOT_READY);
    /* No unsigned fallback on failed signed-response transport. */
    n=request(wire,2,GWIR_TX_SAVED,&button,1);
    assert(gwir_runtime_owner_feed(&owner,wire,n,send_fail,NULL) < 0);
    assert(owner.connected == 0 && ir_transmissions == 0);
    assert(gwir_runtime_owner_connect(&owner) == 0);
    n=request(wire,2,GWIR_TX_SAVED,&button,1);
    assert(gwir_runtime_owner_feed(&owner,wire,n,send_ok,NULL) == 1);
    verify_response(2,GWIR_SAVED_STATUS,GWIR_NOT_READY);
    assert(ir_transmissions == 0);
    /* Clear destroys credentials and prevents any accidental processing. */
    gwir_runtime_owner_clear(&owner);
    assert(owner.initialized == 0 && owner.rx.active == 0 && owner.tx.active == 0);
    assert(gwir_runtime_owner_connect(&owner) < 0);
    assert(gwir_runtime_owner_feed(&owner,wire,n,send_ok,NULL) < 0);
    for(size_t i=0;i<sizeof(scratch);i++) assert(scratch[i]==0);
    for(size_t i=0;i<sizeof(signed_response);i++) assert(signed_response[i]==0);
    puts("PASS CP31: serial owner, real HMAC, saved replay, connection reset, deny-by-default IR, credential wipe");
    return 0;
}
