from pathlib import Path
import re
html=(Path(__file__).resolve().parents[1]/'web/dashboard/index.html').read_text()
assert '<html lang="it">' in html
for keyword in ('GW006 IR UNIVERSAL','Cerca Wi-Fi','DHCP','IP statico','42424','DuckDNS','Home Assistant','3000'):
 assert keyword in html,keyword
assert 'fetch(' not in html and 'WebSocket(' not in html, 'Offline preview cannot make unauthenticated requests'
assert 'non inviato' in html and 'disabled' in html
pattern=re.compile(r"\{key:'(\w+)',name:'([^']+)',icon:'[^']+',buttons:\[([^\]]+)\]\}")
rows=pattern.findall(html)
counts={key:len(re.findall(r"'[^']*'",buttons)) for key,_,buttons in rows}
assert counts=={'tv':36,'clima':14,'decoder':32,'speaker':14},counts
print('PASS dashboard 96 buttons, ESP dark theme, 3s long-press, DHCP/static, HA-only MQTT, offline fail-closed')
