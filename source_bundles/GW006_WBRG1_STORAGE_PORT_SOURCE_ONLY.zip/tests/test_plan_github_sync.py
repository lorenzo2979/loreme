#!/usr/bin/env python3
"""CP22: fail-closed sync and exact allowlist against a local disposable Git repo."""
from pathlib import Path
import importlib.util
import shutil
import stat
import subprocess
import tempfile

source = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('git_sync', source/'scripts/plan_github_sync.py')
sync = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sync)


def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], check=True, capture_output=True, text=True).stdout.strip()


def refused(fn, match):
    try:
        fn()
    except ValueError as e:
        assert match.lower() in str(e).lower(), (match, str(e))
    else:
        raise AssertionError('Expected refusal: ' + match)

with tempfile.TemporaryDirectory(prefix='cp22_gitsync_') as td:
    base = Path(td)
    checkout = base/'repo'
    checkout.mkdir()
    git(checkout, 'init', '-q', '-b', 'main')
    git(checkout, 'config', 'user.name', 'Local Host Test')
    git(checkout, 'config', 'user.email', 'host-test@example.invalid')
    (checkout/'README.md').write_text('old')
    git(checkout, 'add', 'README.md')
    git(checkout, 'commit', '-qm', 'init')
    refused(lambda: sync.run(source, checkout, False), 'non-review')
    git(checkout, 'checkout', '-qb', 'develop')
    refused(lambda: sync.run(source, checkout, True), 'non-review')
    git(checkout, 'checkout', '-qb', 'review/gw006-cp22')
    (checkout/'untracked').write_text('local change')
    refused(lambda: sync.run(source, checkout, True), 'dirty')
    (checkout/'untracked').unlink()
    locked = sync.get_paths(source)
    assert len(locked) == 147
    assert 'firmware/core/gwir_flash_journal.c' in locked
    assert 'scripts/plan_github_sync.py' in locked
    assert not (checkout/'firmware/core/gwir_flash_journal.c').exists()
    dry = sync.run(source, checkout, False)
    assert dry['source_verified'] and dry['locked_files'] == 147
    assert not (checkout/'firmware/core/gwir_flash_journal.c').exists()

    # Disposable copy to test malformed sources without touching the CP22 project.
    tampered = base/'tampered_source'
    shutil.copytree(source, tampered, ignore=shutil.ignore_patterns('build', '__pycache__', '*.pyc'))
    target = tampered/'firmware/core/gwir_flash_journal.c'
    old = target.read_bytes()
    target.write_bytes(old + b'\n')
    refused(lambda: sync.run(tampered, checkout, True), 'integrity mismatch')
    target.write_bytes(old)
    unknown = tampered/'scripts/extra_unlocked.py'
    unknown.write_text('print("unreviewed")')
    refused(lambda: sync.run(tampered, checkout, False), 'inventory mismatch')
    unknown.unlink()
    # Even a source non-code file unknown to the manifest is not copied.
    (tampered/'scripts/temp_debug.secret').write_text('NOT FOR PUBLICATION')
    assert 'scripts/temp_debug.secret' not in sync.get_paths(tampered)
    (tampered/'scripts/temp_debug.secret').unlink()
    # A named extra must be safe as well.
    docs = tampered/'docs/CHECKPOINT_CP21_2026-11-12.md'
    old_doc = docs.read_bytes()
    docs.unlink()
    docs.symlink_to(tampered/'README.md')
    refused(lambda: sync.run(tampered, checkout, True), 'symlink')
    docs.unlink(); docs.write_bytes(old_doc)
    # Reject destination symlink before copying any of the files.
    (checkout/'firmware').symlink_to(base, target_is_directory=True)
    git(checkout, 'add', 'firmware')
    git(checkout, 'commit', '-qm', 'track symlink solely for safety test')
    refused(lambda: sync.run(source, checkout, True), 'symlink destination')
    git(checkout, 'rm', '-q', 'firmware')
    git(checkout, 'commit', '-qm', 'remove symlink after safety test')

    done = sync.run(source, checkout, True)
    assert done['source_verified'] and done['pushed'] is False
    assert (checkout/'firmware/core/gwir_flash_journal.c').read_bytes() == old
    assert (checkout/'scripts/plan_github_sync.py').read_bytes() == (source/'scripts/plan_github_sync.py').read_bytes()
    assert not (checkout/'source_bundles').exists()
    assert not (checkout/'scripts/temp_debug.secret').exists()
    assert not (checkout/'scripts/__pycache__').exists()
    assert stat.S_IMODE((checkout/'scripts/cross_arm_smoke.sh').stat().st_mode) == stat.S_IMODE((source/'scripts/cross_arm_smoke.sh').stat().st_mode)
    assert git(checkout, 'branch', '--show-current') == 'review/gw006-cp22'
    assert git(checkout, 'status', '--porcelain')
print('PASS CP22: locked allowlist, tampered/missing-source guard, review/dirty/symlink, dry-run, copy; NO PUSH/NO FLASH')
