#include "gwir_gwcd_store.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint8_t record[GWIR_GWCD_MAX_SIZE+1u];
static uint32_t pulses[GWIR_MAX_PULSES_PER_FRAME];
static uint32_t record_length;
static uint32_t fail_offset;
static int fail_read;

static int rd(void *ctx,uint32_t off,void *dst,size_t len) {
    (void)ctx;
    if (fail_read && off <= fail_offset && fail_offset < off + len) return -1;
    if (off > record_length || len > record_length-off) return -1;
    memcpy(dst,record+off,len);
    return 0;
}
static void put32(uint32_t *pos,uint32_t x){gwir_write_u32be(record+*pos,x);*pos+=4u;}
static void put16(uint32_t *pos,uint16_t x){gwir_write_u16be(record+*pos,x);*pos+=2u;}
static void crc_finish(uint32_t pos) {
    uint32_t crc=gwir_crc32_continue(0xFFFFFFFFu,record,pos)^0xFFFFFFFFu;
    put32(&pos,crc);
    record_length=pos;
}
static void make_record(uint32_t button,uint32_t frame_count,uint16_t count) {
    uint32_t p=0u;
    memcpy(record,"GWCD",4);p+=4u;
    put32(&p,1u);put32(&p,button);put32(&p,frame_count);
    for(uint32_t f=0;f<frame_count;f++) {
        put32(&p,38000u);put16(&p,333u);put16(&p,count);put32(&p,40000u);
        for(uint32_t i=0;i<count;i++) put32(&p,(i & 1u) ? 560u : 900u);
    }
    crc_finish(p);
}
static void update_crc(void){crc_finish(record_length-4u);}
int main(void) {
    gwir_gwcd_index index,sentinel;
    make_record(95u,5u,2048u);
    assert(record_length == GWIR_GWCD_MAX_SIZE);
    assert(gwir_gwcd_worst_case_bytes() == 3939840u);
    assert(gwir_gwcd_scan(rd,NULL,record_length,95u,&index)==0);
    assert(index.frame_count==5u && index.frame[4].pulse_count==2048u);
    assert(gwir_gwcd_read_frame(rd,NULL,&index,4u,pulses,2048u)==0);
    assert(pulses[0]==900u && pulses[2047]==560u);
    assert(gwir_gwcd_read_frame(rd,NULL,&index,4u,pulses,2047u)!=0);
    assert(gwir_gwcd_scan(rd,NULL,record_length,94u,&index)==-4);
    assert(gwir_gwcd_scan(rd,NULL,record_length+1u,95u,&index)==-1);
    assert(gwir_gwcd_scan(NULL,NULL,record_length,95u,&index)==-1);
    assert(gwir_gwcd_scan(rd,NULL,record_length,96u,&index)==-1);
    memset(&sentinel,0xCC,sizeof(sentinel));
    index=sentinel;
    record[50]^=1u;
    assert(gwir_gwcd_scan(rd,NULL,record_length,95u,&index)==-3);
    assert(memcmp(&index,&sentinel,sizeof(index))==0); /* never publish partial index */
    record[50]^=1u;
    fail_read=1;fail_offset=190u;
    assert(gwir_gwcd_scan(rd,NULL,record_length,95u,&index)==-2);
    fail_read=0;

    make_record(3u,1u,4u);
    assert(record_length==48u);
    assert(gwir_gwcd_scan(rd,NULL,record_length,3u,&index)==0);
    assert(index.frame[0].pulse_offset==28u);
    assert(gwir_gwcd_read_frame(rd,NULL,&index,0u,pulses,2048u)==0);
    assert(pulses[0]==900u && pulses[1]==560u);
    assert(gwir_gwcd_read_frame(rd,NULL,&index,1u,pulses,2048u)==-1);
    {
        gwir_gwcd_index malformed=index;
        malformed.frame_count=255u;
        assert(gwir_gwcd_read_frame(rd,NULL,&malformed,4u,pulses,2048u)==-1);
        malformed=index;
        malformed.serialized_bytes=1u;
        assert(gwir_gwcd_read_frame(rd,NULL,&malformed,0u,pulses,2048u)==-1);
    }

    /* Bad frame data with good checksum must be rejected too. */
    gwir_write_u32be(record+28,0u);update_crc();
    assert(gwir_gwcd_scan(rd,NULL,record_length,3u,&index)==-4);
    gwir_write_u32be(record+28,900u);update_crc();
    record[23]=0; /* pulse_count becomes 0 */
    update_crc();
    assert(gwir_gwcd_scan(rd,NULL,record_length,3u,&index)==-4);
    make_record(3u,1u,4u);
    record[15]=6u;update_crc();
    assert(gwir_gwcd_scan(rd,NULL,record_length,3u,&index)==-4);
    make_record(3u,1u,4u);
    record_length-=1u;
    assert(gwir_gwcd_scan(rd,NULL,record_length,3u,&index)!=0);

    /* Missing frame, trailing data and boundary checks. */
    make_record(3u,1u,4u);
    record[record_length]=0x55u;
    assert(gwir_gwcd_scan(rd,NULL,record_length+1u,3u,&index)!=0);
    printf("PASS CP17: Android GWCD v1 bounds/CRC, 5x2048 frames, IO fail closed, 96-button worst case %u bytes\n",gwir_gwcd_worst_case_bytes());
    return 0;
}
