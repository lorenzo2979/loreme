/* Compile real server source with the vendor lwIP timeout ABI, route back to
 * Linux setsockopt after verifying the exact integer-milliseconds layout. */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int gwir_test_lwip_setsockopt(int fd, int level, int option,
                             const void *optval, socklen_t optlen)
{
    if (level == SOL_SOCKET &&
        (option == SO_RCVTIMEO || option == SO_SNDTIMEO)) {
        if (getenv("GWIR_TEST_DENY_TIMEOUT")) {
            errno = EINVAL;
            return -1; /* Emulate SDK refusal to configure timeouts. */
        }
        int ms;
        struct timeval tv;
        if (optlen != sizeof(ms)) {
            fprintf(stderr, "ERROR: lwIP expects an int timeout (got %u bytes)\n",
                    (unsigned)optlen);
            errno = EINVAL;
            return -1;
        }
        memcpy(&ms, optval, sizeof(ms));
        if (ms != 1000 && ms != 2000) {
            fprintf(stderr, "ERROR: unexpected lwIP timeout %dms\n", ms);
            errno = EINVAL;
            return -1;
        }
        tv.tv_sec = ms / 1000;
        tv.tv_usec = (ms % 1000) * 1000;
        return setsockopt(fd, level, option, &tv, sizeof(tv));
    }
    return setsockopt(fd, level, option, optval, optlen);
}
