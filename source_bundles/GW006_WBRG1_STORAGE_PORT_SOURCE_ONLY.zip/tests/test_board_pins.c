#include "../firmware/realtek/gwir_amebad_board_pins.h"
#include "ameba_soc.h"
#include <assert.h>
#include <stdio.h>
int main(void)
{
    gwir_board_pins p = gwir_board_pins_candidate();
    assert(p.ir_tx == _PA_25 && p.ir_rx == _PA_26);
    assert(p.red_led == GWIR_UNUSED_PIN);
    assert(p.blue_led == _PB_22 && p.ap_button == _PB_23);
    assert(gwir_board_pins_validate(&p) == 0);
    assert(gwir_board_pins_validate(NULL) < 0);
    assert(gwir_board_ir_enable_authorized() == 0);
    /* PA25 is not logically available while red LED is assigned to it. */
    p.red_led = _PA_25;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.ir_tx = p.ap_button;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.ir_rx = p.blue_led;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.ap_button = p.ir_tx;
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_candidate();
    p.red_led = _PB_31; /* cannot misrepresent an unrelated LED assignment */
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_pb31_legacy_candidate();
    assert(p.ir_tx == _PB_31 && p.ir_rx == _PA_26);
    assert(p.red_led == _PA_25);
    assert(gwir_board_pins_validate(&p) == 0);
    p.ir_tx = _PA_25; /* old red-LED assignment collides */
    assert(gwir_board_pins_validate(&p) < 0);
    p = gwir_board_pins_pb31_legacy_candidate();
    p.red_led = GWIR_UNUSED_PIN; /* would be a different unrecognized profile */
    assert(gwir_board_pins_validate(&p) < 0);
    puts("PASS GW006 board metadata: PA25 TX / PA26 RX conditional; PB31 fallback; no IR enable");
    return 0;
}
