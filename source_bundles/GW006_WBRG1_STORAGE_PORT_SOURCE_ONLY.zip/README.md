# GW006 IR Universal — CP-29, authenticated saved-code command (SOURCE ONLY)

**NON INSTALLARE / NO FLASH.** CP-29 routes `GWIR_TX_SAVED` (command 9, one-byte button 0..95) **only after GWAS HMAC-SHA256, nonce and monotonically increasing envelope counter verification**. A serialized, explicitly initialized playback service reads validated GWCD frames from mock NOR journal using the CP-28 bridge; the board IR enable callback remains deliberately false on the physical GW006. Reply is a **signed** `GWIR_SAVED_STATUS` (0x91) with `[status, frames_done]`. A strictly increasing nonzero GWIR sequence prevents accidental duplicate transmissions; same last sequence/button returns the cached status, a lower sequence or mismatched button is rejected. This cache is RAM-only and does not survive device resets.

Host tests include genuine OpenSSL HMAC-SHA256, tampered signatures, anti-replay, fragmented GWAS stream, RX busy, absent/corrupted flash records, denied physical IR, partial transmission and 96-button bounds. No real TCP listener, authorized Realtek GPIO/pinmux, reserved flash partition, complete vendor SDK build or hardware demonstration is activated. Native REV21 GitHub success is **not** a build of this CP-29 snapshot. Preserve OpenBeken 1.18.321 on the GW006.

See `docs/CHECKPOINT_CP29_2026-11-12.md` and `docs/PROTOCOL.md`.

---

# GW006 IR Universal — CP-28, flash-to-IR playback bridge (SOURCE ONLY)

**NON INSTALLARE / NO FLASH.** Added `gwir_fj_play` to the existing portable NOR
journal module, to read a committed GWCD record for button 0..95 and send up
to five validated IR frames to an *injected* IR transmit callback. A physical
board-approval callback must return exactly 1 before reading flash and before
each frame; GW006 hardware authorization remains deliberately **disabled**.
Caller owns a static 2048 × 32-bit timing scratch array and must serialize all
NOR/IR work behind authenticated command dispatch. No Realtek pinmux, flash
partition, network listener, or standalone device runtime is activated here.

Validated with simulated NOR and mock IR: last button (95), maximum payload
five × 2048 durations, reboot, CRC errors, broken reads, TX errors, loss of
board approval mid-playback, and ASan/UBSan. The previous REV21 SDK KM0/KM4
build succeeded, but **CP-28 native build and board tests have NOT happened**.
See `docs/CHECKPOINT_CP28_2026-11-12.md` for remaining blockers.

---

# GW006 IR Universal — CP-17, lettore codici Android GWCD compatibile (NON FLASHARE)

Il nuovo modulo C `gwir_gwcd_store` legge in streaming i file GWCD v1 generati da AndroidCodeStore, controlla CRC32, valori e lunghezze, con prova incrociata Kotlin→C. Integrazione mock SDK portata a 34 sorgenti. Dimensione massima teorica per i 96 tasti: 3.939.840 byte, **senza firmware né costi della memoria flash**. Il WBRG1 nominalmente ha 8 MB di flash, ma la mappa delle partizioni deve ancora essere verificata. **Nessun salvataggio flash reale, nessuna build nativa né flash sulla scheda.** Vedere `docs/CP17_GWCD_READER_AND_CAPACITY.md`.

---

# GW006 IR Universal — CP-16, compatibilità lwIP Realtek (NON FLASHARE)

Corretto il formato dei timeout di rete `LWIP_SO_SNDRCVTIMEO_NONSTANDARD=1` usato dall'SDK ufficiale Realtek: intero in millisecondi, non `struct timeval`. Server HTTP fail-closed quando il timeout non può essere impostato. Aggiunti test ABI lwIP e fallimento socket, entrambi PASS su host; suite regressione PASS.

**Mancano SDK-native build KM0/KM4, collaudo hardware, storage flash e API web autenticate.** OpenBeken 1.18.321 resta invariato. Leggere `docs/GW006_CHECKPOINT_CP16_2026-11-12.md`.

---

# GW006 IR Universal — CP-15 (sviluppo, NON flashare)

La dashboard CP-13 è ora predisposta per un task STA/FreeRTOS sperimentale (porta 8080), disabilitato per impostazione predefinita. Il gate blocca hotspot APConfig e la risposta HTTP quando cambia la rete. Test locali e SDK simulato passati; nessun build/link nativo CP-15 né collaudo su WBRG1. Vedi `docs/CHECKPOINT_CP15_STA_FREERTOS_2026-11-12.md`.

---

# GW006 IR Universal — CP-13 Dashboard HTTP incorporata (non flashare)

CP-13 aggiunge la dashboard web REV18 compressa (5.094 byte) nella sezione read-only del firmware, un parser/risponditore HTTP C con CSP hash, test su vere socket host IPv4 e 30 sorgenti SDK-mock. La pagina rimane dimostrativa: non invia IR, non salva impostazioni e non è ancora servita dal WBRG1. Le API web IR richiederanno autenticazione, mentre la memoria codici standalone richiederà storage flash testato. Vedi `docs/CHECKPOINT_CP13_DASHBOARD_WEB.md`.

**Non installare sulla GW006. Conservare OpenBeken 1.18.321.**

# GW006 IR Universal — CP-12, source-only / no flash

**Non è un firmware da installare sulla GW006.** I nuovi sorgenti includono:
- Mappa proposta PA25 TX / PA26 RX dopo isolamento reale del LED rosso; il vecchio PB31 è alternativa, e l’attivazione IR resta esplicitamente disabilitata.
- `gwir_auth_stream.c/.h`: ricezione TCP incrementale **GWAS firmata**, collegata a HMAC/anti-replay e al dispatcher IR; non esiste ancora listener lwIP sul dispositivo.
- Test con vere socket TCP sul computer per pacchetti IR firmati, test di regressione e sanitizzatori; mock SDK 28 oggetti e ARM compile-only (non build nativa).
- Memoria dei 96 codici nel componente **AndroidCodeStore**: app Android completa e dashboard standalone non ancora operative.

Consultare `docs/CP12_HARDWARE_AND_RUNTIME_STATUS.md` per blocchi e sicurezza; preservare OpenBeken 1.18.321.

---

# GW006 IR Universal — REV21 APConfig TCP transport (offline)

**Source-only: nessuna installazione sul dispositivo.** Test reali su scheda ancora assenti.

REV21 aggiunge un trasporto callback-based limitato per una singola connessione APConfig. La rete AP effettiva, la verifica netif Realtek, DHCP, la memorizzazione Wi-Fi e il pinmux IR non sono implementati/abilitati. I test host, Kotlin, sanitizzatori, mock SDK e ARM compile-only risultano PASS, ma la REV21 non ha ancora una build SDK nativa.

**Dato nuovo importante:** il repository GitHub ha già eseguito con successo una build nativa KM0/KM4 con codice GW006 **REV16**: https://github.com/lorenzo2979/loreme/actions/runs/43073357001. Non confondere la sua riuscita con una certificazione hardware o REV21.

Consultare `docs/REV21_TCP_TRANSPORT_VERIFICATION.md`; preservare OpenBeken 1.18.321, non flashare.

# GW006 IR Universal — REV20 TCP APConfig connection gate

**SOURCE-ONLY, TESTED OFFLINE, NOT A GW006 FIRMWARE IMAGE.**

REV20 builds on the REV19 HTTP validator with a fixed-size per-connection TCP
framing adapter (max 1,536 bytes), split-read assembly, AP/session gate,
2-second idle/10-second total timeout, one-shot status/close, credential wipe,
and rollback handling. No real Realtek TCP listener, DHCP service, STA commit
backend or physical IR pinmux is activated. OpenBeken 1.18.321 is unchanged.

Verification: `make test test-sdk-integration test-web-assets test-kotlin
arm-smoke test-http-sanitized test-stream-sanitized` (host tests/mock SDK,
ARM object compile-only). See `docs/REV20_APCONFIG_HTTP_STREAM.md`.

# GW006 IR Universal — REV19 APConfig HTTP request gate

**SOURCE-ONLY, TESTED OFFLINE, NOT A GW006 FIRMWARE IMAGE.**

REV19 adds strict, allocation-free HTTP/1.1 parsing for the temporary OPEN APConfig network at `192.168.4.1`, with an active-session/AP-interface check and staged Wi-Fi rollback contract. Nothing listens on the network yet; the physical GW006 still runs OpenBeken 1.18.321. See `docs/REV19_APCONFIG_HTTP_GATE.md`.

Verified locally: host regression, SDK mock integration (25 objects), dashboard assets, Kotlin/JVM, ARM Cortex-M23/M33 compile-only, and 30,000 deterministic malformed HTTP inputs under ASan/UBSan. **No Realtek SDK-native REV19 build or hardware test.**

# GW006 IR Universal — REV18 GPIO pin policy, Wi-Fi profile, web dashboard preview

**This is an intermediate source release, NOT flash-ready for the WBRG1.**

- New board pin pair **PB31 → IR TX**, **PA26 → IR RX**. The user has electrically checked both available. Existing red/blue LEDs and APConfig button stay on **PA25/PB22/PB23**.
- The pinmap is checked in portable code and compiled in the vendor SDK. **No PinMux initialization** is enabled, and board IR remains fail-closed until actual 38-kHz TX/RX tests and safe recovery are established.
- Station Wi-Fi profile parser offers **DHCP default and static IPv4, mask, gateway, DNS** with bounds, validation and stage/verify/commit/rollback. The SDK network and nonvolatile implementation are not yet connected.
- `web/dashboard/index.html` is an **offline HTML demo** based on the ESP C3 purple/black interface. TV 36 / Clima 14 / Decoder 32 / Speaker 14 (96 buttons), 3-second long-press menus, Wi-Fi search design, DuckDNS and optional MQTT for Home Assistant only. **It cannot control hardware, store codes, or submit Wi-Fi settings yet**.
- User chose normal LAN command port **TCP 42424** with authenticated commands; this is a specification, not a running listener.
- APConfig SSID `GW006-IR-SETUP`, deliberately open **only for 5 minutes after 5-second physical button press**, no login; only SDK hotspot adapter and state logic developed, not live DHCP/HTTP.
- Maintain OpenBeken 1.18.321 on the original GW006 until image layout, backups, physical GPIO tests and recovery process are verified.

Run `make test test-sdk-integration test-web-assets test-kotlin arm-smoke` for portable checks. See `docs/REV18_BOARD_PINS_DASHBOARD.md`.

# GW006 IR Universal — REV16 Wi-Fi profile provisioning core

REV15 open APConfig has been published for native SDK build. REV16 adds
bounded form decoding and an atomic-profile **backend contract**. The
HTTP AP-only portal, DHCP, verified board pin, persistent storage and
live Wi-Fi association remain to be implemented and physically tested.

- APConfig: OPEN Wi-Fi, no password/login, hold PCB button for 5s, auto-close after 5min.
- STA: keep previous credentials until verification succeeds; never erase on a failed edit.
- Normal IR TCP: fixed port **42424**; HMAC auth, distinct from APConfig.
- DuckDNS: future Android settings integration; no enabled DDNS service here.
- No flash of GW006. Keep OpenBeken 1.18.321.

See docs/REV16_PROVISIONING_VALIDATION.md and CP-07 in GitHub.
