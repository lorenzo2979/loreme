# GW006 IR Universal — CHECKPOINT CP-25 (2026-11-12)

## Stato sicurezza

SORGENTI E TEST HOST SOLTANTO. **NO FLASH.** OpenBeken 1.18.321 non è stato modificato. I backup flash, layout e recovery verificati su hardware restano necessari. Nessuna immagine installabile.

## Modifica tecnica CP-25

Aggiornato `scripts/verify_native_km4_objects.py` per rilevare oggetti `.o` non validi anche se recenti e non vuoti. Il postbuild richiede:

- I 34 file sorgente `.c` copiati nel SDK AmebaD con SHA-256 uguale al manifesto e 34 riferimenti Makefile univoci;
- `.o` normali, non symlink, con mtime non anteriore al marker KM4;
- **ELF32 little-endian**, tipo `ET_REL`, macchina **EM_ARM** (40), struttura delle sezioni consistente e non fuori dai limiti del file;
- almeno una sezione di codice eseguibile (`SHF_EXECINSTR`) non vuota, una `SHT_SYMTAB` valida e un simbolo di funzione *definito* (non semplicemente una referenza esterna).

`tests/test_native_km4_objects.py` usa file ELF ARM **sintetici** e, se Clang e cc sono installati, verifica anche un oggetto ARM prodotto da Clang e rifiuta un oggetto host. Queste prove **non** sono compilazione con SDK AmebaD, prova di link finale o test sulla scheda. Il gate rifiuta dati corrotti, file non ELF, ISA errata, sezioni errate, simboli assenti o indefiniti, oggetti vuoti/vecchi/symlink e sorgenti alterati.

Workflow `.github/workflows/gw006-cp21-native.yml` aggiornato nella denominazione e nei diagnostici; resta eseguibile in GitHub solo dopo la copia completa dei sorgenti. Repository `lorenzo2979/loreme` main non deve essere toccato: usare ramo `review/gw006-cp23-native-probe` e PR bozza n. 2, mai fondere automaticamente.

Il manifesto sorgenti resta `docs/CP21_SOURCE_MANIFEST.json` per compatibilità, con nuovi digest CP-25.

## Limiti espliciti

1. Tutti i test qui descritti sono **host** o **sintetici**; non è stata completata una vera build del SDK Realtek KM0/KM4.
2. I 34 `.o` con architettura ARM **non dimostrano** che l'immagine finale li includa; servirà controllare una link-map realistica e la configurazione della toolchain.
3. Nessun firmware è stato eseguito sulla GW006; pinout, partizioni flash, salvataggio massimo 96×5 codici, backup e ripristino non sono stati validati sul dispositivo.
4. La sincronizzazione completa su GitHub non è stata eseguita perché dal container `git` non risolve `github.com`. Non dichiarare il CP-25 pubblicato.

## Ripresa CP-26

Su un computer con Git autenticato: verificare manifesto, copiare esclusivamente file in allowlist sul ramo review, controllare `git diff` e lanciare su GitHub `gw006-cp21-native.yml`. Raccogliere veri log KM0/KM4 e i JSON dei 34 oggetti. Solo a risultato positivo controllare la link-map, senza predisporre flash finché non siano provati backup, spazio e recovery.

## Verifica finale ripetuta in questa sessione

Il 12/11/2026 sono stati eseguiti nuovamente con errore fatale in caso di fallimento:

- Manifesto sorgenti (139 file SHA-256, 34 moduli C e 34 mappature Makefile), test integrità/manipolazione e test di copia Git isolata: PASS.
- Gate CP25 ARM ELF su oggetti sintetici e su oggetto ARM32 generato davvero da Clang: PASS. Non è una build vendor.
- Sette mappe flash sintetiche: PASS; non è la mappa della GW006 reale.
- `make -j2 test test-sdk-integration test-web-assets test-kotlin arm-smoke test-dashboard-lwip-abi`: PASS.
- `make test-http-sanitized test-stream-sanitized test-tcp-transport-sanitized test-auth-stream-sanitized test-apconfig-live-socket test-auth-live-tcp test-dashboard-live-tcp`: PASS.

Log verificabile: `GW006_CP25_FINAL_VERIFICATION.log` (file esterno al pacchetto).
Rimane rigorosamente PENDING: source sync remoto, SDK Realtek KM0/KM4, prove hardware e recovery.
