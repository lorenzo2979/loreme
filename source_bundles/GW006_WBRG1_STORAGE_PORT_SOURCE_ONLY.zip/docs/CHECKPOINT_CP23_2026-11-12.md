# GW006 IR Universal — CHECKPOINT CP-23

**Data: 12 novembre 2026. Stato: REV21 GitHub native probe OPEN / CP23 SOURCE LOCK HOST PASS / CP22-COMPLETE GITHUB SYNC PENDING / NATIVE KM0-KM4 UNVERIFIED / GW006 UNTOUCHED.**

## 1. Dispositivo, vincoli e baseline

- GW006 RSH-GW006 con modulo Tuya WBRG1 / RTL8721CSM.
- Sul dispositivo rimane **OpenBeken 1.18.321**, non modificato. Nessun flashing o modifica hardware.
- Obiettivo finale invariato: 96 tasti IR (TV 36, clima 14, decoder 32, speaker 14), fino a 5 frame per tasto; persistenza non volatile, dashboard e trasporto autenticato.
- Partenza: archivio locale CP-22 `GW006_IR_UNIVERSAL_CP22_SAFE_SOURCE_NO_FLASH.zip`; SHA-256 originale `91554c47cc1a0d57629dcec2ff1c9e6dadf0940b2c94b0d4a2302a25b1922a42`.

## 2. Operazioni GitHub eseguite (confermate dalla risposta GitHub)

- Repository: `https://github.com/lorenzo2979/loreme`, default branch `main`.
- Base `main` verificata: commit `5892d2dd96a50be19a65d87a385fdb5a9ef1fc97` (CP-19).
- Creato ramo di sola revisione: `review/gw006-cp23-native-probe`.
- Inserita sul ramo la nota `docs/CHECKPOINT_CP23_NATIVE_BASELINE_PROBE.md`.
- Modificato **sul solo ramo** il workflow `.github/workflows/sdk-native-rev21.yml` per attivare una prova nativa REV21 quando cambia quel workflow sul ramo di revisione. Nuovo commit ramo: `ceb3b5a1abbdd962f5fbf392c26824cc9126c6ba`.
- Aperta PR in **bozza**, n. 2: `https://github.com/lorenzo2979/loreme/pull/2`.
- **Nessun merge su `main`.** PR #2 contiene solo il trigger CI di **REV21** e un documento, **non** i 137 file bloccati CP22/CP23. Lo stato di esecuzione/risultato della build GitHub non è stato confermato: non indicare PASS per KM0/KM4.

## 3. Modifiche apportate al pacchetto CP-23 locale

- Rispetto al CP-22 originale sono cambiati solo due file sotto controllo hash:
  1. `.github/workflows/gw006-cp21-native.yml`: aggiunto trigger `push` sul ramo `review/gw006-cp23-native-probe` limitato a modifiche dei sorgenti/manifesto/workflow. Resta disponibile `workflow_dispatch`. Questo workflow può partire **dopo** la sincronizzazione locale completa e il push verificato.
  2. `docs/CP21_SOURCE_MANIFEST.json`: aggiornato esclusivamente hash SHA-256/dimensione del workflow modificato.
- NESSUN sorgente C, file header, protocollo, algoritmo crittografico, schema flash o pinmux è stato cambiato in CP-23.
- La registrazione di CP-23 come documento aggiuntivo non invalida il manifesto (il documento è fuori dal perimetro dei 137 sorgenti bloccati).

## 4. Prove locali eseguite nel container

- `python3 scripts/verify_release_sources.py` **PASS**: 137 file sotto SHA-256, 34 moduli C mappati 34/34 nell'integratore SDK.
- `python3 tests/test_source_manifest.py` **PASS**; `python3 tests/test_plan_github_sync.py` **PASS**.
- YAML caricato tramite PyYAML `BaseLoader`: `workflow_dispatch` preservato, trigger `push` solo sul ramo di revisione, e lista path verificata.
- `make -j2 test test-sdk-integration test-web-assets test-kotlin arm-smoke test-dashboard-lwip-abi` **PASS**.
- `make test-http-sanitized test-stream-sanitized test-tcp-transport-sanitized test-auth-stream-sanitized test-apconfig-live-socket test-auth-live-tcp test-dashboard-live-tcp` **PASS**: sanitizers e loopback host.
- `python3 tests/test_flash_map_audit.py`: **7/7 PASS** su mappe flash sintetiche; non equivale a mappa reale.
- Log completo: `GW006_CP23_VALIDATION.log`. `arm-smoke` esegue controlli su stub e non sostituisce la compilazione o il linking vendor.

## 5. Limiti confermati

- `git` nel container non riesce a risolvere `github.com` (DNS). Il connettore GitHub funziona per operazioni mirate, ma non ha sincronizzato i 141 file del pacchetto di review CP-23. La **sincronizzazione completa è PENDING**, non va dichiarata completata.
- La PR #2 non può essere usata come prova della disponibilità su GitHub di tutto il CP-23.
- Non è stato scaricato né compilato localmente l'SDK Realtek `Ameba-AIoT/ameba-rtos-d` commit `7569200fb8304daa61a9f09ccf439ada38d6de2e`; la compilazione nativa KM0/KM4 è **NON VERIFICATA**.
- Mancano backup flash reale verificato, mappa partizioni reale, procedura recovery collaudata, disponibilità di spazio per 96 codici al massimo, prova IR elettronica ed esecuzione sul WBRG1. **NON FLASHARE.**

## 6. Procedura esatta da cui riprendere — CP-24

1. In un computer con `git`/GitHub accessibili, estrarre `GW006_IR_UNIVERSAL_CP23_SOURCE_ONLY_NO_FLASH.zip` e verificare `python3 scripts/verify_release_sources.py`.
2. Clonare il ramo esistente `review/gw006-cp23-native-probe` (non `main`); eseguire il dry-run e poi la copia verificata con `scripts/plan_github_sync.py --source <cartella-estratta> --checkout <clone> [--apply]`.
3. Controllare `git diff --check`, file nuovi/modificati, manifest SHA-256, presenza di tutti i 34 moduli C, che non siano stati copiati segreti o binari. Prima di commit/push, esaminare il diff.
4. Commit e push **sul solo ramo review** dei 141 file consentiti. Il workflow `gw006-cp21-native.yml` nel pacchetto è predisposto ad avviarsi su quel ramo. Verificare l'effettivo run e scaricare **solo i log**, controllare errori KM0/KM4 e file compilati.
5. Conservare PR #2 in bozza; NON fare merge né flash prima delle verifiche hardware e del backup di recupero.

**Ripartenza: CP-24, prima attività = completare sync su review e ottenere log native KM0/KM4 del pacchetto CP-23, distinguendoli da quelli REV21.**
