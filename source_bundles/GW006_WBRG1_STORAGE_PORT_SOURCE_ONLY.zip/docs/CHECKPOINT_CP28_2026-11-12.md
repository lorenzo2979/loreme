# GW006 IR Universal — Checkpoint CP-28 — 12 novembre 2026

**SOURCE ONLY / NO FLASH.** Nessun accesso alla GW006; OpenBeken 1.18.321 intatto.

## Progressi effettivi

- Implementato `gwir_fj_play` nel modulo portable `gwir_flash_journal.c/.h`:
  lettura di un codice GWCD dalla memoria NOR transazionale e riproduzione di
  fino a cinque pacchetti IR con carrier, duty, sequenze e intervalli associati.
- Interfaccia con due callback obbligatorie: autorizzazione fisica del bus IR e
  invio di **un singolo frame**. L'autorizzazione va verificata prima dell'accesso
  alla flash e per ogni frame. In questo progetto è ancora negata dall'HAL GW006.
- Scratch array fornito dal chiamante, consigliati 2048 uint32_t = 8192 byte in
  memoria statica. Nessuna nuova allocazione grande sullo stack FreeRTOS.
- Semantica di errore esplicita: codice inesistente, lettura I/O, CRC/formato,
  buffer insufficiente, TX fallita, hardware non autorizzato. Un errore dopo
  l'invio dei primi frame non può rendere atomica la trasmissione IR.
- Corretto il percorso di lookup del journal per distinguere errore I/O da
  corruzione dei dati. Nessuna modifica al formato NOR preesistente.
- Nuovo `tests/test_flash_playback.c` con mock flash e IR; aggiunti target
  `make test-flash-playback-sanitized` e test automatico nel `make test`.
- Il manifest SHA-256 e la procedura di sync GitHub saranno verificati sui
  contenuti del pacchetto finale, non sono una prova di autenticità del codice.

## GitHub e compilazione

- La precedente REV21 ha superato KM0/KM4 sul runner GitHub Actions:
  https://github.com/lorenzo2979/loreme/actions/runs/43292963563
- NON è una build nativa CP-28: i sorgenti CP-28 completi non sono pubblicati
  sul ramo GitHub. Il ramo main non è stato modificato.
- Nel container GitHub non è raggiungibile tramite git (DNS). Il connettore
  permette scritture di testo ma non il caricamento diretto di questo archivio
  ZIP di sorgenti. La sync integrale NON va dichiarata effettuata.

## Bloccanti di rilascio

- Mancano integrazione autenticata dei comandi di playback nel runtime GW006,
  driver e IRQ reali, pinmux IR verificato, flash reale e sua partizione,
  backup integrale e recovery validato, collaudo fisico 96×5 e build+link CP-28.
- `ready_to_flash=false`. Non disabilitare il blocco di sicurezza.

## Ripresa CP-29

Eseguire sincronizzazione completa in un checkout GitHub di revisione pulito,
verificare source lock e compilare il CP-28 con l'SDK Realtek fissato al commit
7569200fb8304daa61a9f09ccf439ada38d6de2e. Ispezionare 34 oggetti ARM,
link map KM4 e log diagnostici. Non eseguire flash o merge automatico.
