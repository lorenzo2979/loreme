# GW006 CP-32 — authenticated TCP transport integration, source-only

Date: 2026-11-13. **NOT FLASHABLE.** This document is generated from a local build, not from a device test.

## Scope

- New `firmware/realtek/gwir_amebad_auth_server.{c,h}`: synchronous one-client-at-a-time authenticated TCP transport using GWIR runtime owner; socket receive/send deadlines required, no wildcard IP, STA-only callback, one owner session; no firmware credentials or boot nonce built in.
- `tests/test_amebad_auth_server.c`: real POSIX socketpair test with OpenSSL HMAC, signed status, replay denial, incomplete packet, no-credential and STA-denied paths.
- SDK integration mapping expands from 36 to 37 source C modules.
- Does **not** create a task or provision secrets; physical IR remains unavailable. Boot entry still only logs and optional dashboard (disabled by default).

## What remains

- Genuine vendor KM0/KM4 compile of CP-32 and inspection of remaining excluded modules in final AXF. New linker objects alone do not mean a bootable operational application.
- Board-specific credential provisioning, unpredictable nonce at every boot, safe storage, STA/AP interface enforcement, runtime task startup, IR pinmux/PCB validation, flash map, full dump and proven recovery.

OpenBeken 1.18.321 is **not modified**. No flash performed.
