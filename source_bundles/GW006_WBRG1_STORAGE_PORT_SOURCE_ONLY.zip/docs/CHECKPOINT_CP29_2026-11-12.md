# GW006 IR Universal — Checkpoint CP-29 — 12 novembre 2026

**SOURCE ONLY — NON FLASHARE.** OpenBeken 1.18.321 sulla scheda GW006 non è stato modificato.

## Lavoro implementato

- Comando `GWIR_TX_SAVED = 9`, payload `uint8 button` (0..95), risposta `GWIR_SAVED_STATUS = 0x91` con `[status, frames_done]`.
- `gwir_auth_dispatch_routed` autentica tramite GWAS HMAC-SHA256, nonce/counter anti-replay, CRC e validazione dei buffer **prima** di chiamare `gwir_saved_play_command`.
- `gwir_auth_stream_feed_routed` gestisce frammenti TCP solo dopo un intero messaggio autenticato; i vecchi API senza router restano incompatibili con la riproduzione salvata (UNSUPPORTED).
- `gwir_saved_play_init` azzera il contesto e vincola il servizio ad un archivio NOR, autorizzazione IR e scratch statico 2048 × uint32. Nessuna allocazione su stack FreeRTOS.
- Idempotenza fail-closed: sequenza GWIR strettamente crescente e nonzero; ultima sequenza/tasto restituisce risultato cache senza ritrasmettere; richieste più vecchie sono rifiutate. La cache è RAM, quindi una richiesta dopo reboot non è sicura da ripetere automaticamente.
- Conservati tutti i 96 tasti e fino a 5 pacchetti/tasto nel journal CP-28. Se il callback fisico non autorizza IR, nessuna lettura/trasmissione IR.
- Android Kotlin: helper payload e parsing risposta; NON è una APK pronta né un listener in esecuzione.

## Prove locali e limiti

I test simulano memoria NOR, firma HMAC reale su host tramite OpenSSL, pacchetti corrotti, replay di sessione e comando, serializzazione, RX occupata, record vuoti/corrotti, errori di lettura, revoca gate IR, interruzione TX dopo alcuni frame, risposte firmate e framing TCP frammentato. I test su host e sanitizzatori non dimostrano sicurezza di una rete reale o funzionamento su hardware GW006.

**Non dichiarare:** SDK-native KM0/KM4 CP-29 compilato, 35 oggetti ARM CP-29 realmente linkati, flash WBRG1 verificata, dispositivo collaudato, Wi-Fi pronto, firmware installabile. Gli archivi CP-29 locali NON sono stati pubblicati integralmente su GitHub. La precedente build nativa REV21 di GitHub è diversa da questo codice.

## Blocchi obbligatori ancora aperti

1. Sincronizzazione integrale del pacchetto sorgente su un ramo GitHub di revisione (non `main`).
2. Compilazione SDK ufficiale Realtek AmebaD KM0/KM4 al commit `7569200fb8304daa61a9f09ccf439ada38d6de2e`, con verifica di TUTTI i 35 file `.o` e mappa di link; risoluzione degli errori.
3. Installazione di un vero listener GWAS, credenziali/key storage e nonce RNG sicuri, ownership/serialization task, wiring autentico del journal, e GPIO/IRQ TX-RX validati.
4. Dump completo della flash, verifica partizioni e capienza per tutti i 96 record, prova di ripristino e alimentazione interrotta, controllo elettrico pinmux e portante IR.
5. Prove fisiche bidirezionali IR + Wi-Fi + nonvolatile, simulazione black-out e recovery **prima** di pensare a immagini installabili.

Il gate `ready_to_flash` resta **false**. Nessuna modifica a OpenBeken.
