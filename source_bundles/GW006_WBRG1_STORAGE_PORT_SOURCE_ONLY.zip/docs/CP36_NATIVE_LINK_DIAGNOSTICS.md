# CP-36 — Realtek KM4 final-link diagnostics: failure remains failure

**Scope: diagnostic-only.** Nothing here enables IR, flash writes, FreeRTOS services or device pairing. This checkpoint contains no installable firmware. The GW006/OpenBeken 1.18.321 must not be flashed or altered.

## Problem confirmed in CP-35

The pinned Realtek SDK compiled KM0 and KM4 and produced 39 genuine ARM object files. The strict final-link gate failed because 20 modules had no allocated sections in the final image. The previous gate raised an exception **before it wrote** the diagnostic JSON requested by GitHub Actions, making it harder to isolate which modules were excluded.

## CP-36 change

The strict final link-map parser now provides `analyze_map_report()` with:
- `not_loaded`: expected objects missing from the vendor linker LOAD records;
- `loaded_but_unallocated`: loaded objects whose allocated text/rodata/data/bss/etc sections were all removed or missing;
- `allocated_modules`: objects with allocated input sections;
- `link_gate_pass`: true only if every expected module is both loaded and allocated;
- `linked_evidence` and `firmware_installable`: **never promoted by host-only analysis**.

After validating the real linked ARM ELF, the native check **writes JSON even on final-link failure** and still exits nonzero. It does not weaken the existing strict rule that all mapped modules must contribute. This strict rule is a *source integration audit*, not a sufficient definition of firmware readiness: optional modules may be correctly discarded; required live services need genuine boot wiring and hardware/credential proofs.

Negative tests check missing LOAD records, 39 loaded but only 19 retained, 20 excluded, JSON persisted on failure and failure exit preserved. Host GNU ld map parsing and synthetic SDK fixtures remain separate from vendor CI evidence.

## Outstanding blockers

1. No verified physical secure key store, boot nonce freshness and protected pairing channel on the GW006; do not enable authenticated listener with guesses or hardcoded secrets.
2. The official SDK vendor `main.c` still reaches GWIR diagnostics but not a working provisioned FreeRTOS/lwIP auth + flash/IR runtime.
3. No actual board flash map, full backup and tested recovery.
4. No verified IR pinmux, electrical timings and full 96-key power-loss test on board.
5. A successful KM0/KM4 compile alone is **not** a deployable firmware.
