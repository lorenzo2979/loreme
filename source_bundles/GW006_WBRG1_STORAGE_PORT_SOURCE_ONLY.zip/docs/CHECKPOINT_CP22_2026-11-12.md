# GW006 IR Universal — CHECKPOINT CP-22

**Data:** 12 novembre 2026. **NON FLASHARE.** Sorgenti e test host soltanto, nessun nuovo firmware installabile, nessun lavoro eseguito sulla GW006. OpenBeken 1.18.321 sul dispositivo rimane intatto.

## Baseline e obiettivo
- Partenza: CP-21 del 12/11/2026; GW006 RSH-GW006, WBRG1 / RTL8721CSM.
- Firmware target ancora NON verificato su scheda; esistono le componenti sorgente per 96 tasti IR (36 TV / 14 clima / 32 decoder / 14 speaker), massimo 5 frame per tasto, crittografia GWAS e dashboard REV18.
- Obiettivo CP-22: **prevenire copie GitHub di file non recensiti o alterati** e preservare la riproducibilità di una futura build nativa, senza modificare main e senza toccare hardware.

## Modifiche eseguite
1. `scripts/plan_github_sync.py` rifiuta branch fuori da `review/*`, repository dirty, target non-root, sorgenti posti dentro il clone e destinazioni symlink. **Prima di qualunque dry-run/copia** controlla il manifesto SHA-256 CP-21, eventuali sorgenti C non censiti e la mappatura 34/34 C verso l'integratore SDK.
2. L'elenco di copia è **chiuso**: i 137 file elencati in `docs/CP21_SOURCE_MANIFEST.json`, più `README.md`, manifesto stesso e i checkpoint CP21 e CP22. Non copia per scansione indiscriminata `scripts/`, `tests/` o altri percorsi: ignora log locali, cache, file segreti non censiti e binari.
3. Rilegge e ricontrolla ciascun file bloccato prima della copia; scrive con file temporaneo e `os.replace`, fsync, controllo dei byte dopo copia e conserva i permessi POSIX dei sorgenti. Non esegue `git commit`, `git push` né procedure di flash.
4. `tests/test_plan_github_sync.py` amplia i test negativi: branch `main/develop`, checkout dirty, sorgente modificato, file `.py` non censito, extra segreto non copiato, symlink sorgente/destinazione, e confronto finale dei byte e permessi dopo copia.
5. Rigenerato il manifesto CP-21 per proteggere le nuove versioni dei due file `.py`; rimane **137 file**, dei quali **34** moduli firmware C. Il nome del manifesto resta CP-21 perché viene esteso senza alterare il protocollo o ABI.

**Limite di sicurezza:** il manifesto SHA-256 non è una firma e non autentica la provenienza del codice; chi può modificare sia sorgenti sia manifesto può creare un pacchetto internamente coerente ma non attendibile. La copia è verificata file per file, non transazionale come insieme se il processo viene interrotto. Va sempre esaminato `git diff` prima di un commit.

## Test CP-22 realmente eseguiti su computer
- `python3 scripts/verify_release_sources.py`: **PASS**, 137 file e 34 moduli C integrati nel mapping SDK.
- `python3 tests/test_source_manifest.py`: **PASS**, manomissioni e anomalie rifiutate.
- `python3 tests/test_plan_github_sync.py`: **PASS**, simulazione Git locale con dry-run/apply e test negativi; nessuna rete necessaria.
- `make -j2 test test-sdk-integration test-web-assets test-kotlin arm-smoke test-dashboard-lwip-abi`: **PASS**.
- `python3 tests/test_flash_map_audit.py`: **7 casi PASS** su mappe sintetiche.
- `make test-http-sanitized test-stream-sanitized test-tcp-transport-sanitized test-auth-stream-sanitized test-apconfig-live-socket test-auth-live-tcp test-dashboard-live-tcp`: **PASS** (ASan/UBSan e TCP loopback host).
- I log stanno in `GW006_CP22_VALIDATION.log`. I test SDK sono **mock**, la compilazione ARM è **syntax only** con stub: NON equivalgono a compilazione/link vendor KM0/KM4.

## GitHub e blocchi reali
- Repository: `https://github.com/lorenzo2979/loreme`, ultimo HEAD esaminato prima dei lavori CP-22: `5892d2dd96a50be19a65d87a385fdb5a9ef1fc97` (CP-19); non è stata eseguita alcuna modifica remota in questo passaggio.
- CP-22 **NON pubblicato su GitHub**. Nel ramo `main` precedentemente esaminato c'erano 21 moduli C autonomi contro 34 nel pacchetto locale CP-21/CP-22, non contando eventuali moduli dentro un ZIP di delta.
- Il container non ha accesso DNS a `github.com` tramite Git CLI. Nessuna build nativa vendor KM0/KM4 e nessuna CI CP-22 avviata; la workflow `.github/workflows/gw006-cp21-native.yml` è pronta ma va pubblicata prima di poter essere eseguita.
- SDK target già individuato: `Ameba-AIoT/ameba-rtos-d` commit `7569200fb8304daa61a9f09ccf439ada38d6de2e`, non scaricato localmente.

## Perché NON è pronto per la scheda
- Manca mappa flash reale, backup integrale verificato e un recupero hardware collaudato; per 96 codici massimi la stima minima CP-19 è 4.333.568 byte per il primo popolamento, senza margine di riscrittura/garbage collection.
- Le API IR web autenticate e la connessione completa Wi-Fi/FreeRTOS/motore IR non sono operative sulla scheda.
- Pin PA25 TX (con LED rosso), PA26 RX e alternativa PB31 sono candidati da verificare elettricamente; transistor BC337 / resistenza 1 kΩ senza collaudo sul modulo reale.
- Non esiste un binario `.bin` completo, qualificato e sicuro da installare.

## Ripartenza CP-23
1. Verificare integrità ZIP CP-22 e manifesto; usare `scripts/plan_github_sync.py --checkout <clone-su-branch-review>` in sola lettura, poi `--apply` **solo** su clone verificato e vuoto di modifiche.
2. Esaminare `git diff --check`, `git status`, hash, permessi e contenuto; eseguire commit/push di sorgenti su branch `review/` e aprire PR dopo revisione. **Non pubblicare ZIP come firmware.**
3. Eseguire manualmente `gw006-cp21-native.yml` sul branch, ispezionare risultati KM0/KM4 e rispettare i gate; non equivale a validazione hardware.
4. Senza flash prematuro: backup OpenBeken, mappa partizioni reale, recovery, verifica driver vendor, compattazione memoria, integrazione servizi autenticati, pinmux e prova con strumenti.

**Checkpoint finale CP-22: `SOURCE-GATE HOST TESTED`, `GITHUB SYNC PENDING`, `NATIVE KM0/KM4 NOT RUN`, `BOARD UNTOUCHED`.**
