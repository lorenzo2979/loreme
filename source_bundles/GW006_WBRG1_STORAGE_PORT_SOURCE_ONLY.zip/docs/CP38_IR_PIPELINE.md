# CP-38 — GW006 authenticated IR pipeline (SOURCE ONLY, NO FLASH)

Real device target: Tuya GW006 / WBRG1 / RTL8721CSM / AmebaD, OpenBeken 1.18.321 untouched.

## Concrete new functionality

- `gwir_ir_pipeline` attaches the existing engine HAL to the serialized half-duplex bus and the IRQ FIFO/capture builder. Real TX is sent via the bus state machine with timeout and 1ms cooperative polling; RX pulses are decoded in task context and retained until phone ACK.
- The `gwir_sdk_bootstrap` optionally creates this bridge **only** if an externally validated board port supplies static storage, IR configuration, and affirmative authorization. Absent or invalid board configuration does not enable IR.
- `gwir_sdk_auth_task` binds the IR FIFO pump to the authenticated owner task, never a competing worker. The TCP server checks the queue at <=20ms receive/accept intervals while RX is armed, with bounded idle sessions. Both acceptance and delivery remain STA/HMAC gated.
- Revoking the physical IR permission mid-transmission makes the bus abort, not continue. Unsuccessful start and task termination disable hardware state; no firmware image is emitted.

## Test scope / limits

The fake hardware and compiler-stub tests are NOT proof of pinmux or electrical behavior. The vendor bus's `board_ir_ready` callback is still hardcoded FALSE; the real GW006 IR TX/RX pins, LED conflict, IRQ mapping and active-level remain unapproved. No provisioned secret, validated boot nonce source, flash-map/partition backup+recovery or physical device trial exists. In the absence of an audited GW006 provider, boot schedules **no** IR service. Capture spans >512 pending RX events need the owner pump to keep pace; actual load still requires bench verification.

The final-link gate is intentionally fail-closed for modules lacking allocated sections. Even if all C modules compile on Realtek, a usable flashable firmware cannot be declared until the physical checks above succeed. A mock SDK build is not a native Realtek vendor build.
