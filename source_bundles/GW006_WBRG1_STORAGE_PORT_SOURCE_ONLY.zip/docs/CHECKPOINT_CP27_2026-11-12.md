# GW006 IR Universal — Checkpoint CP-27 — 2026-11-12

**Stato: sorgenti e diagnostica soltanto. Nessun firmware installabile, nessun flash.**

## Progressi verificati da GitHub Actions

La precedente pipeline diagnostica REV21 (NON il nuovo pacchetto CP27) sul ramo `review/gw006-cp23-native-probe` è stata corretta per reintegrare cinque costanti mancanti nello stub **host-only** `tests/stubs/ameba_soc.h`. Questa modifica non tocca la mappatura fisica dei pin, né il Realtek SDK, né OpenBeken.

- Primo run REV21 `43259713771`: **FAILED** nei test host per simboli `_PB_31`, `_PA_26`, `_PB_23`, `_PA_25`, `_PB_22` non definiti; nessuna build SDK era stata raggiunta.
- Run REV21 di prova `43292963563`, commit `280ada7b8f57d50a5e465e930fd50619a04e6a5c`: **SUCCESS**, incluso `KM0_EXIT=0`, `KM4_EXIT=0`, `KM4_REV21_SOURCES_COMPILED=YES`. SDK puntato a `7569200fb8304daa61a9f09ccf439ada38d6de2e`. Log e diagnostica: https://github.com/lorenzo2979/loreme/actions/runs/43292963563
- Workflow test core sullo stesso commit: **SUCCESS**.
- Il run REV21 ha integrato il precedente pacchetto `source_bundles/GW006_REV21_GITHUB_DELTA.zip`, non i sorgenti CP26 o CP27. Non dimostra un'immagine GW006 funzionante e non include verifica fisica, flash map reale o prova di tutte le 34 unità CP27.

## Miglioramento locale CP-27

- Nuovo audit offline `scripts/audit_runtime_readiness.py` e test `tests/test_runtime_readiness.py`. Il programma identifica i blocchi attuali: driver IR fisico sempre non autorizzato, pulsante APConfig disabilitato, dashboard in modalità di prova disabilitata, main SDK con sola diagnostica, build finale non verificata e mancanza di backup/layout/pinout e test 96×5 sul dispositivo.
- L'opzione `--require-ready` **fallisce intenzionalmente** finché non esiste prova indipendente nativa e fisica; NON è un bypass per abilitare il firmware.
- Suite host e CI aggiornate per produrre un report JSON con valori `ready_to_flash=false` / `ir_tx_rx_enabled=false`.
- Manifesta sempre la distinzione tra compilazione REV21 riuscita e funzionalità runtime effettiva.

## Limitazioni e prossima ripresa

1. **Sorgenti CP-27 non sincronizzati su GitHub**; la pull request #2 rimane in bozza, sul ramo di revisione, e `main` non va modificato senza ulteriore verifica.
2. Prima di affermare che CP27 sia compilabile nativamente, sincronizzare la nuova snapshot verificando SHA-256 dell'intera allowlist, avviare pipeline specifica CP27 e leggere oggetti KM4 e mappa link.
3. Il backup integrale della GW006, il layout effettivo flash, il ripristino e il vero pinmux IR rimangono da attestare; **non installare firmware e non modificare OpenBeken 1.18.321**.
4. Il firmware attuale è esplicitamente incompleto come runtime autonomo, nonostante i moduli IR/flash/HTTP possano superare i test software.

**Checkpoint seguente: CP-28** — sincronizzare source snapshot e provare build/link reali del pacchetto corrente, poi approfondire la connessione sicura delle funzioni runtime, senza flash.
