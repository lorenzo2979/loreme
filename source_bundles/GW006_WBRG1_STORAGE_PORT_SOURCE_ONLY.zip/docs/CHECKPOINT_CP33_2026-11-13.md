# GW006 IR Universal — CP-33 | 13 novembre 2026

## Obiettivo unico: avvio FreeRTOS autenticato, senza flash

Punto di partenza: CP-32, 37 moduli firmware C compilati nell'SDK Realtek; KM0/KM4 passati ma linker finale con 18 moduli non allocati. OpenBeken 1.18.321 sulla GW006 intatto.

### Modifiche reali CP-33

- `firmware/sdk/gwir_sdk_auth_task.{c,h}`: adattatore FreeRTOS per il listener TCP autenticato. Non viene avviato dal `main()` vendor. Per avviarlo un integratore della scheda deve prima inizializzare `gwir_runtime_owner` con chiave unica del dispositivo, nonce imprevedibile a ogni boot, motore IR e buffer in memoria statica; eventuale memoria flash deve essere montata in partizione verificata. Nessuna chiave/nonce di prova dentro firmware.
- Il task richiede rete STA-only, associazione, interfaccia e link attivi, IPv4 non locale/non broadcast, porta >=1024; effettua il bind esclusivamente all'IP STA verificato. `gwir_amebad_auth_server_run` ricontrolla lo stato a ogni ricezione. AP e STA+AP sono respinti.
- Una sola attività FreeRTOS; `request_stop` richiede arresto e chiusura; al termine, anche per disconnessione Wi-Fi/errore, le sessioni sono cancellate usando `gwir_runtime_owner_clear`. No IR pinmux, no flash di scheda, no listener senza credenziali.
- `scripts/integrate_amebad_sdk.py`: ora include 38 moduli firmware C. I test d'integrazione verificano 39 oggetti (38 + main).

### Verifiche e limiti

Test host SDK simulato + test adapter di FreeRTOS/STA + ASan/UBSan, protocollo, memoria, rete, dashboard e Kotlin eseguiti con esito PASS nella fase locale. Una reale build KM0/KM4 **CP-33** non può essere dichiarata riuscita senza la relativa esecuzione GitHub nativa e i suoi log. L'assenza di un boot provider sicuro e di una partizione di flash reale impedisce tuttora di abilitare la trasmissione IR.

ATTENZIONE: la sola compilazione di un modulo o la sua presenza in una mappa non ne dimostra il funzionamento sulla GW006. Le funzioni opzionali non devono essere trattenute artificialmente dal linker. Il linker gate può continuare a fallire finché il boot non inizializza e invoca i servizi effettivi; non va disattivato per ottenere un risultato verde.

### Ripartenza

1. Ottenere prova nativa CP-33 nell'SDK ufficiale, revision `7569200fb8304daa61a9f09ccf439ada38d6de2e`.
2. Integrare un vero provider di chiavi per dispositivo e nonce sicuro, persistente e recuperabile, **senza** inserirli nel repository. Collegare inizializzazione e registrazione del servizio solo quando il materiale è disponibile.
3. Eseguire verifica del link **funzionale** e del runtime, distinguendo core richiesti e servizi opzionali; non nascondere moduli esclusi.
4. Prima di ogni flash sulla GW006: backup/dump completo, mappa partizioni, spazi NOR per 96×5 IR, pinmux/elettronica e procedura di recupero provata.

**Nessun firmware installabile generato o consegnato. Nessun flash.**
