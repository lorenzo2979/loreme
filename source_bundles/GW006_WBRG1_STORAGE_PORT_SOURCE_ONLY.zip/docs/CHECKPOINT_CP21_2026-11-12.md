# GW006 IR Universal — Checkpoint CP-21 (12 novembre 2026)

**STATO: SOLO SORGENTI E TEST SU COMPUTER. NON FLASHARE.**
OpenBeken 1.18.321 presente sulla GW006 WBRG1/RTL8721CSM resta invariato.
Nessun `.bin` avviabile GW006, nessun backup hardware verificato e nessuna lettura/scrittura fisica.

## Risultati nuovi CP-21

1. `scripts/verify_release_sources.py` e `docs/CP21_SOURCE_MANIFEST.json`: controllo SHA-256 **137** file sorgente/test/documenti di configurazione selezionati, presenza e dimensione, blocco di symlink e path non canonici, rifiuto di moduli C nuovi non censiti. Confronta inoltre i **34 moduli C firmware** con la mappa `GROUPS` dello script di integrazione SDK. Questa è una protezione contro omissioni/alterazioni accidentali, **non** una firma digitale o garanzia contro chi può alterare insieme codice e manifesto.
2. `tests/test_source_manifest.py`: casi negativi per modifica byte, file mancante, sorgente aggiunto, percorso ambiguo, symlink e hash non valido.
3. `scripts/plan_github_sync.py` + `tests/test_plan_github_sync.py`: piano di copia sorgenti in un clone Git *pulito* su ramo di revisione, asciutto per default, `--apply` solo su richiesta. Nessun commit/push automatico. Rifiuta ramo `main`/`master`, checkout dirty, symlink di destinazione.
4. `.github/workflows/gw006-cp21-native.yml`: workflow **manuale** `workflow_dispatch`, preflight fonti, host regression, SDK pin SHA, integrazione SDK e build/link KM0/KM4 con upload **solo dei log**, non di immagini firmware.
5. SDK ufficiale puntato al commit `7569200fb8304daa61a9f09ccf439ada38d6de2e` (Realtek AmebaD; identificativo verificato via GitHub); non è stato scaricato in questa sessione perché la rete del container non risolve github.com.

## Verifiche eseguite in questa sessione (host)

- `python3 scripts/verify_release_sources.py`: PASS, 137 file, 34 C in GROUPS.
- `python3 tests/test_source_manifest.py`: PASS, casi negativi.
- `python3 tests/test_plan_github_sync.py`: PASS, simulazioni locali senza push.
- `make test`: PASS; inclusi journal CP20 e 96 tasti.
- `make test-sdk-integration`: PASS, SDK mock 35 oggetti C (34 firmware + main), non vendor reale.
- `make test-web-assets`: PASS.
- `make arm-smoke`: PASS, sintassi Cortex-M23/M33 con header stub, **non** linking Realtek.
- `make test-dashboard-lwip-abi`: PASS, shim host.
- `python3 tests/test_flash_map_audit.py`: 7 PASS, mappa sintetica.
- `make test-kotlin`: PASS, Kotlin/JVM host.
- Risultati completi: `GW006_CP21_LOCAL_VALIDATION.log`.

## Stato GitHub osservato il 12/11/2026

- `lorenzo2979/loreme` branch `main`, HEAD `5892d2dd96a50be19a65d87a385fdb5a9ef1fc97` relativo a CP19.
- Workflow core CP19 `43161684913`: `success`.
- GitHub contiene soltanto **21 file firmware .c direttamente nella tree**, contro i **34** del CP-21 locale; **13 moduli C non sono file autonomi nel branch**. È possibile che alcuni siano in `source_bundles/GW006_REV21_GITHUB_DELTA.zip`: la differenza riguarda l'albero diretto, non il contenuto di quell'archivio.
- I sorgenti CP20/CP21 e il nuovo workflow NON sono ancora sincronizzati sul branch remoto. NON affermare che CP21 CI è stata eseguita su GitHub.

## Prossimo passo — gate reale

1. Sincronizzare l'archivio sorgenti CP-21 su branch GitHub di revisione, verificando tutti gli hash e i diff prima del commit. Procedura locale (solo per un clone separato):

   `python3 scripts/plan_github_sync.py --checkout /percorso/clone`

   `python3 scripts/plan_github_sync.py --checkout /percorso/clone --apply`

   Controllare `git diff`, commit su ramo di revisione ed eventualmente aprire PR; non automatizzato da questo pacchetto.
2. Avviare manualmente `.github/workflows/gw006-cp21-native.yml` sul ramo sincronizzato; leggere KM0/KM4 e log di ABI. Anche un `success` non dimostra correttezza del pinmux, memoria flash, circuito IR o compatibilità del binario con GW006.
3. Backup completo e recovery collaudato; verificare mappa flash reale, dimensioni/sector erase e capienza minima 4.333.568 B più margine aggiornamenti; poi progettare adapter fisico flash e compattazione sicura.
4. Integrare API IR web autenticata e servizi runtime FreeRTOS/STA, test con strumentazione hardware, senza pregiudicare APConfig aperta.
