# GW006 IR Universal — CHECKPOINT CP-26 (2026-11-12)

**STATO: SOURCE-ONLY / NO FLASH.** Test host e simulazioni ≠ build vendor Realtek, ≠ firmware installabile.

## Miglioramento CP-26: prova di collegamento KM4 finale

- Nuovo `scripts/verify_native_km4_link_map.py`, eseguito **soltanto dopo** il controllo dei 34 oggetti ARM CP-25. Controlla il file `GCC-RELEASE/project_hp/asdk/image/text_image2_ns.map` e il file linkato `target_img2.axf` dell'SDK fissato al commit `7569200fb8304daa61a9f09ccf439ada38d6de2e`.
- Richiede in una mappa GNU ld la regione **Linker script and memory map**, `LOAD build/ram/<modulo>.o` per tutti i 34 moduli e, per ognuno, una sezione allocata `.text`/`.rodata`/`.data`/`.bss`/ecc. con dimensione maggiore di zero. Non contano le sole sezioni scartate, né file `.o` solo compilati ma assenti dal link finale.
- Gestisce righe di mappa GNU ld di una o due righe. Controlla anche freschezza file, assenza di symlink sul file di output, header ELF32 little-endian ARM, tipo linked `ET_EXEC/ET_DYN` e almeno un segmento caricabile PT_LOAD.
- `tests/test_native_km4_link_map.py` include casi negativi su mappe artificiali, il parsing di una mappa generata davvero da GNU ld sul computer e una **simulazione SDK integrata** con 34 oggetti ARM sintetici. Le prove sono host/sintetiche, non una build Realtek.
- La workflow `.github/workflows/gw006-cp21-native.yml` avvia il nuovo gate dopo `make` KM4 e gli oggetti CP-25; salva SOLO `native_logs/km4_final_link.json` con gli altri log e **non carica immagini firmware**.

## Limiti e sicurezza

1. **Nessuna compilazione nativa Realtek KM0/KM4 confermata** con il pacchetto CP-26. La sincronizzazione completa su GitHub rimane da eseguire.
2. La prova di link **non attesta il corretto funzionamento dei 34 moduli**, né l'effettiva attivazione delle funzioni o la compatibilità della scheda. Un link riuscito può comunque non soddisfare il progetto.
3. Layout flash effettivo, archiviazione 96 tasti × 5 pacchetti nel dispositivo, pinout IR, backup completo e recupero hardware restano da verificare. **Non caricare alcun firmware sulla GW006**.
4. Il firmware OpenBeken 1.18.321 attualmente sulla scheda deve rimanere intatto.
5. La PR GitHub n. 2 resta una bozza REV21; non affermare che includa questi sorgenti senza una sincronizzazione esplicitamente verificata.

## Ripresa CP-27

Sincronizzare solo la allowlist in un ramo `review/...` con autorizzazione al repository, controllare l'intero manifesto SHA-256 e il diff; avviare la workflow del pacchetto CP-26. Leggere il reale `native_logs/RESULTS.txt` e `km4_final_link.json`. Se il gate rivela moduli esclusi dalla mappa, correggere cablaggio software e riferimenti, **senza flash**. Mai effettuare merge automatico su `main`.

## Stato test locale

**Eseguiti e passati localmente**:

- `python3 scripts/verify_release_sources.py`: 141 file SHA-256, 34 C con corrispondenti mappature SDK.
- `tests/test_source_manifest.py`, `tests/test_plan_github_sync.py`, `tests/test_native_km4_objects.py`, `tests/test_native_km4_link_map.py`: integrità/manipolazioni, copia Git di prova, oggetti ARM sintetici e parser link map (anche generata da GNU ld host).
- `make -j2 test test-sdk-integration test-web-assets test-dashboard-lwip-abi`: test C firmware/host, storage 96 tasti, integrazione SDK finta, dashboard e ABI mock.
- `make test-kotlin arm-smoke`: Kotlin/JVM, compilazione ARM *solo stub*.
- `make test-http-sanitized test-stream-sanitized test-tcp-transport-sanitized test-auth-stream-sanitized test-apconfig-live-socket test-auth-live-tcp test-dashboard-live-tcp`: ASan/UBSan e TCP loopback host.
- `python3 tests/test_flash_map_audit.py`: sette mappe flash sintetiche, **nessuna mappa reale GW006**.

La prima esecuzione di tutti i comandi insieme ha raggiunto il limite di tempo e **non è stata conteggiata come successo**; tutti i gruppi sopra sono stati ripetuti e completati con uscita zero. Il log è salvato separatamente in `GW006_CP26_VALIDATION.log`.

**PENDING**: source sync GitHub, KM0/KM4 nativi, mappa reale della flash, wiring IR e recovery. Non usare questo documento come prova di compilazione Realtek né di installabilità.
