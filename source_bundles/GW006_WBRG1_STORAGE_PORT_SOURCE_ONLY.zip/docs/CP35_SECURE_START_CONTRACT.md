# CP-35 — Secure startup boundary (source-only; NO FLASH)

## Why this change exists

The current SDK integration builds GWIR sources but does not start an authenticated
runtime. Boot cannot be enabled safely until the board supplies a device-specific
secret, a cryptographically strong **fresh boot nonce**, and a way to deliver the
nonce to the correctly authenticated Android peer. An untrusted/public nonce
announcement or a constant key is NOT an acceptable workaround.

The pinned official AmebaD SDK at `7569200fb8304daa61a9f09ccf439ada38d6de2e`
contains `rtw_get_random_bytes()` in `component/os/os_dep/osdep_service.c`:
its wrapper returns `0` even when its `osdep_service.rtw_get_random_bytes`
function pointer is absent. Therefore success code `0` **alone is not proof of
entropy**. No generic Wi-Fi RNG is used by the new GWIR module.

## Implementation

`firmware/sdk/gwir_sdk_secure_start.{c,h}` provides a fail-closed entry point
`gwir_sdk_secure_start()` requiring all five **platform-supplied** callbacks:
trusted security/storage verification, device-key retrieval, fresh CSPRNG nonce
generation, nonce freshness attestation across boot epochs, and **authenticated**
nonce delivery. It then initializes the serialized owner and requests the
FreeRTOS STA-only listener. All local key material is explicitly wiped even
when a callback fails. On any error after owner initialization, the owner and
session secrets are erased. Missing callbacks/assurance reject without starting
any listener. The old task layer enforces STA-only mode/link/IP and remains
separately fail-closed.

These callbacks are **interfaces**, not implemented cryptographic security
or hardware attestation. The real GW006 provider MUST be separately reviewed;
never use test mocks or a simple `return 1` as on-device evidence.

## Tests and limitations

- `tests/test_sdk_secure_start.c`: missing/trust-denied/partial key/entropy/
  nonce freshness/authenticated delivery/task failure all deny, valid mocked
  provisioner initializes exactly once; no reinitialization of live owner.
- Host ASan/UBSan, SDK mock integration, source lock and Android regression.
- One additional native SDK C module. **No new vendor `main.c` auto-start hook**:
  enabling a listener with no trustworthy provider would be insecure.
- Official native KM0/KM4 compilation needs its own GitHub Actions result
  for this exact source snapshot. Tests with stubs are not hardware tests.
- The last final-link gate still excludes many modules: adding this adapter
  **does not fix final-link reachability** without real platform provisioning.

## Release blockers

1. Proven per-device secret store with a safe provisioning and revocation flow.
2. A reviewed target CSPRNG/TRNG and robust nonce *non-reuse* across restarts.
3. Authenticated nonce distribution to the paired Android client.
4. Verified STA lifecycle, real IR pinmux, NOR partition and all 96 records.
5. Full chip flash backup, verified recovery procedure, physical tests.

**`ready_to_flash=false`. Existing OpenBeken 1.18.321 remains untouched.**
