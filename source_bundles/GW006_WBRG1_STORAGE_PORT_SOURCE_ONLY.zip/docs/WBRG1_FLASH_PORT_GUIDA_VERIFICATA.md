# GW006 IR Universal — collegamento flash WBRG1 e ricerche tecniche

**Stato:** sorgenti integrati + verifiche locali; **non è un firmware pronto per il flash**.

## Evidenza da guide e utenti

- `https://github.com/jasperw1996/ambd_sdk_GW018-DM`:
  implementazione autonoma AmebaD su WBRG1/RTL8721CSM, con build KM0/KM4 e
  avvio su GW018-DM. I tre output documentati sono `km0_boot_all.bin` dalla
  cartella `project_lp`, `km4_boot_all.bin` e `km0_km4_image2.bin` da
  `project_hp`. **GW018-DM non prova il corretto cablaggio della GW006.**
- `https://www.elektroda.com/rtvforum/topic4127578.html`:
  interventi su RSH-GW006 con WBRG1 e procedura di backup/accesso bootloader.
  Sulla GW006 PA25=LED rosso, PB22=LED blu, PB23=pulsante. PA25 non è
  disponibile per IR TX senza verifica/ispezione elettrica; PA26 ha anche
  funzione PTA_REQ nella scheda del modulo, quindi occorre verificare
  l'utilizzo sulla PCB.
- `https://developer.tuya.com/en/docs/iot/wbrg1-module-datasheet?id=Ka015vo8tfztz`:
  RTL8721CSM, flash esterna da 8 MiB. PB31 è marcato AOUTP_L (audio), ma
  questa dicitura da sola non determina tutte le alternative pinmux del SoC.
- `https://github.com/Ameba-AIoT/ameba-rtos-d`:
  API originali `flash_stream_read`, `flash_stream_write`,
  `flash_erase_sector`, `flash_read_id`, `device_mutex_lock(RT_DEV_LOCK_FLASH)`.
  La scrittura/cancellazione **non è mai autorizzata dalla guida**.

## Proposta di layout per un firmware *autonomo* dopo la sostituzione

| Offset da inizio flash | Ampiezza | Scopo proposto |
| --- | ---: | --- |
| 0x000000–0x1FFFFF | 2 MiB | bootloader, app OTA1/OTA2, parametri SDK: non toccati dal port |
| 0x200000–0x6FFFFF | 5 MiB | esclusivamente archivio IR GWCD, **se autorizzato da layout reale** |
| 0x700000–0x7FFFFF | 1 MiB | non usato dal port; eventuali dati da definire |

Dimensione richiesta dall'archivio completo con una sostituzione atomica:
**4.378.624 byte**. Spazio proposto: **5.242.880 byte**, margine **864.256 byte**.
I due indirizzi OTA di esempio dell'SDK Realtek sono 0x6000 e 0x106000
(offset relativi da 0x08000000). La configurazione SDK include anche
`AP_SETTING_SECTOR=0x1FB000`, `FTL_PHY_PAGE_START_ADDR=0x1FC000` e
`FAST_RECONNECT_DATA=0x1FF000`. Il layout proposto lascia tutto il primo
spazio da 2 MiB intatto. **Non costituisce prova** che il chip fisico abbia
quella mappa, che OTA2 si fermi prima di 0x200000 o che altri componenti
non usino gli stessi indirizzi.

## Codice implementato

`firmware/realtek/gwir_wbrg1_flash_port.{h,c}` implementa l'interfaccia
`gwir_fj_io` con API vere dell'SDK, mutex flash, controlli sui limiti,
preverifica 1->0, verifiche di lettura dopo programmazione e dopo cancellazione.
Verifica JEDEC capacity byte 0x17 (8MiB) prima di restituire un port valido.

**Il driver è deliberatamente DISABILITATO nel firmware standard** tramite
`GWIR_WBRG1_STORAGE_APPROVED=0`. L'attivazione richiede revisione hardware,
prova completa di backup/ripristino e aggiornamento esplicito di una build
separata. Anche quando è abilitato, il chiamante deve aprire il journal e
registrare il servizio nel bootstrap sicuro: questo collegamento runtime
**non è ancora presente** nei binari precedenti e non è fatto da questo port.

## Verifiche eseguite

- Test nuovo driver (disabilitato) PASS, nessun accesso flash.
- Test con memoria NOR emulata PASS (JEDEC, limiti, protezione scritture,
  lettura conferma, cancellazione, errori, byte sentinella esterni).
- Regressione host del progetto PASS.
- Compilazione **compile-only** per Cortex-M23/M33 con stubs PASS.
- Test integratore SDK simulato: 42 C del firmware + main.c PASS.
- Build reale sullo specifico SDK Realtek dopo questa nuova modifica:
  **NON ancora eseguita**. Compilazioni reali precedenti riguardavano
  la versione senza questo port.

## Impedimenti per il firmware utilizzabile

- Driver fisico IR/GPIO non verificato, e revoca hardware sempre attiva.
- Nessun provider per credenziali e nonce sicuri passato a `gwir_sdk_boot_register`.
- Nessun montaggio del journal tramite `gwir_wbrg1_flash_port_attach`
  nella sequenza di avvio del dispositivo.
- Nessuna prova di avvio sulla scheda, dump dell'esemplare e ripristino.

**NON FLASHARE.** Non utilizzare firmware o dump pubblici di terzi per
scrivere i dati nella propria GW006. OpenBeken presente non è stato alterato.
