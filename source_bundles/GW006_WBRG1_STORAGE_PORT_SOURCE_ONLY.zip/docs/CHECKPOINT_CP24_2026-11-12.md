# GW006 IR Universal — CHECKPOINT CP-24 (12 novembre 2026)

**Stato:** CP24 LOCAL SOURCE GATE PASS / 34 KM4 OBJECTS UNIT TESTS PASS (SYNTHETIC) / HOST REGRESSION PASS / GITHUB SYNC INCOMPLETE / REALTEK NATIVE BUILD NOT VERIFIED / DEVICE UNTOUCHED.

## 1. Vincoli da mantenere

- Gateway GW006 / Tuya WBRG1 RTL8721CSM, OpenBeken **1.18.321** sul dispositivo.
- **NON FLASHARE**, non cancellare OpenBeken, non cambiare pinmux o bootloader e non pubblicare un firmware come pronto per il dispositivo.
- Obiettivo funzionale invariato: 96 tasti IR (TV 36, clima 14, decoder 32, speaker 14), fino a 5 pacchetti per tasto, con salvataggio non volatile, dashboard web e autenticazione TCP.
- Backup flash e layout partizioni verificati sul dispositivo, procedura di recovery e prove fisiche IR ancora **ASSENTI**. L'esistenza nominale di 8 MB non prova lo spazio disponibile per i 96 codici massimi.

## 2. Punto di partenza CP-23

- Archivio: `GW006_IR_UNIVERSAL_CP23_SOURCE_ONLY_NO_FLASH.zip`.
- Repository `lorenzo2979/loreme`, `main` al commit `5892d2dd96a50be19a65d87a385fdb5a9ef1fc97` in data di verifica; non aggiornato in questa fase.
- Ramo review: `review/gw006-cp23-native-probe`; PR bozza #2 https://github.com/lorenzo2979/loreme/pull/2 ; head verificato `ceb3b5a1abbdd962f5fbf392c26824cc9126c6ba`.
- GitHub PR #2 è una prova di baseline REV21, **non** la sincronizzazione dei 139 file CP24.
- La descrizione della PR bozza #2 è stata aggiornata dal connettore GitHub con lo stato CP-24 locale, ribadendo che i sorgenti **non** sono pubblicati; la PR resta bozza e non è stata unita a main.
- Connettore GitHub ha restituito 0 workflow run PR-triggered e 0 status per quel commit; ciò **non verifica** l'assenza di eventuali run `push`, non dimostra successo nativo.

## 3. Lavori effettivamente svolti in CP-24

1. Recuperato ed estratto CP-23 con controllo ZIP, senza alterare gli archivi precedenti. Conservati i permessi di esecuzione dagli attributi ZIP, inclusi `scripts/cross_arm_smoke.sh`.
2. Aggiunto `scripts/verify_native_km4_objects.py`: preflight dopo copia nel vendor SDK che verifica **i 34 sorgenti e le registrazioni Makefile**, e postbuild che richiede 34 oggetti `.o` non vuoti, non symlink e datati dopo il marker di avvio KM4. Gate **fail-closed**, non prova link-map o esecuzione su GW006.
3. Aggiunto `tests/test_native_km4_objects.py`: prova host sintetica per tutti 34 gli oggetti e rifiuto di mancanti, vuoti, vecchi, symlink, sorgenti modificati o mapping Makefile duplicato/assente.
4. Aggiornato il workflow `.github/workflows/gw006-cp21-native.yml`: lancia il test CP24, preflight dopo integrazione SDK e verifica oggetti solo dopo `make` KM4 riuscito. **Workflow locale non ancora pubblicato su GitHub**.
5. Aggiornato l'allowlist `scripts/plan_github_sync.py` per includere le note CP23 e CP24, oltre ai vecchi documenti: 139 file sotto hash + 6 documenti/manifesto = **145 file di copia controllata**.
6. Manifesto `docs/CP21_SOURCE_MANIFEST.json` aggiornato ai nuovi hash: **139 file**, **34 sorgenti C** mappati nel build SDK.
7. Nessun sorgente firmware C, header, pinmux, schema flash o chiave crittografica modificati in CP24.

## 4. Prove realmente eseguite

- `python3 scripts/verify_release_sources.py`: PASS, 139 sorgenti sotto SHA-256 e 34 C dichiarati.
- `python3 tests/test_native_km4_objects.py`: PASS con SDK sintetico; **non compilazione SDK nativa**.
- `python3 tests/test_source_manifest.py`: PASS alterazioni, percorsi, symlink, integrità.
- `python3 tests/test_plan_github_sync.py`: PASS copia Git review isolata simulata, senza push.
- `python3 tests/test_flash_map_audit.py`: PASS 7 mappe sintetiche; nessuna mappa reale.
- `make -j2 test test-sdk-integration test-web-assets test-kotlin arm-smoke test-dashboard-lwip-abi`: PASS dopo aver ripristinato il flag eseguibile estratto dallo ZIP.
- `make test-http-sanitized test-stream-sanitized test-tcp-transport-sanitized test-auth-stream-sanitized test-apconfig-live-socket test-auth-live-tcp test-dashboard-live-tcp`: PASS.
- Log: `GW006_CP24_HOST_VALIDATION.log`. Tutte le prove sono **host** o stubs; la compilazione nativa SDK KM0/KM4 **NON ESEGUITA**.

## 5. Limiti e blocchi ancora aperti

- Il container non risolve `github.com` con `git` (DNS), benché il connettore GitHub permetta operazioni mirate. Non è stata sincronizzata l'intera copia di 145 file. **NON dire che CP24 è su GitHub**.
- Nessun run KM0/KM4 nativo CP24 è stato verificato. Il gate a 34 oggetti è preparato, non validato sull'SDK autentico.
- Un oggetto `.o` presente non dimostra che sia incluso nel binario finale né che funzioni sulla board. Servono compilazione e link-map SDK, verifica simboli, layout flash reale, pinout, recovery e test hardware.
- Nessun push, merge o flash eseguito in questa fase.

## 6. Ripartenza — CP-25

1. Estrarre `GW006_IR_UNIVERSAL_CP24_SOURCE_ONLY_NO_FLASH.zip` su computer Git con rete autenticata; verificare `python3 scripts/verify_release_sources.py` (139/34).
2. Clonare **solo** ramo `review/gw006-cp23-native-probe`, usare `scripts/plan_github_sync.py` dry-run, controllare diff, poi `--apply` (145 file in allowlist).
3. Esaminare e committare/pushare sul ramo review senza modificare `main` e senza segreti/binari.
4. Verificare esecuzione reale del workflow GW006 CP24, raccogliere log e controllare successi/fallimenti KM0, KM4 e gate 34 oggetti. Se il gate fallisce, controllare effettiva posizione/denominazione degli `.o` vendor e correggere **solo sulla base dei log**.
5. Prima di qualsiasi build installabile o flash: mappa flash su backup integrale verificato, spazio per il worst-case di 96 tasti, pinout, toolchain firmata/compatibile e recovery testato.

**Stato finale CP-24: local host e gate sintetico PASS; pubblicazione/compilazione/hardware PENDING; OpenBeken invariato.**
