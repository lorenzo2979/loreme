# GW006 IR Universal — CP-31 (13 November 2026)

## Goal: stop extending UI; wire the existing authenticated protocol to a single safe runtime owner

New portable firmware module `gwir_runtime_owner.{c,h}` owns one active authenticated command stream at a time, preserving signed GWAS anti-replay session state when TCP connections are reopened. It routes authenticated `GWIR_TX_SAVED` through the existing `gwir_saved_play_command` handler only after HMAC, nonce, counter, CRC and protocol parsing. All source is BOARD-AGNOSTIC and CANNOT open sockets, access real flash or enable IR pins itself.

The owner requires an externally provisioned non-zero 32-byte key, independently generated fresh 16-byte boot nonce, vetted HMAC implementation, static engine and two separate static buffers. It rejects multiple simultaneous clients, zero key or nonce, overlapping buffers, invalid packet signatures/replays and signed-output send failures; connection errors close the command stream rather than falling back to unsigned commands. `clear()` wipes secrets and working buffers.

**Tested locally** with OpenSSL HMAC-SHA256, fragmented requests, reconnect/replay, signed responses, a saved-button handler with board permission denied, ASan+UBSan, and the synthetic mock SDK. 36 firmware C modules mapped, 37 mock compiled files including the vendor `main.c`. These tests are not native Realtek or on-board results.

**Known blockers:** no live FreeRTOS/lwIP authenticated socket listener, no protected key/nonce provisioning or session discovery, no validated and reserved flash partition, no board pinmux/electrical proof, no UART/flash backup and recovery. Source gate is not proof of a functional runtime, and unresolved link map exclusions remain. CP30 native build compiled 35 old modules but discarded 16; CP31 adds a 36th module. CP31 native build status must be verified separately; never inherit REV21/CP30 PASS.

**DO NOT FLASH.** OpenBeken 1.18.321 on the physical GW006 must remain unchanged. No bootloader, partition or physical GPIO modification is allowed without an independently verified recovery path and board tests.
