#!/usr/bin/env python3
"""CP26: fail-closed evidence that all locked GWIR KM4 objects contribute to a final Realtek link.

Inspects the vendor *actual GNU ld map* and linked ARM AXF after a successful KM4
build. Host fixture tests do NOT constitute a vendor native build or device validation.
"""
from __future__ import annotations

import argparse
import json
import re
import struct
import sys
from pathlib import Path

from verify_native_km4_objects import inspect as verify_objects, SDK_PROJECT
from verify_release_sources import safe_path, verify_compiled_source_inventory

ROOT = Path(__file__).resolve().parents[1]
IMAGE_DIR = SDK_PROJECT / 'GCC-RELEASE/project_hp/asdk/image'
MAP_NAME = 'text_image2_ns.map'
ELF_NAME = 'target_img2.axf'
MAX_FILE_BYTES = 80 * 1024 * 1024

# The section contribution must have a nonzero size and an object under the
# vendor build/ram directory. An object merely mentioned by LOAD, or a section
# listed among discarded input sections, is insufficient.
CONTRIBUTION = re.compile(
    r'^\s*\.(?:text|rodata|data|bss|sdata|sbss|ARM\.exidx|init_array)'
    r'[\w.$-]*\s+0x[0-9a-fA-F]+\s+0x([0-9a-fA-F]+)\s+(\S+?\.o)\s*$'
)
LOADED = re.compile(r'^\s*LOAD\s+(\S+?\.o)\s*$')
SECTION_NAME_ONLY = re.compile(
    r'^\s*\.(?:text|rodata|data|bss|sdata|sbss|ARM\.exidx|init_array)[\w.$-]*\s*$'
)
CONTINUATION = re.compile(r'^\s*0x[0-9a-fA-F]+\s+0x([0-9a-fA-F]+)\s+(\S+?\.o)\s*$')
OBJECT_IN_RAM = re.compile(r'(?:^|/)build/ram/([A-Za-z_][A-Za-z0-9_]*)\.o$')


def _stem(path: str) -> str | None:
    # Reject archive-member syntax and misleading basename-only matches.
    match = OBJECT_IN_RAM.search(path)
    return match.group(1) if match and '(' not in path and ')' not in path else None


def analyze_map_report(text: str, names: set[str]) -> dict:
    """Return classified evidence *even if* the link gate must fail.

    This is a diagnostic only. It does not relax the requirement that every
    expected module have a nonzero allocated section in the final vendor map.
    """
    if 'Linker script and memory map' not in text:
        raise ValueError('GNU ld linked memory-map region is absent')
    if text.count('Linker script and memory map') != 1:
        raise ValueError('Repeated linker map region')
    linked_region = text.split('Linker script and memory map', 1)[1]
    load_set: set[str] = set()
    contributing: set[str] = set()
    pending_section = False
    for line in linked_region.splitlines():
        if pending_section:
            continued = CONTINUATION.match(line)
            pending_section = False
            if continued and int(continued.group(1), 16) > 0:
                name = _stem(continued.group(2))
                if name:
                    contributing.add(name)
                continue
        pending_section = SECTION_NAME_ONLY.match(line) is not None
        hit = LOADED.match(line)
        if hit:
            name = _stem(hit.group(1))
            if name:
                load_set.add(name)
            continue
        hit = CONTRIBUTION.match(line)
        if hit and int(hit.group(1), 16) > 0:
            name = _stem(hit.group(2))
            if name:
                contributing.add(name)
    missing_load = sorted(names - load_set)
    missing_alloc = sorted(names - contributing)
    loaded_but_unallocated = sorted((names & load_set) - contributing)
    return {
        'expected_modules': len(names),
        'loaded_modules': len(names & load_set),
        'modules_with_allocated_sections': len(names & contributing),
        'not_loaded': missing_load,
        'no_allocated_sections': missing_alloc,
        'loaded_but_unallocated': loaded_but_unallocated,
        'allocated_modules': sorted(names & contributing),
        'link_gate_pass': not missing_load and not missing_alloc,
        'linked_evidence': False,  # requires actual linked ARM AXF validation
        'board_runtime_verified': False,
        'flash_performed': False,
        'firmware_installable': False,
    }


def analyze_map(text: str, names: set[str]) -> dict:
    """Strict compatibility interface for the old host/unit release gate."""
    r = analyze_map_report(text, names)
    if not r['link_gate_pass']:
        raise ValueError('Final link excludes GWIR modules: '
                         + 'not_loaded=' + repr(r['not_loaded'])
                         + '; no_allocated_sections=' + repr(r['no_allocated_sections']))
    return r


def safe_build_artifact(path: Path, minimum: int, start_ns: int) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise ValueError('Missing/unsafe final-link artifact: ' + path.name)
    metadata = path.stat()
    if not (minimum <= metadata.st_size <= MAX_FILE_BYTES):
        raise ValueError('Invalid final-link artifact size: ' + path.name)
    if metadata.st_mtime_ns < start_ns:
        raise ValueError('Stale final-link artifact: ' + path.name)
    return path.read_bytes()


def verify_arm_linked_elf(data: bytes) -> None:
    """Check the vendor AXF is a linked ELF32 little-endian ARM image, not a .o."""
    if len(data) < 52 or data[:7] != b'\x7fELF\x01\x01\x01':
        raise ValueError('Final AXF is not ARM32 little-endian ELF')
    etype, machine, version = struct.unpack_from('<HHI', data, 16)
    if etype not in (2, 3) or machine != 40 or version != 1:
        raise ValueError('Final AXF is not linked ARM ELF (ET_EXEC/ET_DYN)')
    phoff = struct.unpack_from('<I', data, 28)[0]
    phentsize, phnum = struct.unpack_from('<HH', data, 42)
    if phnum < 1 or phnum > 64 or phentsize != 32 or phoff < 52 or phoff + phentsize * phnum > len(data):
        raise ValueError('Final AXF has missing/invalid program headers')
    if not any(struct.unpack_from('<I', data, phoff + i * phentsize)[0] == 1 for i in range(phnum)):
        raise ValueError('Final AXF has no loadable PT_LOAD segment')


def inspect(sdk: Path, start: Path, report_output: Path | None = None) -> dict:
    """Object and final-link verification; no SDK build and no device I/O."""
    sdk = sdk.resolve(strict=True)
    # Require the full CP25 source + Makefile + fresh ELF .o gate first.
    objs = verify_objects(sdk, 'postbuild', start)
    manifest = json.loads(safe_path(ROOT, 'docs/CP21_SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    count = verify_compiled_source_inventory(ROOT, manifest)
    if count != 42 or objs['native_objects_verified'] != 42:
        raise ValueError('Expected exactly 42 validated KM4 objects')
    names = {Path(x['path']).stem for x in manifest['files']
             if x['path'].startswith('firmware/') and x['path'].endswith('.c')}
    if len(names) != count:
        raise ValueError('Duplicate source stems across SDK modules')
    start_ns = start.stat().st_mtime_ns
    map_data = safe_build_artifact(sdk / IMAGE_DIR / MAP_NAME, 100, start_ns)
    try:
        map_text = map_data.decode('utf-8')
    except UnicodeDecodeError as e:
        raise ValueError('Final link map is not valid text') from e
    # Always validate the real ARM link image before interpreting allocations.
    # Report a genuine failure as a failure, not as "no result".
    axf_data = safe_build_artifact(sdk / IMAGE_DIR / ELF_NAME, 52, start_ns)
    verify_arm_linked_elf(axf_data)
    summary = analyze_map_report(map_text, names)
    summary.update({'native_objects_verified': count,
                    'link_map': str(IMAGE_DIR / MAP_NAME),
                    'linked_arm_elf': str(IMAGE_DIR / ELF_NAME),
                    'realtek_native_compile_proven': False,  # set only by external CI success + reviewed logs
                    'firmware_installable': False})
    summary['linked_evidence'] = summary['link_gate_pass']
    if report_output is not None:
        report_output.parent.mkdir(parents=True, exist_ok=True)
        report_output.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    if not summary['link_gate_pass']:
        raise ValueError('Final link excludes GWIR modules: '
                         + 'not_loaded=' + repr(summary['not_loaded'])
                         + '; no_allocated_sections=' + repr(summary['no_allocated_sections']))
    return summary


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sdk', type=Path, required=True)
    p.add_argument('--build-start-file', type=Path, required=True)
    p.add_argument('--output', type=Path)
    args = p.parse_args(argv)
    try:
        result = inspect(args.sdk, args.build_start_file, args.output)
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as exc:
        print('CP26 KM4 FINAL LINK GATE FAIL: ' + str(exc), file=sys.stderr)
        return 2
    print('CP26 KM4 FINAL LINK GATE PASS: ' + json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
