#!/usr/bin/env python3
"""CP-21: verify every release source against a locked SHA-256 manifest.

Read-only. Fail closed on path traversal, symlinks, missing files, unexpected
source additions or hash/size differences. Does not build or flash firmware.
"""
import argparse
import ast
import hashlib
import hmac
import json
import sys
from pathlib import Path, PurePosixPath

MANIFEST_VERSION = 1
SOURCE_DIRS = (
    "firmware/core", "firmware/realtek", "firmware/sdk", "tests", "scripts", "android", "web",
)
CODE_SUFFIXES = {".c", ".h", ".py", ".sh", ".kt", ".html", ".json"}
EXTRA_FILES = (
    "Makefile", ".github/workflows/gw006-cp21-native.yml",
)


def paths_for_release(root):
    paths = set(EXTRA_FILES)
    for prefix in SOURCE_DIRS:
        directory = root / prefix
        if not directory.is_dir() or directory.is_symlink():
            raise ValueError("Missing/symlink source directory: " + prefix)
        for p in directory.rglob("*"):
            if p.is_symlink():
                raise ValueError("Symlink source: " + str(p))
            if p.is_file() and p.suffix in CODE_SUFFIXES:
                paths.add(p.relative_to(root).as_posix())
    return sorted(paths)


def safe_path(root, name):
    if not isinstance(name, str) or "\\" in name or not name.isascii() or not name:
        raise ValueError("Invalid path")
    rel = PurePosixPath(name)
    if rel.is_absolute() or ".." in rel.parts or "." in rel.parts or rel.as_posix() != name:
        raise ValueError("Path traversal/noncanonical: " + name)
    target = root
    for part in rel.parts:
        target = target / part
        if target.is_symlink():
            raise ValueError("Symlink disallowed: " + name)
    if not target.is_file():
        raise ValueError("Missing source: " + name)
    if target.resolve().is_relative_to(root.resolve()) is False:
        raise ValueError("Path escapes root: " + name)
    return target


def records(root):
    result = []
    for name in paths_for_release(root):
        data = safe_path(root, name).read_bytes()
        result.append({"path": name, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    return result


def validate_manifest_schema(obj):
    if not isinstance(obj, dict) or set(obj) != {"schema", "kind", "files"}:
        raise ValueError("Unexpected manifest schema")
    if obj["schema"] != MANIFEST_VERSION or obj["kind"] != "GW006-CP21-SOURCE-LOCK":
        raise ValueError("Wrong manifest version/kind")
    files = obj["files"]
    if not isinstance(files, list) or not files:
        raise ValueError("Empty manifest")
    prev = ""
    for x in files:
        if not isinstance(x, dict) or set(x) != {"path", "size", "sha256"}:
            raise ValueError("Malformed record")
        p, n, h = x["path"], x["size"], x["sha256"]
        if not isinstance(p, str) or not (prev < p):
            raise ValueError("Unsorted or duplicate manifest paths")
        if type(n) is not int or n < 0 or n > 100_000_000:
            raise ValueError("Invalid file size")
        if not isinstance(h, str) or len(h) != 64 or any(c not in "0123456789abcdef" for c in h):
            raise ValueError("Invalid SHA-256")
        prev = p


def verify(root, manifest):
    validate_manifest_schema(manifest)
    expected = [x["path"] for x in manifest["files"]]
    present = paths_for_release(root)
    if expected != present:
        missing = sorted(set(expected) - set(present))
        extra = sorted(set(present) - set(expected))
        raise ValueError("Source inventory mismatch: missing=" + str(missing) + " extra=" + str(extra))
    for item in manifest["files"]:
        p = safe_path(root, item["path"])
        data = p.read_bytes()
        if len(data) != item["size"] or not hmac.compare_digest(
            hashlib.sha256(data).hexdigest(), item["sha256"]
        ):
            raise ValueError("Source integrity mismatch: " + item["path"])
    num_c = sum(x.endswith('.c') and x.startswith("firmware/") for x in expected)
    if num_c < 36:
        raise ValueError("Not enough C sources: " + str(num_c))
    return len(expected), num_c


def verify_compiled_source_inventory(root, manifest):
    """Prevent unlinked C sources from silently being omitted in vendor KM4."""
    # A source file is not necessarily executed at runtime; this checks makefile
    # inclusion *intent*, NOT a successful native KM4 compilation.
    filename = safe_path(root, "scripts/integrate_amebad_sdk.py")
    module = ast.parse(filename.read_text(encoding="utf-8"), filename=str(filename))
    groups = None
    for node in module.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "GROUPS" for t in node.targets
        ):
            groups = ast.literal_eval(node.value)
            break
    if not isinstance(groups, dict) or set(groups) != {"core", "realtek", "sdk"}:
        raise ValueError("Missing SDK integration GROUPS mapping")
    actual = []
    for group, files in groups.items():
        if not isinstance(files, list):
            raise ValueError("Invalid SDK group: " + group)
        for name in files:
            if not isinstance(name, str) or not name.endswith(".c") or "/" in name:
                raise ValueError("Invalid SDK C filename")
            actual.append("firmware/" + group + "/" + name)
    if len(set(actual)) != len(actual):
        raise ValueError("Duplicate compiled source in SDK integration GROUPS")
    expected = sorted(x["path"] for x in manifest["files"] if x["path"].endswith(".c") and x["path"].startswith("firmware/"))
    if sorted(actual) != expected:
        raise ValueError(
            "KM4 integration source mismatch: missing=" + str(sorted(set(expected)-set(actual)))
            + " extra=" + str(sorted(set(actual)-set(expected)))
        )
    return len(actual)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--manifest", type=Path, default=None)
    args = parser.parse_args(argv)
    root = args.root.resolve(strict=True)
    manifest_path = args.manifest or root / "docs/CP21_SOURCE_MANIFEST.json"
    try:
        obj = json.loads(manifest_path.read_text(encoding="utf-8"))
        file_count, c_count = verify(root, obj)
        linked = verify_compiled_source_inventory(root, obj)
    except (OSError, ValueError, json.JSONDecodeError) as e:
        print("CP21 SOURCE GATE FAIL: " + str(e), file=sys.stderr)
        return 2
    print(f"CP21 SOURCE GATE PASS: {file_count} locked files, {c_count} C files, {linked} mapped into SDK; NO FLASH")
    return 0


if __name__ == "__main__":
    sys.exit(main())
