#!/usr/bin/env python3
"""CP29 offline firmware readiness report. Never flashes or accesses hardware.

This is a *negative-evidence* gate, not a way to grant hardware approval.
It recognizes the current explicit disable guards and independently requires
real-device validation, flash/backup proof and native build/link evidence.
No synthetic fixture is allowed to set those physical evidence flags.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    'vendor_bus': 'firmware/realtek/gwir_amebad_vendor_bus.c',
    'board_pins': 'firmware/realtek/gwir_amebad_board_pins.c',
    'apconfig': 'firmware/sdk/gwir_sdk_apconfig_port.c',
    'station': 'firmware/sdk/gwir_sdk_sta_dashboard.c',
    'integrator': 'scripts/integrate_amebad_sdk.py',
    'saved_playback': 'firmware/core/gwir_saved_play_command.c',
}


def _read(root: Path, rel: str) -> str:
    # Read only known fixed paths and reject symlink escapes.
    start = root.resolve(strict=True)
    p = start
    for part in Path(rel).parts:
        p = p / part
        if p.is_symlink():
            raise ValueError('Source symlink prohibited: ' + rel)
    if not p.is_file() or not p.resolve().is_relative_to(start):
        raise ValueError('Missing/unsafe source: ' + rel)
    return p.read_text(encoding='utf-8')


def _function_body(src: str, signature: str) -> str:
    # Scope a C function to its balanced body. No assumption about whitespace.
    pat = re.compile(r'\b' + re.escape(signature) + r'\s*\([^;{}]*\)\s*\{')
    m = pat.search(src)
    if not m:
        raise ValueError('Expected function is not found: ' + signature)
    pos, depth = m.end(), 1
    start = pos
    while pos < len(src):
        if src[pos] == '{':
            depth += 1
        elif src[pos] == '}':
            depth -= 1
            if depth == 0:
                return src[start:pos]
        pos += 1
    raise ValueError('Unbalanced C function: ' + signature)


def _always_zero(body: str) -> bool:
    # Only certify the explicit one-statement guard in current sources.
    clean = re.sub(r'/\*.*?\*/|//[^\n]*', '', body, flags=re.S)
    return bool(re.fullmatch(r'\s*(?:\(void\)\s*ctx\s*;\s*)?return\s+0\s*;\s*', clean))


def inspect(root: Path = ROOT) -> dict:
    sources = {k: _read(root, rel) for k, rel in FILES.items()}
    bus = _function_body(sources['vendor_bus'], 'board_verified')
    pins = _function_body(sources['board_pins'], 'gwir_board_ir_enable_authorized')
    ap = sources['apconfig']
    station = sources['station']
    integration = sources['integrator']
    blockers = []
    if _always_zero(bus):
        blockers.append('Hardware vendor IR bus intentionally denies board authorization')
    else:
        blockers.append('Vendor IR board authorization has changed: independent hardware audit required')
    if _always_zero(pins):
        blockers.append('Board IR pin enable is explicitly denied')
    else:
        blockers.append('Board pin enable guard changed: independent physical wiring proof required')
    if re.search(r'board_button_approved_flag\s*=\s*0u\s*;', ap):
        blockers.append('Physical APConfig button approval is disabled')
    else:
        blockers.append('APConfig approval state is unknown and requires hardware audit')
    if ('#if defined(GWIR_ENABLE_STA_DASHBOARD_TRIAL)' in station and
            'return -1; /* Runtime intentionally disabled by default.' in station):
        blockers.append('Wi-Fi station dashboard is a disabled-by-default trial')
    else:
        blockers.append('Station dashboard compile-time policy requires review')
    if 'gwir_sdk_integration_banner();' in integration and 'GWIR_ENABLE_STA_DASHBOARD_TRIAL' in integration:
        blockers.append('Vendor main integration initializes diagnostics, not full authenticated IR/storage services')
    else:
        blockers.append('Vendor main boot integration requires full runtime path review')
    if ('gwir_saved_play_command' in sources['saved_playback'] and
            'gwir_auth_stream_feed_routed' not in integration):
        blockers.append('Authenticated saved IR command is host-wired only; no real GWAS listener and no persistent GW006 store')
    else:
        blockers.append('Saved IR runtime wiring changed: full security/hardware review required')
    blockers.extend((
        'No independently verified KM0/KM4 build AND final link for the complete source snapshot',
        'No target GW006 full-flash backup, reserved partition map or tested recovery path',
        'No physical-board IR wiring, pinmux and electrical timing validation',
        'No on-board persistence power-loss test covering all 96 keys x up to 5 frames',
    ))
    return {
        'checkpoint': 'CP29',
        'inspection': 'static offline source guard and outstanding requirements',
        'ir_tx_rx_enabled': False,
        'ready_to_flash': False,
        'installable_firmware_available': False,
        'realtek_native_km0_km4_proven': False,
        'hardware_verified': False,
        'openbeken_modified': False,
        'blockers': blockers,
        'blocker_count': len(blockers),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--require-ready', action='store_true',
                        help='Mandatory release gate: fail until physical and native evidence exists')
    args = parser.parse_args(argv)
    try:
        result = inspect(args.root)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    except (OSError, UnicodeError, ValueError) as exc:
        print('CP29 RUNTIME AUDIT FAIL: ' + str(exc), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    if args.require_ready:
        print('CP29 RELEASE GATE BLOCKED: target board and native firmware are not proven ready', file=sys.stderr)
        return 3
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
