#!/usr/bin/env sh
# Compile portable TX modules to the instruction-set targets of RTL872xCS:
# KM0 ~ Cortex-M23, KM4 ~ Cortex-M33.
# This uses test stub ameba_soc.h: NOT an SDK build, not device firmware!
set -eu
cd "$(dirname "$0")/.."
: "${CLANG:=clang}"
command -v "$CLANG" >/dev/null 2>&1 || { echo "Clang unavailable" >&2; exit 2; }
for spec in 'cortex-m23 arm-km0-m23' 'cortex-m33 arm-km4-m33'; do
    set -- $spec
    cpu=$1
    target=$2
    mkdir -p "build/$target"
    for name in gwir_amebad_tx_codec gwir_amebad_tx_fifo gwir_amebad_tx_vendor gwir_amebad_rx_fifo gwir_amebad_rx_vendor gwir_amebad_rx_irq gwir_amebad_bus gwir_amebad_vendor_bus gwir_amebad_board_pins; do
        "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb \
          -mfloat-abi=soft -ffreestanding -fno-builtin -O2 \
          -std=c11 -Wall -Wextra -Werror \
          -Itests/stubs -c "firmware/realtek/$name.c" \
          -o "build/$target/$name.o"
    done
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb \
      -mfloat-abi=soft -ffreestanding -fno-builtin -O2 \
      -std=c11 -Wall -Wextra -Werror \
      -c firmware/core/gwir_apconfig_button.c \
      -o "build/$target/gwir_apconfig_button.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -c firmware/core/gwir_apconfig_session.c -o "build/$target/gwir_apconfig_session.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -c firmware/core/gwir_apconfig_provision.c -o "build/$target/gwir_apconfig_provision.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -Ifirmware/core -c firmware/core/gwir_apconfig_http.c -o "build/$target/gwir_apconfig_http.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -Ifirmware/core -c firmware/core/gwir_apconfig_http_stream.c -o "build/$target/gwir_apconfig_http_stream.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -Ifirmware/core -c firmware/core/gwir_apconfig_tcp_transport.c -o "build/$target/gwir_apconfig_tcp_transport.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -Ifirmware/core -c firmware/core/gwir_auth_stream.c -o "build/$target/gwir_auth_stream.o"
    # CP29: signed dispatch and saved-code handler compile only for both ARM
    # cores, using the host-only libc declaration stub (no link or flash).
    for name in gwir_auth_dispatch gwir_saved_play_command; do
        "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb \
          -mfloat-abi=soft -ffreestanding -fno-builtin -O2 \
          -std=c11 -Wall -Wextra -Werror -Itests/stubs_arm \
          -Ifirmware/core -c "firmware/core/$name.c" \
          -o "build/$target/$name.o"
    done
    # The generated asset is compiled as plain rodata. The host-only responder uses
    # libc/newlib snprintf and is validated by host and SDK mock builds instead.
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 -Wall -Wextra -Werror -Ifirmware/core -c firmware/core/gwir_dashboard_asset.c -o "build/$target/gwir_dashboard_asset.o"
    # CP18 journal is source-only, with compile-time libc declaration stubs.
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb \
      -mfloat-abi=soft -ffreestanding -fno-builtin -O2 \
      -std=c11 -Wall -Wextra -Werror \
      -Itests/stubs_arm -Ifirmware/core \
      -c firmware/core/gwir_flash_journal.c \
      -o "build/$target/gwir_flash_journal.o"
    "$CLANG" --target=arm-none-eabi -mcpu="$cpu" -mthumb \
      -mfloat-abi=soft -ffreestanding -fno-builtin -O2 -std=c11 \
      -Wall -Wextra -Werror -Itests/stubs -Itests/stubs_arm -Ifirmware/core -Ifirmware/realtek \
      -c firmware/realtek/gwir_wbrg1_flash_port.c \
      -o "build/$target/gwir_wbrg1_flash_port.o"
    echo "PASS compile-only $cpu with test stub (NOT linked/SDK-tested)"
done
