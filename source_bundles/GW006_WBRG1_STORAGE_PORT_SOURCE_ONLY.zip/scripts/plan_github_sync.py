#!/usr/bin/env python3
"""CP22: locked source-only sync into a CLEAN Git review checkout (NO PUSH).

Requires a verified CP21 SHA-256 source inventory before even dry-run.
Only copies explicitly locked files plus named documentation/manifest
companions; excludes caches, binaries, extraneous files and firmware images.
This is NOT authentication of the origin of the manifest, a native build, or
permission to flash any GW006 board.
"""
import argparse
import hashlib
import hmac
import importlib.util
import json
import os
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
EXTRAS = (
    'README.md',
    'docs/CP21_SOURCE_MANIFEST.json',
    'docs/CHECKPOINT_CP21_2026-11-12.md',
    'docs/CHECKPOINT_CP22_2026-11-12.md',
    'docs/CHECKPOINT_CP23_2026-11-12.md',
    'docs/CHECKPOINT_CP24_2026-11-12.md',
    'docs/CHECKPOINT_CP25_2026-11-12.md',
    'docs/CHECKPOINT_CP26_2026-11-12.md',
    'docs/CHECKPOINT_CP27_2026-11-12.md',
    'docs/CHECKPOINT_CP28_2026-11-12.md',
    'docs/CHECKPOINT_CP29_2026-11-12.md',
    'docs/CHECKPOINT_CP31_2026-11-13.md',
)


def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True, check=True).stdout.strip()


def source_lock(source):
    """Reject unexpected code, missing files, symlinks or altered locked bytes."""
    gate_file = source / 'scripts/verify_release_sources.py'
    if gate_file.is_symlink() or not gate_file.is_file():
        raise ValueError('Missing/unsafe source verifier')
    spec = importlib.util.spec_from_file_location('gwir_cp22_gate', gate_file)
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    manifest_file = source / 'docs/CP21_SOURCE_MANIFEST.json'
    if manifest_file.is_symlink() or not manifest_file.is_file():
        raise ValueError('Missing/unsafe source manifest')
    manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
    gate.verify(source, manifest)
    gate.verify_compiled_source_inventory(source, manifest)
    locked = {entry['path']: entry['sha256'] for entry in manifest['files']}
    for path in EXTRAS:
        gate.safe_path(source, path)
    return locked


def get_paths(source):
    """Exact allowlist, never every arbitrary file in source directories."""
    return source_lock(source)


def atomic_copy(destination, data, mode):
    """One-file atomic replace; leave working tree visibly dirty, never commit."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        raise ValueError('Symlink destination prohibited: ' + str(destination))
    with tempfile.NamedTemporaryFile(prefix='.gwir-stage-', dir=destination.parent,
                                     delete=False) as stage:
        tmp = Path(stage.name)
        try:
            stage.write(data)
            stage.flush()
            os.fchmod(stage.fileno(), mode)
            os.fsync(stage.fileno())
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise
    try:
        if destination.is_symlink():
            raise ValueError('Symlink destination prohibited: ' + str(destination))
        os.replace(tmp, destination)
    finally:
        tmp.unlink(missing_ok=True)


def run(source, checkout, apply):
    source, checkout = source.resolve(strict=True), checkout.resolve(strict=True)
    if source == checkout or source.is_relative_to(checkout):
        raise ValueError('Source must be outside the Git checkout')
    if not (checkout / '.git').exists():
        raise ValueError('Target must be a Git checkout with .git metadata')
    if Path(git(checkout, 'rev-parse', '--show-toplevel')).resolve() != checkout:
        raise ValueError('Target is not Git checkout root')
    branch = git(checkout, 'branch', '--show-current')
    if not branch.startswith('review/') or branch in ('main', 'master'):
        raise ValueError('Refusing non-review branch; use review/gw006-cp22')
    if git(checkout, 'status', '--porcelain', '--untracked-files=all'):
        raise ValueError('Refusing dirty checkout; commit/stash changes first')

    locked = get_paths(source)
    to_copy = sorted(set(locked) | set(EXTRAS))
    new, changed, unchanged = [], [], []
    content = {}
    modes = {}
    # Preflight every file and every destination before any mutation.
    for rel in to_copy:
        origin = source / rel
        if origin.is_symlink() or not origin.is_file():
            raise ValueError('Unsafe source: ' + rel)
        data = origin.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if rel in locked and not hmac.compare_digest(digest, locked[rel]):
            raise ValueError('Source changed after integrity gate: ' + rel)
        content[rel] = data
        modes[rel] = stat.S_IMODE(origin.stat().st_mode)
        dest = checkout / rel
        if any(p.is_symlink() for p in (dest, *dest.parents) if p != Path('/')):
            raise ValueError('Symlink destination prohibited: ' + rel)
        if dest.exists():
            if not dest.is_file():
                raise ValueError('Non-file collision: ' + rel)
            if hashlib.sha256(dest.read_bytes()).hexdigest() == digest:
                unchanged.append(rel)
            else:
                changed.append(rel)
        else:
            new.append(rel)

    if apply:
        for rel in new + changed:
            dest = checkout / rel
            if any(p.is_symlink() for p in (dest, *dest.parents) if p != Path('/')):
                raise ValueError('Symlink destination prohibited on apply: ' + rel)
            atomic_copy(dest, content[rel], modes[rel])
            if dest.read_bytes() != content[rel]:
                raise ValueError('Post-copy verification failed: ' + rel)
    report = {'review_branch': branch, 'mode': 'copy-only' if apply else 'dry-run',
              'new': new, 'changed': changed, 'unchanged_count': len(unchanged),
              'locked_files': len(locked), 'extra_files': list(EXTRAS),
              'source_verified': True, 'pushed': False, 'committed': False,
              'board_flashing': False}
    print(json.dumps(report, indent=2, sort_keys=True))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkout', type=Path, required=True)
    parser.add_argument('--source', type=Path, default=SRC)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        run(args.source, args.checkout, args.apply)
    except (OSError, ValueError, subprocess.CalledProcessError, json.JSONDecodeError) as e:
        print('CP22 GITHUB SYNC REFUSED: ' + str(e), file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    sys.exit(main())
