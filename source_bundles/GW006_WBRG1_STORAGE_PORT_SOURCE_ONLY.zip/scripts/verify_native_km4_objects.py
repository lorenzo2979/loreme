#!/usr/bin/env python3
"""CP25 NO FLASH: fail-closed source, freshness and ARM ELF KM4 .o audit.

This is a native build *artifact* gate, NOT a final-link or board-runtime
attestation. Its synthetic tests do not substitute for a real AmebaD SDK run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

from verify_release_sources import safe_path, verify_compiled_source_inventory

ROOT = Path(__file__).resolve().parents[1]
SDK_PROJECT = Path('project/realtek_amebaD_va0_example')
VENDOR_MAKE = SDK_PROJECT / 'src/src_hp/Makefile'
VENDOR_C = SDK_PROJECT / 'src/gwir_sdk'
OBJECT_ROOT = SDK_PROJECT / 'src/src_hp'


def arm_elf_relocatable(path: Path, *, allow_data_only: bool = False) -> None:
    """Reject non-ELF, wrong ISA, stripped or malformed object file headers.

    Bounded, standard-library-only parsing; validates section extents before
    examining code and symbol sections. No untrusted object is executed.
    """
    stat = path.stat()
    if not (52 <= stat.st_size <= 64 * 1024 * 1024):
        raise ValueError('Native KM4 object has invalid ELF size: ' + path.name)
    data = path.read_bytes()
    if len(data) != stat.st_size or data[:4] != b'\x7fELF':
        raise ValueError('Native KM4 object is not ELF: ' + path.name)
    if data[4:7] != b'\x01\x01\x01':
        raise ValueError('Native KM4 object is not 32-bit little-endian ELF: ' + path.name)
    if struct.unpack_from('<H', data, 16)[0] != 1:
        raise ValueError('Native KM4 object is not relocatable ELF: ' + path.name)
    if struct.unpack_from('<H', data, 18)[0] != 40:
        raise ValueError('Native KM4 object has wrong machine (expected ARM): ' + path.name)
    if struct.unpack_from('<I', data, 20)[0] != 1:
        raise ValueError('Native KM4 object has invalid ELF version: ' + path.name)

    shoff = struct.unpack_from('<I', data, 32)[0]
    ehsize = struct.unpack_from('<H', data, 40)[0]
    shentsize = struct.unpack_from('<H', data, 46)[0]
    shnum = struct.unpack_from('<H', data, 48)[0]
    if ehsize != 52 or shentsize != 40 or shnum < 3 or shnum > 4096:
        raise ValueError('Native KM4 object has invalid section table: ' + path.name)
    if shoff < ehsize or shoff + shentsize * shnum > len(data):
        raise ValueError('Native KM4 object has out-of-range section table: ' + path.name)

    sections = [struct.unpack_from('<IIIIIIIIII', data, shoff + i * 40) for i in range(shnum)]
    code_found, symbol_found = False, False
    data_found, object_found = False, False
    for idx, sec in enumerate(sections):
        _, kind, flags, _, offset, size, link, _, _, entsize = sec
        if kind != 8 and size and (offset < ehsize or offset + size > len(data)):
            raise ValueError('Native KM4 object has out-of-range section data: ' + path.name)
        if kind == 1 and (flags & 4) and size:
            code_found = True
        if kind == 1 and (flags & 2) and not (flags & 4) and size:
            data_found = True
        if kind == 2:  # SHT_SYMTAB; link must point at a string table
            if (size < 32 or entsize != 16 or size % 16 or
                    link >= shnum or sections[link][1] != 3):
                raise ValueError('Native KM4 object has invalid symbol table: ' + path.name)
            # One *defined* function symbol, not just a blank .symtab header.
            strings = sections[link]
            str_offset, str_size = strings[4], strings[5]
            if str_offset < ehsize or str_offset + str_size > len(data):
                raise ValueError('Native KM4 object has invalid symbol strings: ' + path.name)
            for pos in range(offset + 16, offset + size, 16):
                name_at, sym_value, sym_size, info, _, section_idx = struct.unpack_from('<IIIBBH', data, pos)
                kind_symbol = info & 15
                if (kind_symbol == 2 or (allow_data_only and kind_symbol == 1 and sym_size > 0)) and section_idx not in (0, 0xfff1, 0xfff2) and name_at:
                    if name_at >= str_size:
                        raise ValueError('Native KM4 object has invalid symbol name: ' + path.name)
                    end = data.find(b'\x00', str_offset + name_at, str_offset + str_size)
                    if end == -1 or end == str_offset + name_at:
                        raise ValueError('Native KM4 object has invalid symbol name: ' + path.name)
                    if kind_symbol == 2:
                        symbol_found = True
                    else:
                        # Data-only exception is limited to a *real* symbol
                        # occupying an allocated non-executable section.
                        if section_idx < shnum:
                            sec = sections[section_idx]
                            if (sec[1] == 1 and (sec[2] & 2) and
                                    not (sec[2] & 4) and
                                    sym_value + sym_size <= sec[5]):
                                object_found = True
    if not code_found or not symbol_found:
        if allow_data_only and data_found and object_found:
            return
        raise ValueError('Native KM4 object missing code or defined function symbol: ' + path.name)


def inspect(sdk: Path, phase: str, start: Path | None = None) -> dict:
    sdk = sdk.resolve(strict=True)
    if not sdk.is_dir():
        raise ValueError('SDK root is not a directory')
    manifest_path = safe_path(ROOT, 'docs/CP21_SOURCE_MANIFEST.json')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    c_count = verify_compiled_source_inventory(ROOT, manifest)
    source_records = [entry for entry in manifest['files'] if entry['path'].startswith('firmware/') and entry['path'].endswith('.c')]
    if c_count != len(source_records) or c_count != 42:
        raise ValueError('Unexpected SDK source count; expected exact 42')
    makefile = sdk / VENDOR_MAKE
    if makefile.is_symlink() or not makefile.is_file():
        raise ValueError('Missing or unsafe SDK project Makefile')
    maketext = makefile.read_text(encoding='utf-8')
    records = []
    stems = set()
    for entry in source_records:
        rel = entry['path']
        parts = rel.split('/')
        group, name = parts[1], parts[2]
        expected = '$(GWIR_DIR)/' + group + '/' + name
        if maketext.count(expected) != 1:
            raise ValueError('GWIR source not registered exactly once in SDK Makefile: ' + rel)
        stem = Path(name).stem
        if stem in stems:
            raise ValueError('Object name collision: ' + stem)
        stems.add(stem)
        source = sdk / VENDOR_C / group / name
        if source.is_symlink() or not source.is_file():
            raise ValueError('Missing/symlink installed SDK source: ' + rel)
        data = source.read_bytes()
        if hashlib.sha256(data).hexdigest() != entry['sha256'] or len(data) != entry['size']:
            raise ValueError('SDK source differs from locked local source: ' + rel)
        records.append({'source': rel, 'object': stem + '.o'})

    output = {'phase': phase, 'expected_modules': len(records), 'sdk_sources_verified': len(records),
              'makefile_mappings_verified': len(records), 'native_objects_verified': None,
              'object_format': 'ELF32 little-endian ET_REL EM_ARM with code and symbols',
              'flashed': False, 'firmware_installable': False}
    if phase == 'preflight':
        return output
    if phase != 'postbuild':
        raise ValueError('Invalid phase')
    if start is None or start.is_symlink() or not start.is_file():
        raise ValueError('Missing or unsafe build start marker')
    start_ns = start.stat().st_mtime_ns
    if start_ns <= 0:
        raise ValueError('Invalid build start marker timestamp')
    objdir = sdk / OBJECT_ROOT
    if objdir.is_symlink() or not objdir.is_dir():
        raise ValueError('SDK object directory missing/unsafe')
    for record in records:
        path = objdir / record['object']
        if path.is_symlink() or not path.is_file():
            raise ValueError('Native KM4 object missing/unsafe: ' + record['object'])
        meta = path.stat()
        if meta.st_size <= 0:
            raise ValueError('Native KM4 object is empty: ' + record['object'])
        if meta.st_mtime_ns < start_ns:
            raise ValueError('Native KM4 object is stale: ' + record['object'])
        arm_elf_relocatable(path, allow_data_only=(record["object"] == "gwir_dashboard_asset.o"))
    output['native_objects_verified'] = len(records)
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path, required=True)
    parser.add_argument('--phase', choices=['preflight', 'postbuild'], required=True)
    parser.add_argument('--build-start-file', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args(argv)
    try:
        summary = inspect(args.sdk, args.phase, args.build_start_file)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print('CP25 KM4 ARM ELF OBJECT GATE FAIL: ' + str(exc), file=sys.stderr)
        return 2
    print('CP25 KM4 ARM ELF OBJECT GATE PASS: ' + json.dumps(summary, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
