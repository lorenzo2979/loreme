#include "gwir_sdk_sta_dashboard.h"

/* OFF BY DEFAULT. Enable only with a *tested* AmebaD Wi-Fi network build.
 * No service starts, no pins are driven and no IR TX/RX is enabled otherwise.
 * Never enable together with public/open APConfig without a hardware-tested
 * interface isolation strategy. This gate strictly accepts STA-only mode. */
#if defined(GWIR_ENABLE_STA_DASHBOARD_TRIAL) && (GWIR_ENABLE_STA_DASHBOARD_TRIAL == 1)
#include "ameba_soc.h"
#include <wifi/wifi_conf.h>
#include <lwip_netconf.h>
#include <lwip/netif.h>
#include <string.h>
#include "../core/gwir_sta_gate.h"
#include "../realtek/gwir_dashboard_sta_server.h"

/* The vendor SDK has a global wifi_mode (wifi_conf.c). Do not replace this
 * with a cached value: APConfig may turn on STA+AP at any time. */
extern rtw_mode_t wifi_mode;
static volatile int task_stop;
static int read_sta_snapshot(gwir_sta_snapshot *s)
{
    uint8_t *ip;
    if (!s) return 0;
    memset(s, 0, sizeof(*s));
    s->sta_only = wifi_mode == RTW_MODE_STA;
    if (!s->sta_only) return 0;
    s->associated = wifi_is_connected_to_ap() == RTW_SUCCESS;
    if (!s->associated) return 0;
    s->netif_up = netif_is_up(&xnetif[0]) != 0;
    s->link_up = netif_is_link_up(&xnetif[0]) != 0;
    if (!s->netif_up || !s->link_up) return 0;
    ip = LwIP_GetIP(&xnetif[0]);
    if (!ip) return 0;
    memcpy(s->ipv4, ip, sizeof(s->ipv4));
    return 1;
}
static int check_sta(void *ctx, uint32_t expected_ip)
{
    gwir_sta_snapshot s;
    (void)ctx;
    return read_sta_snapshot(&s) && gwir_sta_gate_match(&s, expected_ip);
}
static void dashboard_task(void *arg)
{
    (void)arg;
    while (!task_stop) {
        gwir_sta_snapshot s;
        uint32_t ip;
        if (read_sta_snapshot(&s) && gwir_sta_gate_ip(&s, &ip)) {
            gwir_dashboard_server_config cfg;
            memset(&cfg, 0, sizeof(cfg));
            cfg.sta_ip_network_order = ip;
            cfg.port = 8080u; /* Trial-only, not port 80 nor public APConfig. */
            cfg.stop = &task_stop;
            cfg.check_sta = check_sta;
            (void)gwir_dashboard_server_run(&cfg);
        }
        vTaskDelay((TickType_t)(500 / portTICK_PERIOD_MS));
    }
    vTaskDelete(NULL);
}
int gwir_sdk_sta_dashboard_start(void)
{
    if (xTaskCreate(dashboard_task, "GWIR-DASH", 1024u, NULL,
                    tskIDLE_PRIORITY + 1u, NULL) != pdPASS)
        return -1;
    return 0;
}
#else
int gwir_sdk_sta_dashboard_start(void)
{
    return -1; /* Runtime intentionally disabled by default. */
}
#endif
