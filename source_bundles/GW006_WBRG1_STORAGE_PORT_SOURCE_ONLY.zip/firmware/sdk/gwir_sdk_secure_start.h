#ifndef GWIR_SDK_SECURE_START_H
#define GWIR_SDK_SECURE_START_H

#include <stdint.h>
#include "../core/gwir_runtime_owner.h"

/* Platform trust boundary. These callbacks MUST be implemented and audited
 * against the physical GW006 board before they may be registered. A boolean
 * callback is not cryptographic proof by itself. There is deliberately NO
 * default, constant key, weak RNG, public nonce endpoint or bypass mode.
 *
 * The platform MUST ensure that:
 *  - trust_verified affirms secure per-device key storage and a CSPRNG/TRNG;
 *  - load_key returns the matching 32-byte secret without writing logs;
 *  - fresh_nonce produces 16 unpredictable bytes UNIQUE across boot epochs;
 *  - nonce_freshness_verified proves this epoch was never used before;
 *  - deliver_nonce uses a mutually authenticated, independent channel BEFORE
 *    the TCP listener is made available (never an unauthenticated broadcast).
 * All callbacks run in a serialized, non-ISR context. No implementation is
 * provided for the actual GW006 until hardware-specific proofs exist. */
typedef struct {
    int (*trust_verified)(void *ctx);
    int (*load_key)(void *ctx, uint8_t key[GWIR_AUTH_KEY_BYTES]);
    int (*fresh_nonce)(void *ctx, uint8_t nonce[GWIR_AUTH_NONCE_BYTES]);
    int (*nonce_freshness_verified)(void *ctx,
                                   const uint8_t nonce[GWIR_AUTH_NONCE_BYTES]);
    int (*deliver_nonce)(void *ctx,
                         const uint8_t nonce[GWIR_AUTH_NONCE_BYTES]);
    void *ctx;
} gwir_sdk_secure_provider;

/* Fail closed. Returns 0 ONLY after protected owner init, authenticated nonce
 * delivery and successful FreeRTOS task registration. On any error all local
 * key material is wiped, and any initialized owner is cleared. This function
 * does NOT initialize IR/pinmux, map NOR flash or obtain a key by itself.
 * It must NEVER be invoked with a fake/mock or unverified provider on hardware.
 */
int gwir_sdk_secure_start(const gwir_sdk_secure_provider *provider,
                          gwir_runtime_owner *owner,
                          gwir_engine *engine,
                          gwir_saved_play_service *saved,
                          gwir_auth_hmac_fn hmac,
                          void *crypto_ctx,
                          uint8_t *scratch, size_t scratch_capacity,
                          uint8_t *response, size_t response_capacity,
                          uint16_t port);

#endif
