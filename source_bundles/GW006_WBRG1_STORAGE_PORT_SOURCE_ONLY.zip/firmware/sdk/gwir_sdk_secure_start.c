#include "gwir_sdk_secure_start.h"
#include "gwir_sdk_auth_task.h"
#include <string.h>

static void wipe_secret(void *p, size_t n)
{
    volatile uint8_t *b = (volatile uint8_t *)p;
    while (n--) *b++ = 0u;
}

/* This function intentionally never calls a Realtek random helper. Some
 * vendor wrappers return 0 even when no random callback is installed.
 * Trust and freshness must be provided by an audited, board-specific port. */
int gwir_sdk_secure_start(const gwir_sdk_secure_provider *provider,
                          gwir_runtime_owner *owner,
                          gwir_engine *engine,
                          gwir_saved_play_service *saved,
                          gwir_auth_hmac_fn hmac,
                          void *crypto_ctx,
                          uint8_t *scratch, size_t scratch_capacity,
                          uint8_t *response, size_t response_capacity,
                          uint16_t port)
{
    uint8_t key[GWIR_AUTH_KEY_BYTES] = {0};
    uint8_t nonce[GWIR_AUTH_NONCE_BYTES] = {0};
    int rc = -1;
    int initialized = 0;

    /* Refuse a reinitialization of an active session, including invalid calls.
     * The external board port owns and serializes the lifetime of 'owner'. */
    if (!provider || !provider->trust_verified || !provider->load_key ||
        !provider->fresh_nonce || !provider->nonce_freshness_verified ||
        !provider->deliver_nonce || !owner || owner->initialized ||
        !engine || !hmac || !scratch || !response || port < 1024u)
        goto done;
    if (provider->trust_verified(provider->ctx) != 1)
        goto done;
    if (provider->load_key(provider->ctx, key) != 0)
        goto done;
    if (provider->fresh_nonce(provider->ctx, nonce) != 0)
        goto done;
    if (provider->nonce_freshness_verified(provider->ctx, nonce) != 1)
        goto done;
    if (gwir_runtime_owner_init(owner, engine, saved, key, nonce, hmac,
                                crypto_ctx, scratch, scratch_capacity,
                                response, response_capacity) != 0)
        goto done;
    initialized = 1;
    /* Client must learn the fresh nonce through a trusted out-of-band channel.
     * If the client cannot receive it, do not expose a listener. */
    if (provider->deliver_nonce(provider->ctx, nonce) != 0)
        goto done;
    if (gwir_sdk_auth_task_start(owner, port) != 0)
        goto done;
    rc = 0;

done:
    if (rc != 0 && initialized)
        gwir_runtime_owner_clear(owner);
    wipe_secret(key, sizeof(key));
    wipe_secret(nonce, sizeof(nonce));
    return rc;
}
