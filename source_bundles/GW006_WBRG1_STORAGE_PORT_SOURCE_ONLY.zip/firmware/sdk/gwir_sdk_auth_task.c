#include "gwir_sdk_auth_task.h"
#include "../core/gwir_sta_gate.h"
#include "../realtek/gwir_amebad_auth_server.h"
#include "ameba_soc.h"
#include <wifi/wifi_conf.h>
#include <lwip_netconf.h>
#include <lwip/netif.h>
#include <string.h>

/* The vendor SDK exports the active Wi-Fi mode. Never use an AP+STA or
 * stale cached status: every server accept/receive checks it again. */
extern rtw_mode_t wifi_mode;
static volatile int task_active;
static volatile int task_stop;
static gwir_amebad_auth_server_config task_config;
static gwir_ir_pipeline *task_ir_pipeline;

static int poll_ir(void *ctx, uint32_t max_events)
{
    gwir_ir_pipeline *p = (gwir_ir_pipeline *)ctx;
    return gwir_ir_pipeline_pump(p, max_events);
}

int gwir_sdk_auth_task_bind_ir_pipeline(gwir_ir_pipeline *p)
{
    /* A NULL pointer revokes a pending binding before a task is launched. */
    if (!p && !task_active) { task_ir_pipeline = NULL; return 0; }
    if (task_active || task_ir_pipeline || !p || !p->ready ||
        !p->bus.ops.board_ir_ready ||
        p->bus.ops.board_ir_ready(p->bus.ops.ctx) != 1) return -1;
    task_ir_pipeline = p;
    return 0;
}


static int read_sta_snapshot(gwir_sta_snapshot *snapshot)
{
    uint8_t *ip;
    if (!snapshot) return 0;
    memset(snapshot, 0, sizeof(*snapshot));
    snapshot->sta_only = wifi_mode == RTW_MODE_STA;
    if (!snapshot->sta_only) return 0;
    snapshot->associated = wifi_is_connected_to_ap() == RTW_SUCCESS;
    if (!snapshot->associated) return 0;
    snapshot->netif_up = netif_is_up(&xnetif[0]) != 0;
    snapshot->link_up = netif_is_link_up(&xnetif[0]) != 0;
    if (!snapshot->netif_up || !snapshot->link_up) return 0;
    ip = LwIP_GetIP(&xnetif[0]);
    if (!ip) return 0;
    memcpy(snapshot->ipv4, ip, sizeof(snapshot->ipv4));
    return 1;
}

int gwir_sdk_auth_network_ready(void)
{
    gwir_sta_snapshot snapshot;
    uint32_t ip;
    return read_sta_snapshot(&snapshot) &&
           gwir_sta_gate_ip(&snapshot, &ip);
}

static int check_sta(void *context, uint32_t bound_ip)
{
    gwir_sta_snapshot snapshot;
    (void)context;
    return read_sta_snapshot(&snapshot) &&
           gwir_sta_gate_match(&snapshot, bound_ip);
}

static void auth_task(void *arg)
{
    (void)arg;
    (void)gwir_amebad_auth_server_run(&task_config);
    /* Single owner; stop and revoke keys on all exits (including Wi-Fi loss). */
    gwir_runtime_owner_clear(task_config.owner);
    if (task_ir_pipeline) (void)gwir_ir_pipeline_stop(task_ir_pipeline);
    task_ir_pipeline = NULL;
    memset(&task_config, 0, sizeof(task_config));
    task_stop = 1;
    task_active = 0;
    vTaskDelete(NULL);
}

int gwir_sdk_auth_task_start(gwir_runtime_owner *owner, uint16_t port)
{
    gwir_sta_snapshot snapshot;
    uint32_t ip;
    if (task_active || !owner || !owner->initialized || !owner->rx.active ||
        !owner->tx.active || !owner->engine || !owner->scratch ||
        !owner->signed_response || port < 1024u ||
        !read_sta_snapshot(&snapshot) || !gwir_sta_gate_ip(&snapshot, &ip))
        return -1;
    /* Only one caller may start/register this task before the scheduler.
     * The integrator must serialize lifecycle calls, not invoke from an ISR. */
    task_stop = 0;
    task_active = 1;
    memset(&task_config, 0, sizeof(task_config));
    task_config.owner = owner;
    task_config.port = port;
    task_config.sta_ip_network_order = ip;
    task_config.stop = &task_stop;
    task_config.check_sta = check_sta;
    if (task_ir_pipeline) {
        task_config.pump_ir = poll_ir;
        task_config.ir_ctx = task_ir_pipeline;
    }
    if (xTaskCreate(auth_task, "GWIR-AUTH", 2048u, NULL,
                    tskIDLE_PRIORITY + 1u, NULL) != pdPASS) {
        task_stop = 1;
        memset(&task_config, 0, sizeof(task_config));
        task_active = 0;
        return -2;
    }
    return 0;
}

int gwir_sdk_auth_task_request_stop(void)
{
    if (!task_active) return -1;
    task_stop = 1;
    return 0;
}
