#ifndef GWIR_SDK_BOOTSTRAP_H
#define GWIR_SDK_BOOTSTRAP_H
#include <stddef.h>
#include <stdint.h>
#include "gwir_sdk_secure_start.h"
#include "../realtek/gwir_ir_pipeline.h"

/* Production-shaped boot bridge, not a credential provider.
 * A future AUDITED GW006 board port may register this configuration only
 * from pre-scheduler startup (e.g. vendor pre_example_entry()).
 * All pointers including the provider and its ctx MUST refer to static
 * storage lasting until the authenticated service exits. Boot code must
 * not allocate an engine (~50 KB) on the FreeRTOS stack.
 * No default provider, embedded key, randomness fallback or IR enable.
 * In an unprovisioned build main calls schedule(); it returns -1 without
 * creating any task or listener. The boot task waits briefly for genuine
 * STA connectivity, then calls the fail-closed secure start function.
 */
typedef struct {
    const gwir_sdk_secure_provider *provider;
    gwir_runtime_owner *owner;
    gwir_engine *engine;
    gwir_saved_play_service *saved;
    gwir_auth_hmac_fn hmac;
    void *crypto_ctx;
    uint8_t *scratch;
    size_t scratch_capacity;
    uint8_t *response;
    size_t response_capacity;
    uint16_t port;
    /* Both optional pointers must be present together. No auto-activation.
     * A board port needs independently verified IR pinmux/IRQ first. */
    gwir_ir_pipeline *ir_pipeline;
    const gwir_ir_pipeline_config *ir_config;
} gwir_sdk_boot_config;

/* Register once, before GWIR's hook in vendor main. Never from an ISR. */
int gwir_sdk_boot_register(const gwir_sdk_boot_config *config);
/* Called from vendor main immediately before vTaskStartScheduler().
 * Seals registration even when nothing was registered; no default listener.
 * 0 means task registration only, NOT a running/provisioned service. */
int gwir_sdk_boot_schedule(void);

#endif
