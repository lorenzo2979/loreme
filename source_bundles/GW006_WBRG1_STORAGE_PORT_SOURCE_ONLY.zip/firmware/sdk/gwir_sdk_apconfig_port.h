#ifndef GWIR_SDK_APCONFIG_PORT_H
#define GWIR_SDK_APCONFIG_PORT_H
#include "../core/gwir_apconfig_session.h"
/* REV15: pure source wiring. Board gate remains permanently unapproved. */
int gwir_sdk_button_read_pb23(int *pressed);
int gwir_sdk_apconfig_install_backend(gwir_apcfg_backend ops);
int gwir_sdk_apconfig_start(void *ctx);
int gwir_sdk_apconfig_stop(void *ctx);
#endif
