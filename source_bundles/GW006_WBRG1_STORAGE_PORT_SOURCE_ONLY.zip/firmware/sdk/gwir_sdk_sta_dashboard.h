#ifndef GWIR_SDK_STA_DASHBOARD_H
#define GWIR_SDK_STA_DASHBOARD_H
/* Does nothing unless explicitly built with GWIR_ENABLE_STA_DASHBOARD_TRIAL.
 * This is a development-only endpoint. Does not authorize a board flash. */
int gwir_sdk_sta_dashboard_start(void);
#endif
