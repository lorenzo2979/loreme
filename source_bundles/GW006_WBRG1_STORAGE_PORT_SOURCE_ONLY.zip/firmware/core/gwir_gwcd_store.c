#include "gwir_gwcd_store.h"
#include <string.h>

static int read_at(gwir_gwcd_read_fn rd, void *ctx, uint32_t off,
                   void *buf, size_t bytes, uint32_t total) {
    if (!rd || !buf || off > total || bytes > (size_t)(total - off)) return -1;
    return rd(ctx, off, buf, bytes) == 0 ? 0 : -1;
}

static int valid_frame(const gwir_gwcd_frame_index *f) {
    return f->carrier_hz >= 25000u && f->carrier_hz <= 500000u &&
           f->duty_permille >= 200u && f->duty_permille <= 500u &&
           f->pulse_count >= 1u && f->pulse_count <= GWIR_MAX_PULSES_PER_FRAME &&
           f->gap_after_us <= 30000000u;
}

int gwir_gwcd_scan(gwir_gwcd_read_fn rd, void *ctx, uint32_t size,
                   uint8_t expected_button, gwir_gwcd_index *out) {
    uint8_t scratch[128], header[16], frame_hdr[12], checksum[4];
    uint32_t off, crc, expected_crc, count;
    gwir_gwcd_index candidate;
    if (!rd || !out || expected_button >= GWIR_GWCD_BUTTONS ||
        size < GWIR_GWCD_MIN_SIZE || size > GWIR_GWCD_MAX_SIZE) return -1;
    memset(&candidate, 0, sizeof(candidate));
    if (read_at(rd,ctx,0,header,sizeof(header),size) ||
        read_at(rd,ctx,size - 4,checksum,sizeof(checksum),size)) return -2;
    if (memcmp(header,"GWCD",4) || gwir_read_u32be(header+4) != 1u ||
        gwir_read_u32be(header+8) != expected_button) return -4;
    count = gwir_read_u32be(header+12);
    if (count < 1u || count > GWIR_MAX_FRAMES_PER_BUTTON) return -4;
    /* Check CRC before interpreting any pulse. 128 B is the largest buffer. */
    crc = 0xFFFFFFFFu;
    for (off=0; off < size - 4u;) {
        size_t n = size - 4u - off;
        if (n > sizeof(scratch)) n = sizeof(scratch);
        if (read_at(rd,ctx,off,scratch,n,size)) return -2;
        crc = gwir_crc32_continue(crc,scratch,n);
        off += (uint32_t)n;
    }
    expected_crc = gwir_read_u32be(checksum);
    if ((crc ^ 0xFFFFFFFFu) != expected_crc) return -3;

    candidate.button = expected_button;
    candidate.frame_count = (uint8_t)count;
    candidate.serialized_bytes = size;
    off = sizeof(header);
    for (uint32_t f=0; f<count; ++f) {
        gwir_gwcd_frame_index *frame = &candidate.frame[f];
        uint32_t pulses_len;
        if (read_at(rd,ctx,off,frame_hdr,sizeof(frame_hdr),size)) return -4;
        frame->carrier_hz = gwir_read_u32be(frame_hdr);
        frame->duty_permille = gwir_read_u16be(frame_hdr+4);
        frame->pulse_count = gwir_read_u16be(frame_hdr+6);
        frame->gap_after_us = gwir_read_u32be(frame_hdr+8);
        if (!valid_frame(frame)) return -4;
        off += sizeof(frame_hdr);
        frame->pulse_offset = off;
        pulses_len = (uint32_t)frame->pulse_count * 4u;
        if (off > size - 4u || pulses_len > size - 4u - off) return -4;
        for (uint32_t i=0; i<pulses_len;) {
            size_t n = pulses_len - i;
            if (n > sizeof(scratch)) n = sizeof(scratch);
            if (read_at(rd,ctx,off+i,scratch,n,size)) return -2;
            /* n and pulse lengths are always multiples of 4. */
            for (size_t k=0; k<n; k+=4) {
                uint32_t d = gwir_read_u32be(scratch+k);
                if (d==0u || d>30000000u) return -4;
            }
            i += (uint32_t)n;
        }
        off += pulses_len;
    }
    if (off != size - 4u) return -4;
    *out = candidate; /* publish only after full successful scan */
    return 0;
}

int gwir_gwcd_read_frame(gwir_gwcd_read_fn rd, void *ctx,
                         const gwir_gwcd_index *index, uint8_t frame,
                         uint32_t *pulses, size_t cap) {
    uint8_t tmp[128];
    const gwir_gwcd_frame_index *f;
    if (!rd || !index || !pulses || index->button >= GWIR_GWCD_BUTTONS ||
        index->frame_count == 0u || index->frame_count > GWIR_MAX_FRAMES_PER_BUTTON ||
        index->serialized_bytes < GWIR_GWCD_MIN_SIZE ||
        index->serialized_bytes > GWIR_GWCD_MAX_SIZE ||
        frame >= index->frame_count) return -1;
    f = &index->frame[frame];
    if (index->serialized_bytes < GWIR_GWCD_MIN_SIZE || !valid_frame(f) || cap < f->pulse_count ||
        f->pulse_offset > index->serialized_bytes - 4u ||
        (uint32_t)f->pulse_count * 4u > index->serialized_bytes - 4u - f->pulse_offset)
        return -1;
    for (uint32_t pos=0; pos<f->pulse_count; ) {
        size_t n = f->pulse_count - pos;
        if (n > sizeof(tmp)/4u) n = sizeof(tmp)/4u;
        if (read_at(rd,ctx,f->pulse_offset+pos*4u,tmp,n*4u,index->serialized_bytes))
            return -2;
        /* Caller must NOT transmit until complete validation succeeds. */
        for (size_t i=0;i<n;++i) {
            uint32_t d=gwir_read_u32be(tmp+i*4);
            if (!d || d>30000000u) return -4;
            pulses[pos+i]=d;
        }
        pos+=(uint32_t)n;
    }
    return 0;
}
uint32_t gwir_gwcd_worst_case_bytes(void) {
    return GWIR_GWCD_BUTTONS * GWIR_GWCD_MAX_SIZE;
}
