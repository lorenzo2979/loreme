#include "gwir_flash_journal.h"
#include <string.h>

#define FJ_MANIFEST_BODY (16u + 8u * GWIR_FJ_RECORDS)
#define FJ_CRC_OFF FJ_MANIFEST_BODY
#define FJ_MARK_OFF (FJ_CRC_OFF + 4u)
#define FJ_MANIFEST_SIZE (FJ_MARK_OFF + 4u)
#define FJ_MARKER 0x3CB16A94u

typedef struct {const gwir_fj_io *io;uint32_t off;uint32_t size;} record_reader;
static int record_read(void *ctx, uint32_t off, void *dst, size_t n);

static uint32_t ceil_sector(uint32_t n) {
    return (n + GWIR_FJ_SECTOR - 1u) & ~(GWIR_FJ_SECTOR - 1u);
}
static int read_f(const gwir_fj_io *io, uint32_t off, void *dst, size_t n) {
    if (off > io->region_size || n > (size_t)(io->region_size-off)) return -1;
    return io->read(io->ctx,off,dst,n);
}
static int write_f(const gwir_fj_io *io, uint32_t off, const void *src, size_t n) {
    if (off > io->region_size || n > (size_t)(io->region_size-off)) return -1;
    return io->program(io->ctx,off,src,n);
}
static int erase_f(const gwir_fj_io *io, uint32_t off) {
    if ((off % GWIR_FJ_SECTOR) || off > io->region_size ||
        io->region_size - off < GWIR_FJ_SECTOR) return -1;
    return io->erase_sector(io->ctx,off);
}
static int blank_region(const gwir_fj_io *io, uint32_t off, uint32_t n) {
    uint8_t buf[128];
    while (n) {
        uint32_t take = n > sizeof(buf) ? sizeof(buf) : n;
        if (read_f(io,off,buf,take)) return -1;
        for (uint32_t i=0;i<take;i++) if (buf[i]!=0xffu) return 0;
        off+=take;
        n-=take;
    }
    return 1;
}
/* A sector is not reusable when it belongs to any record referenced by
 * the CURRENT committed manifest, even when its unused tail reads as 0xff.
 * No allocation and no assumption about physical flash addresses. */
static int overlaps_live(const gwir_fj_store *s, uint32_t off, uint32_t n) {
    for (uint32_t i=0; i<GWIR_FJ_RECORDS; i++) {
        if (s->entry[i].bytes) {
            uint32_t start=s->entry[i].offset;
            uint32_t end=start+ceil_sector(s->entry[i].bytes);
            if (off<end && start<off+n) return 1;
        }
    }
    return 0;
}
/* Look only at erased, NON-LIVE sectors. Never erase or reuse a live record. */
static int find_free_run(const gwir_fj_store *s, uint32_t from, uint32_t padded,
                         uint32_t *found) {
    if (padded>s->io.region_size || from>s->io.region_size-padded) return -4;
    for (uint32_t pos=from;pos<=s->io.region_size-padded;pos+=GWIR_FJ_SECTOR) {
        if (overlaps_live(s,pos,padded)) continue;
        int blank=blank_region(&s->io,pos,padded);
        if (blank<0) return -2;
        if (blank==1) { *found=pos; return 0; }
    }
    return -4;
}

static void init_empty(gwir_fj_store *s) {
    for(uint32_t i=0;i<GWIR_FJ_RECORDS;i++) {
        s->entry[i].offset = 0xffffffffu;
        s->entry[i].bytes = 0u;
    }
    s->highwater = GWIR_FJ_DATA_START;
    s->active_bank = -1;
    s->generation = 0;
}
static void format_manifest(uint8_t *buf, const gwir_fj_entry *entries,
                            uint32_t generation, uint32_t highwater) {
    memset(buf,0xff,FJ_MANIFEST_SIZE);
    memcpy(buf,"GWFJ",4);
    gwir_write_u32be(buf+4,1u);
    gwir_write_u32be(buf+8,generation);
    gwir_write_u32be(buf+12,highwater);
    for(uint32_t i=0;i<GWIR_FJ_RECORDS;i++) {
        gwir_write_u32be(buf+16u+8u*i,entries[i].offset);
        gwir_write_u32be(buf+20u+8u*i,entries[i].bytes);
    }
    uint32_t crc = gwir_crc32_continue(0xffffffffu,buf,FJ_CRC_OFF)^0xffffffffu;
    gwir_write_u32be(buf+FJ_CRC_OFF,crc);
    gwir_write_u32be(buf+FJ_MARK_OFF,FJ_MARKER);
}
/* 1 valid, 0 erased/invalid, -1 read error. Invalid metadata is never loaded. */
static int read_manifest(const gwir_fj_io *io, uint32_t bank,
                         uint8_t *buf, uint32_t *generation) {
    if (read_f(io,bank*GWIR_FJ_SECTOR,buf,FJ_MANIFEST_SIZE)) return -1;
    if (memcmp(buf,"GWFJ",4) || gwir_read_u32be(buf+4)!=1u ||
        gwir_read_u32be(buf+FJ_MARK_OFF)!=FJ_MARKER) return 0;
    uint32_t crc = gwir_crc32_continue(0xffffffffu,buf,FJ_CRC_OFF)^0xffffffffu;
    if (gwir_read_u32be(buf+FJ_CRC_OFF)!=crc) return 0;
    uint32_t high = gwir_read_u32be(buf+12);
    if (high < GWIR_FJ_DATA_START || high > io->region_size ||
        high % GWIR_FJ_SECTOR) return 0;
    for(uint32_t i=0;i<GWIR_FJ_RECORDS;i++) {
        uint32_t off=gwir_read_u32be(buf+16u+8u*i);
        uint32_t len=gwir_read_u32be(buf+20u+8u*i);
        if (!len) {if(off!=0xffffffffu) return 0; continue;}
        if(off<GWIR_FJ_DATA_START || off%GWIR_FJ_SECTOR ||
           len>GWIR_GWCD_MAX_SIZE || len<GWIR_GWCD_MIN_SIZE ||
           off>high || len>high-off || ceil_sector(len)>high-off) return 0;
        /* Two live buttons may never reference overlapping flash sectors.
         * Reject even a correctly checksummed but internally inconsistent
         * manifest rather than making later updates unsafe. */
        for (uint32_t j=0;j<i;j++) {
            uint32_t other=gwir_read_u32be(buf+16u+8u*j);
            uint32_t other_len=gwir_read_u32be(buf+20u+8u*j);
            if (other_len && off < other + ceil_sector(other_len) &&
                other < off + ceil_sector(len)) return 0;
        }
    }
    *generation = gwir_read_u32be(buf+8);
    return 1;
}
int gwir_fj_open(gwir_fj_store *s, const gwir_fj_io *io) {
    uint8_t manifest[2][FJ_MANIFEST_SIZE];
    uint32_t seq[2]={0,0};
    int valid[2];
    if(!s || !io || !io->read || !io->program || !io->erase_sector ||
       io->region_size < 3u*GWIR_FJ_SECTOR ||
       io->region_size % GWIR_FJ_SECTOR) return -1;
    memset(s,0,sizeof(*s));
    s->io=*io;
    init_empty(s);
    for(uint32_t i=0;i<2;i++) {
        valid[i]=read_manifest(io,i,manifest[i],&seq[i]);
        if(valid[i]<0) return -2;
    }
    if (!valid[0] && !valid[1]) {
        int a=blank_region(io,0,GWIR_FJ_SECTOR),b=blank_region(io,GWIR_FJ_SECTOR,GWIR_FJ_SECTOR);
        if(a<0 || b<0) return -2;
        if(a!=1 || b!=1) return -3; /* Never assume corrupt metadata is virgin. */
        s->ready=1;
        return 0;
    }
    uint32_t choice=0;
    if(!valid[0]) choice=1;
    else if(valid[1]) {
        /* Unsigned serial arithmetic allows one rollover; ambiguous ties
         * are rejected if the bytes differ. */
        if(seq[0]==seq[1]) {
            if(memcmp(manifest[0],manifest[1],FJ_MANIFEST_SIZE)) return -3;
        } else {
            uint32_t distance=(uint32_t)(seq[1]-seq[0]);
            if (distance==0x80000000u) return -3; /* ambiguous modular order */
            if (distance<0x80000000u) choice=1;
        }
    }
    const uint8_t *p=manifest[choice];
    s->generation=seq[choice];
    s->highwater=gwir_read_u32be(p+12);
    for(uint32_t i=0;i<GWIR_FJ_RECORDS;i++) {
        s->entry[i].offset=gwir_read_u32be(p+16u+8u*i);
        s->entry[i].bytes=gwir_read_u32be(p+20u+8u*i);
    }
    s->active_bank=(int8_t)choice;
    /* A valid manifest CRC is insufficient: power loss, aging or bit flips
     * may corrupt a referenced GWCD record. Verify every live payload before
     * permitting ANY new flash writes. No fallback to an older committed
     * manifest (which could resurrect records explicitly deleted). */
    for (uint32_t i=0;i<GWIR_FJ_RECORDS;i++) {
        if (s->entry[i].bytes) {
            record_reader r={&s->io,s->entry[i].offset,s->entry[i].bytes};
            gwir_gwcd_index index;
            int rc=gwir_gwcd_scan(record_read,&r,r.size,(uint8_t)i,&index);
            if (rc) return rc==-2 ? -2 : -3;
        }
    }
    s->ready=1;
    return 0;
}
static int persist(gwir_fj_store *s, const gwir_fj_entry *new_entries,
                   uint32_t new_highwater) {
    uint8_t buf[FJ_MANIFEST_SIZE];
    uint32_t target=(s->active_bank==0) ? 1u : 0u;
    uint32_t base=target*GWIR_FJ_SECTOR;
    if(erase_f(&s->io,base)) return -2;
    format_manifest(buf,new_entries,s->generation+1u,new_highwater);
    /* Commit marker last. If power fails earlier, old bank is safe. */
    if(write_f(&s->io,base,buf,FJ_MARK_OFF) ||
       write_f(&s->io,base+FJ_MARK_OFF,buf+FJ_MARK_OFF,4)) return -2;
    /* Verify committed image before switching in-memory state. */
    uint8_t verify[FJ_MANIFEST_SIZE];
    uint32_t sequence;
    if(read_manifest(&s->io,target,verify,&sequence)!=1 ||
       memcmp(verify,buf,sizeof(buf))) return -2;
    memcpy(s->entry,new_entries,sizeof(s->entry));
    s->highwater=new_highwater;
    s->generation++;
    s->active_bank=(int8_t)target;
    return 0;
}
static int record_read(void *ctx, uint32_t off, void *dst, size_t n) {
    record_reader *r=(record_reader*)ctx;
    if(off>r->size || n>r->size-off) return -1;
    return read_f(r->io,r->off+off,dst,n);
}
int gwir_fj_lookup(const gwir_fj_store *s, uint8_t button,
                   uint32_t *offset, uint32_t *bytes) {
    if(!s || !s->ready || button >= GWIR_FJ_RECORDS || !offset || !bytes) return -1;
    if(!s->entry[button].bytes) return 1;
    record_reader r={&s->io,s->entry[button].offset,s->entry[button].bytes};
    gwir_gwcd_index index;
    int result=gwir_gwcd_scan(record_read,&r,r.size,button,&index);
    if (result == -2) return -2;
    if (result) return -3;
    *offset=r.off; *bytes=r.size;
    return 0;
}
/* Reclaim only sectors outside the currently committed live set. A power
 * cut during a sector erase cannot damage the current generation. The older
 * manifest can then refer to erased obsolete data, but mount always selects
 * the latest complete manifest; it must fail closed if that data is corrupt.
 * No compaction of live records, no wear balancing, no physical-flash policy.
 * A board adapter MUST first prove this region is exclusively GWIR-owned.
 */
int gwir_fj_reclaim(gwir_fj_store *s) {
    if (!s || !s->ready) return -1;
    /* Never erase anything if the current live set is already corrupted. */
    for (uint32_t i=0;i<GWIR_FJ_RECORDS;i++) {
        if (s->entry[i].bytes) {
            uint32_t o=0,n=0;
            int rc=gwir_fj_lookup(s,(uint8_t)i,&o,&n);
            if (rc) return rc==-2 ? -2 : -3;
        }
    }
    for (uint32_t off=GWIR_FJ_DATA_START;
         off<s->io.region_size;off+=GWIR_FJ_SECTOR) {
        if (!overlaps_live(s,off,GWIR_FJ_SECTOR)) {
            int blank=blank_region(&s->io,off,GWIR_FJ_SECTOR);
            if (blank<0) return -2;
            if (blank==0 && erase_f(&s->io,off)) return -2;
        }
    }
    return 0;
}

int gwir_fj_put(gwir_fj_store *s, uint8_t button, gwir_gwcd_read_fn source,
                void *source_ctx, uint32_t source_bytes) {
    uint8_t buf[128];
    uint32_t position, padded;
    gwir_fj_entry entries[GWIR_FJ_RECORDS];
    gwir_gwcd_index verified;
    if(!s || !s->ready || !source || button >= GWIR_FJ_RECORDS ||
       source_bytes<GWIR_GWCD_MIN_SIZE || source_bytes>GWIR_GWCD_MAX_SIZE) return -1;
    if(gwir_gwcd_scan(source,source_ctx,source_bytes,button,&verified)) return -5;
    padded=ceil_sector(source_bytes);
    /* Prefer fresh append sectors. If exhausted, erase ONLY unreferenced
     * payload sectors and safely reuse a contiguous erased span. This also
     * recovers torn, uncommitted payloads after a power cut. */
    int rc=find_free_run(s,s->highwater,padded,&position);
    if (rc==-4) {
        rc=gwir_fj_reclaim(s);
        if (rc) return rc;
        rc=find_free_run(s,GWIR_FJ_DATA_START,padded,&position);
    }
    if (rc) return rc;
    for(uint32_t off=0;off<source_bytes;) {
        uint32_t n=source_bytes-off;
        if(n>sizeof(buf)) n=sizeof(buf);
        if(source(source_ctx,off,buf,n) || write_f(&s->io,position+off,buf,n)) return -2;
        off+=n;
    }
    record_reader r={&s->io,position,source_bytes};
    if(gwir_gwcd_scan(record_read,&r,source_bytes,button,&verified)) return -2;
    memcpy(entries,s->entry,sizeof(entries));
    entries[button].offset=position;
    entries[button].bytes=source_bytes;
    uint32_t next_highwater=position+padded;
    if (next_highwater<s->highwater) next_highwater=s->highwater;
    return persist(s,entries,next_highwater);
}
int gwir_fj_delete(gwir_fj_store *s, uint8_t button) {
    gwir_fj_entry entries[GWIR_FJ_RECORDS];
    if(!s || !s->ready || button >= GWIR_FJ_RECORDS) return -1;
    if(!s->entry[button].bytes) return 0;
    memcpy(entries,s->entry,sizeof(entries));
    entries[button].offset=0xffffffffu;
    entries[button].bytes=0;
    return persist(s,entries,s->highwater);
}
uint32_t gwir_fj_worst_case_bytes(void) {
    return GWIR_FJ_DATA_START+GWIR_FJ_RECORDS*ceil_sector(GWIR_GWCD_MAX_SIZE);
}
/* Capacity for all 96 maximally filled buttons AND one atomic replacement.
 * Excludes vendor image, OTA/calibration and flash endurance margins. */
uint32_t gwir_fj_worst_case_rewrite_bytes(void) {
    return gwir_fj_worst_case_bytes()+ceil_sector(GWIR_GWCD_MAX_SIZE);
}


/* Physical authorization is checked before flash access and for every
 * frame; no firmware pinmux or network listener is enabled here. */
int gwir_fj_play(gwir_fj_store *s, uint8_t button,
                 const gwir_fj_play_ops *ops, uint32_t *pulse_scratch,
                 size_t pulse_capacity, uint8_t *frames_done) {
    uint32_t offset=0, length=0;
    gwir_gwcd_index index;
    record_reader r;
    int rc;
    if (frames_done) *frames_done=0;
    if (!s || !s->ready || button >= GWIR_FJ_RECORDS ||
        !ops || !ops->board_ir_ready || !ops->send_frame ||
        !pulse_scratch || pulse_capacity == 0 || !frames_done) return -1;
    if (ops->board_ir_ready(ops->ctx) != 1) return -6;
    rc=gwir_fj_lookup(s,button,&offset,&length);
    if (rc == 1) return 1;
    if (rc == -3) return -3;
    if (rc != 0) return -2;
    r.io=&s->io; r.off=offset; r.size=length;
    rc=gwir_gwcd_scan(record_read,&r,length,button,&index);
    if (rc == -2) return -2;
    if (rc) return -3;
    /* Reject too-small caller buffer BEFORE sending any of the frames. */
    for (uint32_t f=0;f<index.frame_count;f++) {
        if (index.frame[f].pulse_count > pulse_capacity) return -4;
    }
    for (uint32_t f=0;f<index.frame_count;f++) {
        const gwir_gwcd_frame_index *frame=&index.frame[f];
        if (ops->board_ir_ready(ops->ctx) != 1) return -6;
        rc=gwir_gwcd_read_frame(record_read,&r,&index,(uint8_t)f,
                                 pulse_scratch,pulse_capacity);
        if (rc == -2) return -2;
        if (rc) return -3;
        if (ops->board_ir_ready(ops->ctx) != 1) return -6;
        if (ops->send_frame(ops->ctx,frame->carrier_hz,frame->duty_permille,
                            pulse_scratch,frame->pulse_count,
                            frame->gap_after_us)) return -5;
        (*frames_done)++;
    }
    return 0;
}
