#ifndef GWIR_STA_GATE_H
#define GWIR_STA_GATE_H
#include <stdint.h>
/* A portable, fail-closed snapshot of the SDK's STA/AP state. The 4 IPv4
 * bytes are ordered as printed (network order); never reinterpret as host u32
 * for address validation. */
typedef struct {
    int sta_only;
    int associated;
    int netif_up;
    int link_up;
    uint8_t ipv4[4];
} gwir_sta_snapshot;
/* Returns 1 and copies exact IPv4 socket representation, or 0 without writing.
 * This is a *policy check*, not a proof of network-interface isolation. */
int gwir_sta_gate_ip(const gwir_sta_snapshot *snapshot, uint32_t *ip_network_order);
int gwir_sta_gate_match(const gwir_sta_snapshot *snapshot, uint32_t expected_ip_network_order);
#endif
