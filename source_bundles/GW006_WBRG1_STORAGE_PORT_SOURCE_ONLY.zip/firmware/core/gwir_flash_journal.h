#ifndef GWIR_FLASH_JOURNAL_H
#define GWIR_FLASH_JOURNAL_H
#include <stddef.h>
#include <stdint.h>
#include "gwir_gwcd_store.h"

/* Device-agnostic NOR flash journal, not a WBRG1 flash driver.
 * The WHOLE region must be explicitly reserved by the eventual bootloader /
 * partition layout. NEVER pass the address of an unknown vendor partition.
 * Sector size 4096; flash programming must only change 1-bits to 0-bits.
 * Two 4KiB commit sectors; GWCD payload records append in sector units.
 * Lazy sector reclamation: obsolete, UNREFERENCED payload sectors can be
 * erased and reused when append space runs out. Requires one maximum-record
 * free span for atomic replacement of a fully populated 96-button store.
 * Reclaim is not wear leveling; flash endurance must still be assessed.
 * All calls must be serialized by the owner task; callbacks and store are
 * not thread-safe. Indices are not protected from hostile flash tampering.
 * Mount rechecks every live record CRC (up to ~4 MiB of flash reads) and
 * fails closed rather than exposing records with silent data corruption.
 */
#define GWIR_FJ_SECTOR 4096u
#define GWIR_FJ_RECORDS GWIR_GWCD_BUTTONS
#define GWIR_FJ_DATA_START (2u * GWIR_FJ_SECTOR)

/* All callback offsets are relative to the DEDICATED partition, not raw
 * physical flash addresses. Callbacks must return 0 only on full success.
 * Programming byte streams across page boundaries is adapter responsibility.
 * No operation may cross the region boundary. */
typedef struct {
    void *ctx;
    int (*read)(void *ctx, uint32_t off, void *dst, size_t n);
    int (*program)(void *ctx, uint32_t off, const void *src, size_t n);
    int (*erase_sector)(void *ctx, uint32_t off);
    uint32_t region_size;
} gwir_fj_io;

typedef struct {
    uint32_t offset;
    uint32_t bytes;
} gwir_fj_entry;

typedef struct {
    gwir_fj_io io;
    gwir_fj_entry entry[GWIR_FJ_RECORDS];
    uint32_t generation;
    uint32_t highwater;
    int8_t active_bank; /* -1 if brand new and both commit sectors blank */
    uint8_t ready;
} gwir_fj_store;

/* Returns 0 OK, -1 bad arguments/layout, -2 I/O error, -3 corrupted or
 * conflicting metadata, -4 out of space, -5 invalid GWCD record. */
int gwir_fj_open(gwir_fj_store *s, const gwir_fj_io *io);
int gwir_fj_put(gwir_fj_store *s, uint8_t button, gwir_gwcd_read_fn source,
                void *source_ctx, uint32_t source_bytes);
int gwir_fj_delete(gwir_fj_store *s, uint8_t button);
/* Explicit, optional reclamation of unreferenced payload sectors only.
 * Requires a verified exclusively reserved partition; a power loss during
 * reclaim must not invalidate the latest committed generation.
 * Returns 0 OK, -1 invalid state, -2 flash I/O, -3 corrupt live record.
 * Does not reclaim metadata sectors and does not move live payloads. */
int gwir_fj_reclaim(gwir_fj_store *s);
/* Lookup: 0 record, 1 empty, -1 invalid args, -2 flash I/O, -3 corruption. */
int gwir_fj_lookup(const gwir_fj_store *s, uint8_t button,
                   uint32_t *offset, uint32_t *bytes);
uint32_t gwir_fj_worst_case_bytes(void);
/* 96 maximum GWCD records + space for one maximum-sized atomic rewrite. */
uint32_t gwir_fj_worst_case_rewrite_bytes(void);
/* CP28: playback bridge for ONE persisted 96-button GWCD record. This layer
 * performs NO hardware initialization and does not authenticate requests:
 * use it only from a serialized, authenticated command handler.
 * board_ir_ready MUST return exactly 1; the actual GW006 implementation
 * still denies that approval. Pulse scratch must be caller-owned/static
 * (up to 8192 bytes), never placed on a small FreeRTOS task stack.
 * One frame is validated before each transmission. A later flash/IR error
 * can occur after earlier frames have been sent (no atomic IR playback).
 * Flash writes/deletes and this read must not run concurrently. */
typedef struct {
    void *ctx;
    int (*board_ir_ready)(void *ctx);
    int (*send_frame)(void *ctx, uint32_t carrier_hz, uint16_t duty_permille,
                      const uint32_t *durations_us, uint16_t pulse_count,
                      uint32_t gap_after_us);
} gwir_fj_play_ops;

/* 0 = all frames transmitted, 1 = button empty, -1 = bad arguments,
 * -2 = flash read/I/O error, -3 = record corrupted, -4 = insufficient
 * caller scratch, -5 = TX failure, -6 = physical IR not approved.
 * frames_done is updated only for completely accepted TX callbacks. */
int gwir_fj_play(gwir_fj_store *store, uint8_t button,
                 const gwir_fj_play_ops *ops, uint32_t *pulse_scratch,
                 size_t pulse_capacity, uint8_t *frames_done);

#endif
