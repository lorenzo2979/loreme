#ifndef GWIR_RUNTIME_OWNER_H
#define GWIR_RUNTIME_OWNER_H

#include "gwir_auth_stream.h"
#include "gwir_saved_play_command.h"

/* CP31: one serialized owner for authentication + saved-button playback.
 * Pure portable protocol glue: NO socket, flash partition assignment, keys,
 * randomness, GPIO, IR initialization, Wi-Fi or FreeRTOS task is created here.
 *
 * The integrator MUST:
 *  - allocate owner/engine/buffers statically, zero initialize the owner;
 *  - obtain key from a trusted device-specific provisioning/secure store;
 *  - generate a fresh unpredictable nonce on EACH BOOT and communicate it to
 *    authenticated clients out of band; never reuse it after a restart;
 *  - call all APIs on the same owner task (no concurrent socket clients);
 *  - use ONE connection at a time, strict network deadlines, STA-only access;
 *  - reserve NOR partition, mount store, verify physical IR permission first;
 *  - call disconnect on socket error/timeout, never fall back to raw GWIR TCP.
 * Counter state survives disconnect within the current boot, not power loss.
 */
typedef struct {
    gwir_auth_session rx;
    gwir_auth_session tx;
    gwir_auth_stream stream;
    gwir_engine *engine;
    gwir_saved_play_service *saved; /* NULL => saved command unsupported */
    uint8_t *scratch;
    size_t scratch_cap;
    uint8_t *signed_response;
    size_t response_cap;
    uint8_t initialized;
    uint8_t connected;
} gwir_runtime_owner;

/* Caller must use zero-initialized storage; cannot reinitialize a live owner.
 * If any argument is invalid, no session or network state is enabled.
 * 0 success, -1 validation failure; accepts no all-zero key/nonce. */
int gwir_runtime_owner_init(gwir_runtime_owner *o, gwir_engine *engine,
    gwir_saved_play_service *saved,
    const uint8_t key[GWIR_AUTH_KEY_BYTES],
    const uint8_t boot_nonce[GWIR_AUTH_NONCE_BYTES],
    gwir_auth_hmac_fn hmac, void *crypto_ctx,
    uint8_t *scratch, size_t scratch_cap,
    uint8_t *signed_response, size_t response_cap);

/* Open one serialized authenticated connection; refuses parallel connections.
 * A reopened socket does NOT reset RX replay counter or response counter. */
int gwir_runtime_owner_connect(gwir_runtime_owner *o);
int gwir_runtime_owner_feed(gwir_runtime_owner *o, const uint8_t *data, size_t n,
    gwir_auth_stream_send_fn send, void *send_ctx);
void gwir_runtime_owner_disconnect(gwir_runtime_owner *o);
/* Shut down and wipe session secrets; any new init needs a DIFFERENT nonce. */
void gwir_runtime_owner_clear(gwir_runtime_owner *o);

#endif
