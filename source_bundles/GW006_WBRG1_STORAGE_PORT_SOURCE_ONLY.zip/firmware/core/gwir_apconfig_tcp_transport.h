#ifndef GWIR_APCONFIG_TCP_TRANSPORT_H
#define GWIR_APCONFIG_TCP_TRANSPORT_H
#include <stddef.h>
#include <stdint.h>
#include "gwir_apconfig_http_stream.h"

/* REV21: portable single-client socket service, not a Realtek TCP listener.
 * Real adapter MUST pre-create a socket bound to the AP local address AND
 * attest netif affinity with trusted SDK metadata. Host/source IP and HTTP
 * headers are never an acceptable proof. Caller serializes invocations. */
#define GWIR_APTCP_ACCEPT_WAIT_MS 100u
#define GWIR_APTCP_IO_WAIT_MS 100u
#define GWIR_APTCP_WRITE_BUDGET_MS 750u
#define GWIR_APTCP_MAX_STEPS 512u
#define GWIR_APTCP_READ_CAP 128u

typedef struct {
    void *ctx;
    /* Return 1 ONLY if listener is on the currently live AP netif.
       The listener must be previously bound to the AP's specific local IP.
       Return 0 (or negative) on ambiguous/absent AP status. */
    int (*listener_on_ap)(void *ctx);
    /* Called no longer than max_wait_ms, returns 1 when a client was
       accepted, 0 if none, -1 on error. Only one client may be active. */
    int (*accept_one)(void *ctx, uint32_t max_wait_ms);
    /* Return 1 only when accepted socket belongs to the actual AP netif. */
    int (*client_on_ap)(void *ctx);
    /* recv: 1..cap bytes; 0 EOF; -2 no data/timeout; -1 I/O failure.
       A call MUST finish within max_wait_ms. */
    int (*recv_some)(void *ctx, uint8_t *dst, size_t cap, uint32_t max_wait_ms);
    /* send: 1..n bytes; <=0 indicates failure/no progress.
       A call MUST finish within max_wait_ms. */
    int (*send_some)(void *ctx, const uint8_t *bytes, size_t n,
                     uint32_t max_wait_ms);
    void (*close_client)(void *ctx);
    /* 32-bit monotonically increasing milliseconds (wrap is supported). */
    uint32_t (*now_ms)(void *ctx);
} gwir_aptcp_ops;

typedef enum {
    GWIR_APTCP_IDLE = 0,       /* No accepted client; no change */
    GWIR_APTCP_REPLIED = 1,    /* A complete HTTP response attempted */
    GWIR_APTCP_DISCONNECTED = 2, /* Remote closed before request complete */
    GWIR_APTCP_REJECTED = 3,   /* Untrusted socket was rejected */
    GWIR_APTCP_UNAVAILABLE = -1, /* Inactive/uncertain AP or listener */
    GWIR_APTCP_IO_FAILURE = -2,
    GWIR_APTCP_INVALID_CALL = -3
} gwir_aptcp_result;

/* Processes at most one accepted TCP client in the caller's dedicated task.
 * Does not configure AP/DHCP, make/bind/listen a socket, save credentials,
 * start threads, or change pinmux/flash. No dynamic allocations.
 * Callback adapters MUST guarantee timeout bounds; no asynchronous calls.
 * A vendor adapter that cannot verify AP netif MUST fail closed. */
int gwir_aptcp_serve_one(const gwir_aptcp_ops *tcp,
                         const gwir_apcfg_session *session,
                         const gwir_station_ops *station);
#endif
