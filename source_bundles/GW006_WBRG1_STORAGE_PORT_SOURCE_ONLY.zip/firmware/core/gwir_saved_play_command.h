#ifndef GWIR_SAVED_PLAY_COMMAND_H
#define GWIR_SAVED_PLAY_COMMAND_H
#include "gwir_auth_dispatch.h"
#include "gwir_flash_journal.h"

/* CP29: authenticated GWIR_TX_SAVED (one-byte button 0..95) handler.
 * Only pass to gwir_auth_dispatch_routed or gwir_auth_stream_feed_routed.
 * Runs synchronously within an EXCLUSIVE serialized IR/flash task. Never
 * allocate the 2048-duration scratch on a FreeRTOS worker stack.
 * GW006 board_ir_ready is still disabled: no physical IR transmission.
 * New successful control sequence must be strictly increasing/nonzero per
 * boot. Same sequence+button returns the cached result WITHOUT retransmit.
 * Any older sequence, same sequence with other button => BAD_REQUEST.
 * Retrying after an ACK is lost requires the SAME GWIR sequence with a NEW
 * valid GWAS counter; the signature and session nonce still must verify.
 * Device restart loses this cache, so callers must not retry across reboot.
 */
typedef struct {
    gwir_fj_store *store;
    const gwir_fj_play_ops *ir;
    uint32_t *pulse_scratch;
    size_t pulse_capacity;
    uint32_t last_sequence;
    uint8_t last_button;
    uint8_t last_status;
    uint8_t last_frames_done;
    uint8_t last_valid;
} gwir_saved_play_service;

/* Explicitly initialize the per-boot service and clear cached sequence state.
 * Passing NULL, a missing callback or insufficient scratch fails closed.
 * Never reinitialize while a request is in progress. */
int gwir_saved_play_init(gwir_saved_play_service *service,
                         gwir_fj_store *store, const gwir_fj_play_ops *ir,
                         uint32_t *pulse_scratch, size_t pulse_capacity);

/* Respond with GWIR_SAVED_STATUS: two-byte payload [status,frames_done].
 * Nonzero result means response buffer/contract failure; closes connection.
 * A signed error status is returned for missing/unready IR hardware. */
int gwir_saved_play_command(void *ctx, const gwir_message *msg,
                            gwir_engine *engine, uint8_t *response,
                            size_t capacity, size_t *response_len);
#endif
