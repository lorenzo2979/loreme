#include "gwir_apconfig_http_stream.h"
#include <stddef.h>
#include <stdint.h>

static void erase(volatile void *data, size_t len)
{
    volatile uint8_t *p = (volatile uint8_t *)data;
    while (len--) *p++ = 0u;
}
static int ci_equal(const uint8_t *text, size_t len, const char *literal)
{
    size_t i;
    for (i = 0u; i < len && literal[i]; ++i) {
        unsigned a = text[i];
        unsigned b = (unsigned char)literal[i];
        if (a >= 'A' && a <= 'Z') a += 'a' - 'A';
        if (b >= 'A' && b <= 'Z') b += 'a' - 'A';
        if (a != b) return 0;
    }
    return i == len && literal[i] == '\0';
}

/* Length extractor is intentionally NOT an alternate acceptance parser:
   the authoritative REV19 parser verifies all headers, content and form
   before any stage/verify/commit operation. Extraction merely bounds reads. */
/* Header length extraction must scan the ENTIRE header to reject a second
   Content-Length, even if a first valid one was encountered. */
static int body_length(const uint8_t *data, size_t header_end, size_t *expected)
{
    size_t p = 0u, end;
    unsigned found = 0u;
    size_t length = 0u;
    while (p + 1u < header_end) {
        size_t colon, begin, trimmed;
        end = p;
        while (end + 1u < header_end &&
               !(data[end] == '\r' && data[end + 1u] == '\n')) ++end;
        if (end + 1u >= header_end) return -1;
        if (p == end) break;
        if (p != 0u) {
            colon = p;
            while (colon < end && data[colon] != ':') ++colon;
            if (colon < end && ci_equal(data + p, colon - p, "content-length")) {
                if (++found != 1u) return -1;
                begin = colon + 1u;
                trimmed = end;
                while (begin < trimmed && data[begin] == ' ') ++begin;
                while (trimmed > begin && data[trimmed - 1u] == ' ') --trimmed;
                if (trimmed == begin) return -1;
                length = 0u;
                for (; begin < trimmed; ++begin) {
                    size_t digit;
                    if (data[begin] < '0' || data[begin] > '9') return -1;
                    digit = (size_t)(data[begin] - '0');
                    if (length > (GWIR_PROVISION_BODY_MAX - digit) / 10u)
                        return -1;
                    length = length * 10u + digit;
                }
            }
        }
        p = end + 2u;
    }
    if (found != 1u || length == 0u) return -1;
    *expected = header_end + length;
    return *expected <= GWIR_APHTTP_REQUEST_MAX ? 0 : -1;
}

static const char response_204[] =
    "HTTP/1.1 204 No Content\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Length: 0\r\n\r\n";
static const char response_400[] =
    "HTTP/1.1 400 Bad Request\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Length: 0\r\n\r\n";
static const char response_403[] =
    "HTTP/1.1 403 Forbidden\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Length: 0\r\n\r\n";
static const char response_408[] =
    "HTTP/1.1 408 Request Timeout\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Length: 0\r\n\r\n";
static const char response_413[] =
    "HTTP/1.1 413 Content Too Large\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Length: 0\r\n\r\n";
static const char response_503[] =
    "HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Length: 0\r\n\r\n";

static int done(gwir_apstream *s, unsigned status, const gwir_apstream_io *io)
{
    const char *wire;
    size_t n;
    int ok;
    if (!s || s->terminated || !io || !io->write_all || !io->close)
        return GWIR_APSTREAM_INVALID_CALL;
    switch (status) {
    case 204u: wire = response_204; n = sizeof(response_204) - 1u; break;
    case 403u: wire = response_403; n = sizeof(response_403) - 1u; break;
    case 408u: wire = response_408; n = sizeof(response_408) - 1u; break;
    case 413u: wire = response_413; n = sizeof(response_413) - 1u; break;
    case 503u: wire = response_503; n = sizeof(response_503) - 1u; break;
    default: status = 400u; wire = response_400; n = sizeof(response_400) - 1u; break;
    }
    s->terminated = 1u;
    s->status = status;
    erase(s->request, sizeof(s->request));
    s->len = s->header_end = s->expected_total = 0u;
    ok = io->write_all(io->ctx, (const uint8_t *)wire, n);
    io->close(io->ctx);
    return ok == 0 ? GWIR_APSTREAM_CLOSED : GWIR_APSTREAM_IO_FAILURE;
}

int gwir_apstream_init(gwir_apstream *s, uint32_t opened_ms,
                       int trusted_ap_interface)
{
    if (!s || (trusted_ap_interface != 0 && trusted_ap_interface != 1)) return -1;
    erase(s, sizeof(*s));
    s->opened_ms = s->last_rx_ms = opened_ms;
    s->trusted_ap_interface = (unsigned)trusted_ap_interface;
    return 0;
}
static int guard(gwir_apstream *s, uint32_t now_ms,
                 const gwir_apcfg_session *session,
                 const gwir_apstream_io *io)
{
    if (!s || s->terminated || !io || !io->write_all || !io->close)
        return GWIR_APSTREAM_INVALID_CALL;
    if (!s->trusted_ap_interface || !gwir_apcfg_session_is_active(session))
        return done(s, 403u, io);
    if ((uint32_t)(now_ms - s->opened_ms) >= GWIR_APSTREAM_TOTAL_MS ||
        (uint32_t)(now_ms - s->last_rx_ms) >= GWIR_APSTREAM_IDLE_MS)
        return done(s, 408u, io);
    return GWIR_APSTREAM_MORE;
}

int gwir_apstream_feed(gwir_apstream *s, const uint8_t *chunk, size_t count,
                       uint32_t now_ms, const gwir_apcfg_session *session,
                       const gwir_station_ops *ops, const gwir_apstream_io *io)
{
    size_t old;
    int gate;
    if (!s || !chunk || !count || !io || !io->write_all || !io->close || s->terminated)
        return GWIR_APSTREAM_INVALID_CALL;
    gate = guard(s, now_ms, session, io);
    if (gate != GWIR_APSTREAM_MORE) return gate;
    if (count > sizeof(s->request) - s->len) return done(s, 413u, io);
    old = s->len;
    for (size_t i = 0u; i < count; ++i) s->request[old + i] = chunk[i];
    s->len += count;
    s->last_rx_ms = now_ms;
    if (!s->header_end && s->len >= 4u) {
        size_t start = old >= 3u ? old - 3u : 0u;
        for (size_t i = start; i + 3u < s->len; ++i) {
            if (s->request[i] == '\r' && s->request[i+1u] == '\n' &&
                s->request[i+2u] == '\r' && s->request[i+3u] == '\n') {
                s->header_end = i + 4u;
                break;
            }
        }
    }
    if (!s->header_end) {
        if (s->len >= GWIR_APHTTP_HEADER_MAX) return done(s, 413u, io);
        return GWIR_APSTREAM_MORE;
    }
    if (s->header_end > GWIR_APHTTP_HEADER_MAX)
        return done(s, 413u, io);
    if (!s->expected_total &&
        body_length(s->request, s->header_end, &s->expected_total) != 0)
        return done(s, 400u, io);
    if (s->len > s->expected_total)
        return done(s, 400u, io);
    if (s->len < s->expected_total)
        return GWIR_APSTREAM_MORE;
    gate = gwir_aphttp_apply(s->request, s->len, session, 1, ops);
    if (gate == GWIR_APHTTP_OK) return done(s, 204u, io);
    if (gate == GWIR_APHTTP_FORBIDDEN) return done(s, 403u, io);
    if (gate == GWIR_APHTTP_BACKEND_FAILURE) return done(s, 503u, io);
    return done(s, 400u, io);
}

int gwir_apstream_poll(gwir_apstream *s, uint32_t now_ms,
                       const gwir_apcfg_session *session,
                       const gwir_apstream_io *io)
{
    return guard(s, now_ms, session, io);
}

void gwir_apstream_discard(gwir_apstream *s)
{
    if (!s) return;
    erase(s->request, sizeof(s->request));
    s->len = s->header_end = s->expected_total = 0u;
    s->terminated = 1u;
}
