#include "gwir_saved_play_command.h"
#include <string.h>

int gwir_saved_play_init(gwir_saved_play_service *service,
                         gwir_fj_store *store, const gwir_fj_play_ops *ir,
                         uint32_t *pulse_scratch, size_t pulse_capacity)
{
    if (!service || !store || !ir || !ir->board_ir_ready ||
        !ir->send_frame || !pulse_scratch ||
        pulse_capacity < GWIR_MAX_PULSES_PER_FRAME) return -1;
    memset(service, 0, sizeof(*service));
    service->store = store;
    service->ir = ir;
    service->pulse_scratch = pulse_scratch;
    service->pulse_capacity = pulse_capacity;
    return 0;
}

int gwir_saved_play_command(void *ctx, const gwir_message *msg,
                            gwir_engine *engine, uint8_t *response,
                            size_t capacity, size_t *response_len)
{
    gwir_saved_play_service *service = (gwir_saved_play_service *)ctx;
    uint8_t status = GWIR_BAD_REQUEST;
    uint8_t done = 0u;
    int rc;
    uint8_t button;
    uint8_t result[2];
    if (response_len) *response_len = 0u;
    if (!msg || !engine || !response || !response_len ||
        msg->command != GWIR_TX_SAVED || capacity < GWIR_HEADER_SIZE + 2u)
        return -1;
    if (msg->payload_len != 1u || !msg->payload ||
        msg->payload[0] >= GWIR_FJ_RECORDS || msg->sequence == 0u)
        goto encode;
    button = msg->payload[0];
    if (!service) { status = GWIR_NOT_READY; goto encode; }
    if (service->last_valid) {
        if (msg->sequence < service->last_sequence ||
            (msg->sequence == service->last_sequence &&
             button != service->last_button)) goto encode;
        if (msg->sequence == service->last_sequence) {
            status = service->last_status;
            done = service->last_frames_done;
            goto encode;
        }
    }
    if (engine->rx_armed) status = GWIR_BUSY;
    else if (!service->store || !service->store->ready || !service->ir ||
             !service->pulse_scratch || service->pulse_capacity == 0u)
        status = GWIR_NOT_READY;
    else {
        rc = gwir_fj_play(service->store, button, service->ir,
                          service->pulse_scratch, service->pulse_capacity,
                          &done);
        switch (rc) {
            case 0: status = GWIR_OK; break;
            case 1: status = GWIR_NO_SAVED_CODE; break;
            case -2: case -3: status = GWIR_STORAGE_ERROR; break;
            case -4: status = GWIR_RANGE; break;
            case -5: status = GWIR_IR_FAILED; break;
            case -6: status = GWIR_NOT_READY; break;
            default: status = GWIR_BAD_REQUEST; break;
        }
    }
    /* Cache even failures/partial sends; retry never fires again by accident.
     * Only the last accepted saved-button command is cached in RAM. */
    service->last_sequence = msg->sequence;
    service->last_button = button;
    service->last_status = status;
    service->last_frames_done = done;
    service->last_valid = 1u;
encode:
    result[0] = status;
    result[1] = done;
    return gwir_encode(response, capacity, GWIR_SAVED_STATUS,
                       msg->sequence, result, sizeof(result), response_len);
}
