#include "gwir_dashboard_http.h"
#include "gwir_dashboard_asset.h"
#include <stdio.h>
#include <string.h>

static int eq_ci(const uint8_t *a, size_t na, const char *b)
{
    size_t i;
    if (strlen(b) != na) return 0;
    for (i = 0; i < na; i++) {
        unsigned char c = a[i], d = (unsigned char)b[i];
        if (c >= 'A' && c <= 'Z') c = (unsigned char)(c + 32);
        if (d >= 'A' && d <= 'Z') d = (unsigned char)(d + 32);
        if (c != d) return 0;
    }
    return 1;
}
static int write_all(gwir_dash_http_write_fn writer, void *ctx, const uint8_t *data, size_t len)
{
    size_t at = 0;
    while (at < len) {
        size_t step = len - at;
        int sent;
        if (step > 384u) step = 384u;
        sent = writer(ctx, data + at, step);
        if (sent <= 0 || (size_t)sent > step) return -1;
        at += (size_t)sent;
    }
    return 0;
}
void gwir_dash_http_init(gwir_dash_http_connection *s)
{
    if (s) memset(s, 0, sizeof(*s));
}
int gwir_dash_http_feed(gwir_dash_http_connection *s, const uint8_t *data, size_t len)
{
    size_t i;
    if (!s || (!data && len) || s->failed || s->ready) return -1;
    if (len > GWIR_DASH_HTTP_MAX_REQUEST - s->used) { s->failed = 1u; return -1; }
    for (i = 0; i < len; i++) {
        uint8_t b = data[i];
        /* Reject NUL and opaque binary in a header-only GET request. */
        if (b == 0 || (b < 32 && b != '\r' && b != '\n' && b != '\t') || b == 127) {
            s->failed = 1u; return -1;
        }
        if ((b == '\n' && (s->used == 0 || s->request[s->used - 1] != '\r')) ||
            (s->used != 0 && s->request[s->used - 1] == '\r' && b != '\n')) {
            s->failed = 1u; return -1;
        }
        s->request[s->used++] = b;
        if (s->used >= 4 && memcmp(s->request + s->used - 4, "\r\n\r\n", 4) == 0) {
            if (i != len - 1) { s->failed = 1u; return -1; }
            s->request[s->used] = 0;
            s->ready = 1u;
            return 1;
        }
    }
    return 0;
}
static int do_response(gwir_dash_http_write_fn writer, void *ctx, int code, int head)
{
    const char *reason = "Bad Request";
    const char *ctype = "text/plain; charset=utf-8";
    const char *extra = "";
    const uint8_t *body = (const uint8_t *)"Bad Request\n";
    size_t blen = 12;
    char header[768];
    int n;
    switch (code) {
        case 200:
            reason = "OK";
            ctype = "text/html; charset=utf-8";
            extra = "Content-Encoding: gzip\r\n";
            body = gwir_dashboard_gzip_html;
            blen = gwir_dashboard_gzip_len;
            break;
        case 404:
            reason = "Not Found"; body = (const uint8_t *)"Not Found\n"; blen = 10; break;
        case 405:
            reason = "Method Not Allowed"; body = (const uint8_t *)"Method Not Allowed\n";
            blen = 19; extra = "Allow: GET, HEAD\r\n"; break;
        default: break;
    }
    n = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %lu\r\n"
        "%s"
        "Connection: close\r\nCache-Control: no-store\r\n"
        "X-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\n"
        "Referrer-Policy: no-referrer\r\n"
        "Content-Security-Policy: %s\r\n\r\n",
        code, reason, ctype, (unsigned long)blen, extra, gwir_dashboard_csp);
    if (n < 0 || (size_t)n >= sizeof(header)) return -1;
    if (write_all(writer, ctx, (const uint8_t *)header, (size_t)n)) return -1;
    if (!head && write_all(writer, ctx, body, blen)) return -1;
    return 0;
}
int gwir_dash_http_respond(const gwir_dash_http_connection *s, gwir_dash_http_write_fn writer, void *ctx)
{
    const uint8_t *p, *end, *line, *space, *path, *ver;
    size_t method_len, path_len, ver_len, line_len;
    int head = 0, code = 200, hosts = 0, is11 = 0;
    if (!s || !writer || !s->ready || s->failed) return -1;
    p = s->request; end = p + s->used;
    line = (const uint8_t *)strstr((const char *)p, "\r\n");
    if (!line) return do_response(writer, ctx, 400, 0);
    space = (const uint8_t *)memchr(p, ' ', (size_t)(line - p));
    if (!space) return do_response(writer, ctx, 400, 0);
    method_len = (size_t)(space - p);
    if (method_len == 3 && memcmp(p, "GET", 3) == 0) head = 0;
    else if (method_len == 4 && memcmp(p, "HEAD", 4) == 0) head = 1;
    else return do_response(writer, ctx, 405, 0);
    path = space + 1;
    space = (const uint8_t *)memchr(path, ' ', (size_t)(line - path));
    if (!space) return do_response(writer, ctx, 400, 0);
    path_len = (size_t)(space - path);
    ver = space + 1;
    ver_len = (size_t)(line - ver);
    if (ver_len == 8 && memcmp(ver, "HTTP/1.1", 8) == 0) is11 = 1;
    else if (ver_len != 8 || memcmp(ver, "HTTP/1.0", 8) != 0) code = 400;
    if (code == 200 && !(path_len == 1 && path[0] == '/') &&
        !(path_len == 11 && memcmp(path, "/index.html", 11) == 0)) code = 404;
    p = line + 2;
    while (p < end - 2) {
        const uint8_t *colon;
        line = (const uint8_t *)strstr((const char *)p, "\r\n");
        if (!line) { code = 400; break; }
        if (line == p) break;
        line_len = (size_t)(line - p);
        colon = (const uint8_t *)memchr(p, ':', line_len);
        if (!colon || colon == p) { code = 400; break; }
        if (eq_ci(p, (size_t)(colon - p), "Host")) {
            hosts++;
            const uint8_t *v = colon + 1;
            while (v < line && (*v == ' ' || *v == '\t')) v++;
            if (hosts != 1 || v == line) code = 400;
        } else if (eq_ci(p, (size_t)(colon - p), "Content-Length") ||
                   eq_ci(p, (size_t)(colon - p), "Transfer-Encoding") ||
                   eq_ci(p, (size_t)(colon - p), "Expect")) code = 400;
        p = line + 2;
    }
    if (is11 && hosts != 1) code = 400;
    return do_response(writer, ctx, code, head && code == 200);
}
