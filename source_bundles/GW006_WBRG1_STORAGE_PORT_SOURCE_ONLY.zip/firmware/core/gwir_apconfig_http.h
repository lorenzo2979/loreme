#ifndef GWIR_APCONFIG_HTTP_H
#define GWIR_APCONFIG_HTTP_H
#include <stddef.h>
#include <stdint.h>
#include "gwir_network_profile.h"
#include "gwir_apconfig_session.h"
/* This is a pure bounded HTTP/1.1 request validator, not a socket listener.
   The eventual transport MUST bind exclusively to the temporary AP interface. */
#define GWIR_APHTTP_HEADER_MAX 1024u
#define GWIR_APHTTP_REQUEST_MAX (GWIR_APHTTP_HEADER_MAX + GWIR_PROVISION_BODY_MAX)

typedef enum {
    GWIR_APHTTP_OK = 0,
    GWIR_APHTTP_BAD_REQUEST = -1,
    GWIR_APHTTP_FORBIDDEN = -2,
    GWIR_APHTTP_BACKEND_FAILURE = -3
} gwir_aphttp_result;

/* Accept only an entire POST /api/provision HTTP/1.1 request to the
   192.168.4.1 AP host, strict Content-Type and a single Content-Length.
   No chunking, request pipeline, upgrade, compression or allocations.
   Output is wiped on failure. Does NOT change stored Wi-Fi credentials. */
int gwir_aphttp_parse(const uint8_t *request, size_t len,
                      gwir_station_profile *out);

/* The future AP-only HTTP transport must enforce AP-local binding and pass
   interface_is_ap=1 only after verifying the accepted socket's interface.
   Requires an active button-triggered APConfig session. NEVER use on STA LAN.
   Does not send an HTTP response, start/stop Wi-Fi, or persist credentials.
   The stage/verify/commit operations are external and must be atomic. */
int gwir_aphttp_apply(const uint8_t *request, size_t len,
                      const gwir_apcfg_session *session, int interface_is_ap,
                      const gwir_station_ops *ops);
#endif
