#include "gwir_auth_stream.h"
#include <limits.h>

static void copy_bytes(uint8_t *dst, const uint8_t *src, size_t n)
{
    for (size_t i = 0u; i < n; ++i) dst[i] = src[i];
}
static int same_bytes(const uint8_t *a, const uint8_t *b, size_t n)
{
    uint8_t difference = 0u;
    for (size_t i = 0u; i < n; ++i) difference |= (uint8_t)(a[i] ^ b[i]);
    return difference == 0u;
}
static void secure_wipe(void *dst, size_t n)
{
    volatile uint8_t *p = (volatile uint8_t *)dst;
    while (n--) *p++ = 0u;
}
void gwir_auth_stream_init(gwir_auth_stream *s)
{
    if (s) secure_wipe(s, sizeof(*s));
}
void gwir_auth_stream_discard(gwir_auth_stream *s)
{
    if (s) {
        secure_wipe(s->buffer, sizeof(s->buffer));
        s->filled = s->expected = 0u;
        s->failed = 1u;
    }
}
static int fail(gwir_auth_stream *s)
{
    if (s->packets_invalid != UINT32_MAX) ++s->packets_invalid;
    gwir_auth_stream_discard(s);
    return -1;
}

int gwir_auth_stream_feed_routed(gwir_auth_stream *s, const uint8_t *data, size_t n,
                          gwir_auth_session *rx, gwir_auth_session *tx,
                          gwir_engine *engine,
                          uint8_t *scratch, size_t scratch_capacity,
                          uint8_t *signed_response, size_t response_capacity,
                          gwir_auth_stream_send_fn send, void *ctx,
                          gwir_auth_saved_handler handler, void *handler_ctx)
{
    size_t offset = 0u;
    int completed = 0;
    if (!s || s->failed) return -1;
    if ((n && !data) || !rx || !tx || !engine ||
        !scratch || !signed_response || !send || rx == tx ||
        scratch_capacity < GWIR_MAX_MESSAGE ||
        response_capacity < GWIR_AUTH_MAX_PACKET ||
        !rx->active || !tx->active || !rx->hmac || !tx->hmac)
        return fail(s);

    while (offset < n) {
        size_t target = s->expected ? s->expected : GWIR_AUTH_HEADER_BYTES;
        size_t count;
        if (s->filled > target || target > sizeof(s->buffer)) return fail(s);
        count = n - offset;
        if (count > target - s->filled) count = target - s->filled;
        if (count) {
            copy_bytes(s->buffer + s->filled, data + offset, count);
            s->filled += count;
            offset += count;
        }
        /* Minimal header gate rejects wrong magic/version/direction BEFORE
         * buffering arbitrary lengths. 0 input never progresses the parser. */
        if (s->filled >= 8u && !s->expected &&
            (!same_bytes(s->buffer, (const uint8_t *)"GWAS", 4u) ||
             s->buffer[4] != GWIR_AUTH_VERSION ||
             s->buffer[5] != GWIR_AUTH_TO_DEVICE ||
             s->buffer[6] != 0u || s->buffer[7] != 0u))
            return fail(s);
        if (s->filled < target) break;
        if (!s->expected) {
            uint32_t inner = gwir_read_u32be(s->buffer + 32u);
            if (inner < GWIR_HEADER_SIZE || inner > GWIR_MAX_MESSAGE ||
                !same_bytes(s->buffer + 8u, rx->boot_nonce, GWIR_AUTH_NONCE_BYTES))
                return fail(s);
            s->expected = GWIR_AUTH_HEADER_BYTES + (size_t)inner + GWIR_AUTH_TAG_BYTES;
            if (s->expected > sizeof(s->buffer)) return fail(s);
            continue;
        }
        if (s->filled == s->expected) {
            size_t signed_len = 0u;
            int rc = gwir_auth_dispatch_routed(rx, tx, engine, s->buffer,
                                        s->filled, scratch, scratch_capacity,
                                        signed_response, response_capacity,
                                        &signed_len, handler, handler_ctx);
            if (rc != GWIR_AUTH_OK || signed_len == 0u ||
                signed_len > response_capacity ||
                send(ctx, signed_response, signed_len) != 0) return fail(s);
            /* Do not retain signed request bytes or unrelated credentials. */
            secure_wipe(s->buffer, s->filled);
            s->filled = s->expected = 0u;
            if (s->packets_ok != UINT32_MAX) ++s->packets_ok;
            ++completed;
        }
    }
    return completed;
}

int gwir_auth_stream_feed(gwir_auth_stream *s, const uint8_t *data, size_t n,
                          gwir_auth_session *rx, gwir_auth_session *tx,
                          gwir_engine *engine,
                          uint8_t *scratch, size_t scratch_capacity,
                          uint8_t *signed_response, size_t response_capacity,
                          gwir_auth_stream_send_fn send, void *ctx)
{
    return gwir_auth_stream_feed_routed(s, data, n, rx, tx, engine,
                                        scratch, scratch_capacity,
                                        signed_response, response_capacity,
                                        send, ctx, NULL, NULL);
}
