#ifndef GWIR_NETWORK_PROFILE_H
#define GWIR_NETWORK_PROFILE_H
#include <stddef.h>
#include <stdint.h>
#include "gwir_apconfig_provision.h"

/* Station addressing, separate from the temporary APConfig interface. */
typedef enum { GWIR_IP_DHCP = 0, GWIR_IP_STATIC = 1 } gwir_ip_mode;
typedef struct {
    gwir_ip_mode mode;
    uint8_t address[4];
    uint8_t mask[4];
    uint8_t gateway[4];
    uint8_t dns1[4];
    uint8_t dns2[4];
    uint8_t dns2_present;
} gwir_ip_settings;
typedef struct {
    gwir_provision_profile wifi;
    gwir_ip_settings network;
} gwir_station_profile;

typedef struct {
    void *ctx;
    /* STAGE MUST NOT overwrite the active persistent profile. */
    int (*stage)(void *ctx, const gwir_station_profile *profile);
    /* Verify Wi-Fi and network addressing before COMMIT is allowed. */
    int (*verify)(void *ctx);
    /* Atomic nonvolatile commit (platform responsibility). */
    int (*commit)(void *ctx);
    /* Drop staged changes, restore prior working STA. */
    void (*rollback)(void *ctx);
} gwir_station_ops;

/* Reject malformed IPv4, noncontiguous masks, unusable hosts and gateway.
 * The temporary setup AP 192.168.4.0/24 must not overlap the STA static IP. */
int gwir_ipv4_parse(const char *s, uint8_t out[4]);
int gwir_ip_settings_validate(const gwir_ip_settings *ip);
/* Strict application/x-www-form-urlencoded body:
 * ssid, password, optional ip_mode=dhcp|static; for static, require
 * ip, mask, gateway, dns1 and optionally dns2. No unknown/duplicate keys.
 * No memory allocation; output zeroed on failure. */
int gwir_station_parse_form(const uint8_t *body, size_t len,
                            gwir_station_profile *out);
int gwir_station_apply(const gwir_station_profile *profile,
                       const gwir_station_ops *ops);
void gwir_station_wipe(gwir_station_profile *profile);
#endif
