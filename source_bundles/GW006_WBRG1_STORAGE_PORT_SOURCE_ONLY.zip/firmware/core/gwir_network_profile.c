#include "gwir_network_profile.h"
#include <stddef.h>
#include <stdint.h>
#include <string.h>

void gwir_station_wipe(gwir_station_profile *p)
{
    if (!p) return;
    volatile uint8_t *bytes = (volatile uint8_t *)p;
    for (size_t i = 0u; i < sizeof(*p); ++i) bytes[i] = 0u;
}

int gwir_ipv4_parse(const char *s, uint8_t out[4])
{
    uint8_t tmp[4] = {0};
    size_t pos = 0u;
    if (!s || !out) return -1;
    for (size_t octet = 0; octet < 4u; ++octet) {
        uint32_t num = 0u;
        size_t digits = 0u;
        while (s[pos] >= '0' && s[pos] <= '9') {
            if (digits++ == 3u) return -1;
            num = num * 10u + (uint32_t)(s[pos++] - '0');
            if (num > 255u) return -1;
        }
        if (!digits) return -1;
        tmp[octet] = (uint8_t)num;
        if (octet != 3u) {
            if (s[pos++] != '.') return -1;
        } else if (s[pos] != 0) return -1;
    }
    memcpy(out, tmp, 4u);
    return 0;
}

static uint32_t u32be(const uint8_t x[4])
{
    return ((uint32_t)x[0] << 24) | ((uint32_t)x[1] << 16) |
           ((uint32_t)x[2] << 8) | (uint32_t)x[3];
}
static int routable_host(const uint8_t x[4])
{
    /* Excludes any, loopback, link-local, multicast, reserved and broadcast. */
    if (x[0] == 0u || x[0] == 127u || x[0] >= 224u ||
        (x[0] == 169u && x[1] == 254u)) return 0;
    return 1;
}
int gwir_ip_settings_validate(const gwir_ip_settings *ip)
{
    uint32_t addr, mask, router, network, broadcast, inverted;
    if (!ip) return -1;
    if (ip->mode == GWIR_IP_DHCP) {
        const uint8_t zero[4] = {0};
        if (memcmp(ip->address, zero, 4) || memcmp(ip->mask, zero, 4) ||
            memcmp(ip->gateway, zero, 4) || memcmp(ip->dns1, zero, 4) ||
            memcmp(ip->dns2, zero, 4) || ip->dns2_present) return -1;
        return 0;
    }
    if (ip->mode != GWIR_IP_STATIC || ip->dns2_present > 1u) return -1;
    if (!routable_host(ip->address) || !routable_host(ip->gateway) ||
        !routable_host(ip->dns1) ||
        (ip->dns2_present && !routable_host(ip->dns2))) return -1;
    addr = u32be(ip->address);
    mask = u32be(ip->mask);
    router = u32be(ip->gateway);
    inverted = ~mask;
    /* /1 through /30 only: net/broadcast and gateway must be usable hosts. */
    if (mask == 0u || inverted < 3u || (inverted & (inverted + 1u)) != 0u) return -1;
    network = addr & mask;
    broadcast = network | inverted;
    if (addr == network || addr == broadcast ||
        router == network || router == broadcast ||
        addr == router || (router & mask) != network) return -1;
    /* 192.168.4.0/24 is reserved for temporary setup AP. */
    if (ip->address[0] == 192u && ip->address[1] == 168u && ip->address[2] == 4u) return -1;
    return 0;
}

static int key_equals(const uint8_t *raw, size_t size, const char *name)
{
    size_t n = strlen(name);
    return size == n && memcmp(raw, name, n) == 0;
}
static int copy_ipv4_text(const uint8_t *raw, size_t size, char text[16])
{
    if (size == 0u || size >= 16u) return -1;
    for (size_t i = 0u; i < size; ++i) {
        if ((raw[i] < '0' || raw[i] > '9') && raw[i] != '.') return -1;
        text[i] = (char)raw[i];
    }
    text[size] = 0;
    return 0;
}

int gwir_station_parse_form(const uint8_t *body, size_t len, gwir_station_profile *out)
{
    /* Raw ssid/password percent-escaped substrings are preserved and passed
       through the strict REV16 credential parser; no ambiguous double decode. */
    uint8_t wifi_body[GWIR_PROVISION_BODY_MAX + 1u];
    size_t wifi_len = 0u, pos = 0u;
    unsigned seen = 0u;
    uint8_t ip_mode = GWIR_IP_DHCP;
    uint8_t mode_seen = 0u;
    gwir_station_profile tmp;
    if (!out) return -1;
    gwir_station_wipe(out);
    gwir_station_wipe(&tmp);
    if (!body || len == 0u || len > GWIR_PROVISION_BODY_MAX) return -2;
    while (pos < len) {
        size_t start = pos, eq, end;
        char txt[16];
        unsigned bit = 0u;
        while (pos < len && body[pos] != '&') ++pos;
        end = pos;
        eq = start;
        while (eq < end && body[eq] != '=') ++eq;
        if (eq == start || eq == end) goto invalid;
        if (key_equals(body + start, eq - start, "ssid")) bit = 1u;
        else if (key_equals(body + start, eq - start, "password")) bit = 2u;
        else if (key_equals(body + start, eq - start, "ip_mode")) bit = 4u;
        else if (key_equals(body + start, eq - start, "ip")) bit = 8u;
        else if (key_equals(body + start, eq - start, "mask")) bit = 16u;
        else if (key_equals(body + start, eq - start, "gateway")) bit = 32u;
        else if (key_equals(body + start, eq - start, "dns1")) bit = 64u;
        else if (key_equals(body + start, eq - start, "dns2")) bit = 128u;
        else goto invalid;
        if ((seen & bit) != 0u) goto invalid;
        seen |= bit;
        if (bit == 1u || bit == 2u) {
            const size_t n = end - start;
            if (wifi_len + n + (wifi_len ? 1u : 0u) > GWIR_PROVISION_BODY_MAX) goto invalid;
            if (wifi_len) wifi_body[wifi_len++] = '&';
            memcpy(wifi_body + wifi_len, body + start, n);
            wifi_len += n;
        } else if (bit == 4u) {
            const size_t n = end - eq - 1u;
            const uint8_t *v = body + eq + 1u;
            mode_seen = 1u;
            if (n == 4u && memcmp(v, "dhcp", 4u) == 0) ip_mode = GWIR_IP_DHCP;
            else if (n == 6u && memcmp(v, "static", 6u) == 0) ip_mode = GWIR_IP_STATIC;
            else goto invalid;
        } else {
            if (copy_ipv4_text(body + eq + 1u, end - eq - 1u, txt) != 0) goto invalid;
            uint8_t *target = bit == 8u ? tmp.network.address :
                              bit == 16u ? tmp.network.mask :
                              bit == 32u ? tmp.network.gateway :
                              bit == 64u ? tmp.network.dns1 : tmp.network.dns2;
            if (gwir_ipv4_parse(txt, target) != 0) goto invalid;
            if (bit == 128u) tmp.network.dns2_present = 1u;
        }
        if (pos == len) break;
        ++pos;
        if (pos == len) goto invalid;
    }
    if ((seen & 3u) != 3u) goto invalid;
    if (gwir_provision_parse_form(wifi_body, wifi_len, &tmp.wifi) != 0) goto invalid;
    (void)mode_seen; /* omitted ip_mode intentionally defaults to DHCP */
    tmp.network.mode = (gwir_ip_mode)ip_mode;
    if (ip_mode == GWIR_IP_STATIC) {
        if ((seen & (8u | 16u | 32u | 64u)) != (8u | 16u | 32u | 64u)) goto invalid;
    } else if ((seen & (8u | 16u | 32u | 64u | 128u)) != 0u) goto invalid;
    if (gwir_ip_settings_validate(&tmp.network) != 0) goto invalid;
    *out = tmp;
    gwir_station_wipe(&tmp);
    memset(wifi_body, 0, sizeof(wifi_body));
    return 0;
invalid:
    gwir_station_wipe(&tmp);
    memset(wifi_body, 0, sizeof(wifi_body));
    return -3;
}

int gwir_station_apply(const gwir_station_profile *profile, const gwir_station_ops *ops)
{
    if (!profile || !ops || !ops->stage || !ops->verify ||
        !ops->commit || !ops->rollback) return -1;
    if (profile->wifi.ssid[0] == 0 ||
        profile->wifi.ssid[GWIR_PROVISION_SSID_MAX] != 0 ||
        profile->wifi.password[GWIR_PROVISION_PASSWORD_MAX] != 0 ||
        gwir_ip_settings_validate(&profile->network) != 0) return -2;
    if (ops->stage(ops->ctx, profile) != 0) { ops->rollback(ops->ctx); return -3; }
    if (ops->verify(ops->ctx) != 0) { ops->rollback(ops->ctx); return -4; }
    if (ops->commit(ops->ctx) != 0) { ops->rollback(ops->ctx); return -5; }
    return 0;
}
