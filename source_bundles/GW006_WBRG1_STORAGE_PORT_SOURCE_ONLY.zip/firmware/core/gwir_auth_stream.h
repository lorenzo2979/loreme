#ifndef GWIR_AUTH_STREAM_H
#define GWIR_AUTH_STREAM_H
#include "gwir_auth_dispatch.h"
#include <stdint.h>
#include <stddef.h>

/* Incremental GWAS v1 framing for authenticated IR TCP (port 42424).
 * This parser CANNOT call the IR engine directly: every complete record is
 * routed via gwir_auth_dispatch (HMAC + counter + payload CRC gate).
 * Do not use the older unauthenticated GWIR stream for a network listener.
 * One instance per *serialized* connection; allocate this and the engine,
 * scratch and response buffers statically, NOT on a small FreeRTOS stack.
 * THIS IS NOT A SOCKET LISTENER OR WIFI INITIALIZATION. */
typedef struct {
    size_t filled;
    size_t expected; /* 0 until the GWAS header is complete */
    uint32_t packets_ok;
    uint32_t packets_invalid;
    uint8_t failed;
    uint8_t buffer[GWIR_AUTH_MAX_PACKET];
} gwir_auth_stream;

typedef int (*gwir_auth_stream_send_fn)(void *ctx, const uint8_t *data, size_t n);

/* All returned data is signed by gwir_auth_dispatch. `send` must send ALL bytes
 * or return nonzero. Negative result is fatal for this session: close socket.
 * rx and tx sessions must have strongly provisioned key/boot nonce; no fallback.
 * The caller is responsible for socket deadlines, listener authentication,
 * single-worker serialization and cleanup on disconnect. */
void gwir_auth_stream_init(gwir_auth_stream *s);
int gwir_auth_stream_feed(gwir_auth_stream *s,
                          const uint8_t *data, size_t n,
                          gwir_auth_session *rx, gwir_auth_session *tx,
                          gwir_engine *engine,
                          uint8_t *scratch, size_t scratch_capacity,
                          uint8_t *signed_response, size_t response_capacity,
                          gwir_auth_stream_send_fn send, void *ctx);
/* CP29 optional signed dispatch route for saved IR commands. This does
 * NOT create a TCP listener or authorize the physical IR bus. */
int gwir_auth_stream_feed_routed(gwir_auth_stream *s,
                          const uint8_t *data, size_t n,
                          gwir_auth_session *rx, gwir_auth_session *tx,
                          gwir_engine *engine,
                          uint8_t *scratch, size_t scratch_capacity,
                          uint8_t *signed_response, size_t response_capacity,
                          gwir_auth_stream_send_fn send, void *ctx,
                          gwir_auth_saved_handler handler, void *handler_ctx);
void gwir_auth_stream_discard(gwir_auth_stream *s);
#endif
