#include "gwir_runtime_owner.h"
#include <stdint.h>
#include <string.h>

static void wipe(void *p, size_t n)
{
    volatile uint8_t *v = (volatile uint8_t *)p;
    while (n--) *v++ = 0u;
}

static int overlap(const void *a, size_t n, const void *b, size_t m)
{
    uintptr_t x = (uintptr_t)a, y = (uintptr_t)b;
    return x <= y ? y - x < n : x - y < m;
}

int gwir_runtime_owner_init(gwir_runtime_owner *o, gwir_engine *engine,
    gwir_saved_play_service *saved,
    const uint8_t key[GWIR_AUTH_KEY_BYTES],
    const uint8_t boot_nonce[GWIR_AUTH_NONCE_BYTES],
    gwir_auth_hmac_fn hmac, void *crypto_ctx,
    uint8_t *scratch, size_t scratch_cap,
    uint8_t *signed_response, size_t response_cap)
{
    if (!o || o->initialized || !engine || !key || !boot_nonce || !hmac ||
        !scratch || !signed_response ||
        scratch_cap < GWIR_MAX_MESSAGE ||
        response_cap < GWIR_AUTH_MAX_PACKET ||
        overlap(scratch, scratch_cap, signed_response, response_cap) ||
        overlap(o, sizeof(*o), scratch, scratch_cap) ||
        overlap(o, sizeof(*o), signed_response, response_cap)) return -1;
    /* Securely provisioned key and unpredictable nonce are caller obligations.
     * gwir_auth_init rejects the all-zero values and missing HMAC. */
    if (gwir_auth_init(&o->rx, key, boot_nonce, hmac, crypto_ctx)) return -1;
    if (gwir_auth_init(&o->tx, key, boot_nonce, hmac, crypto_ctx)) {
        gwir_auth_clear(&o->rx);
        return -1;
    }
    gwir_auth_stream_init(&o->stream);
    o->engine = engine;
    o->saved = saved;
    o->scratch = scratch;
    o->scratch_cap = scratch_cap;
    o->signed_response = signed_response;
    o->response_cap = response_cap;
    o->connected = 0u;
    o->initialized = 1u;
    return 0;
}

int gwir_runtime_owner_connect(gwir_runtime_owner *o)
{
    if (!o || !o->initialized || o->connected ||
        !o->rx.active || !o->tx.active) return -1;
    gwir_auth_stream_init(&o->stream);
    o->connected = 1u;
    return 0;
}

void gwir_runtime_owner_disconnect(gwir_runtime_owner *o)
{
    if (!o || !o->initialized) return;
    gwir_auth_stream_discard(&o->stream);
    o->connected = 0u;
}

int gwir_runtime_owner_feed(gwir_runtime_owner *o, const uint8_t *data, size_t n,
    gwir_auth_stream_send_fn send, void *send_ctx)
{
    int rc;
    if (!o || !o->initialized || !o->connected || !send ||
        (n && !data) || !o->engine || !o->scratch || !o->signed_response)
        return -1;
    rc = gwir_auth_stream_feed_routed(&o->stream, data, n, &o->rx, &o->tx,
        o->engine, o->scratch, o->scratch_cap,
        o->signed_response, o->response_cap, send, send_ctx,
        o->saved ? gwir_saved_play_command : NULL, o->saved);
    if (rc < 0) gwir_runtime_owner_disconnect(o);
    return rc;
}

void gwir_runtime_owner_clear(gwir_runtime_owner *o)
{
    if (!o) return;
    gwir_runtime_owner_disconnect(o);
    if (o->initialized) {
        if (o->scratch) wipe(o->scratch, o->scratch_cap);
        if (o->signed_response) wipe(o->signed_response, o->response_cap);
        gwir_auth_clear(&o->rx);
        gwir_auth_clear(&o->tx);
    }
    wipe(o, sizeof(*o));
}
