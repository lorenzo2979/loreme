#include "gwir_apconfig_http.h"
#include <stddef.h>
#include <stdint.h>

static int ascii_lower(int c)
{
    return c >= 'A' && c <= 'Z' ? c + ('a' - 'A') : c;
}
static int equal_ascii_ci(const uint8_t *buf, size_t n, const char *literal)
{
    size_t i = 0u;
    while (i < n && literal[i]) {
        if (ascii_lower(buf[i]) != ascii_lower((unsigned char)literal[i])) return 0;
        ++i;
    }
    return i == n && literal[i] == '\0';
}
static int equal_ascii(const uint8_t *buf, size_t n, const char *literal)
{
    size_t i = 0u;
    for (; i < n && literal[i]; ++i) {
        if (buf[i] != (uint8_t)literal[i]) return 0;
    }
    return i == n && literal[i] == '\0';
}
static int header_name_char(uint8_t c)
{
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
           (c >= '0' && c <= '9') || c == '-';
}
/* Locates CRLF without reading past the supplied byte span. */
static int line_end(const uint8_t *buf, size_t from, size_t limit, size_t *out)
{
    for (size_t i = from; i + 1u < limit; ++i) {
        if (buf[i] == '\r' && buf[i+1u] == '\n') { *out = i; return 0; }
        if (buf[i] < 0x20u || buf[i] > 0x7eu) return -1;
    }
    return -1;
}

int gwir_aphttp_parse(const uint8_t *request, size_t len, gwir_station_profile *out)
{
    size_t p, e, content_length = 0u, body_start;
    unsigned seen_host = 0u, seen_ct = 0u, seen_cl = 0u, header_count = 0u;
    if (!out) return GWIR_APHTTP_BAD_REQUEST;
    gwir_station_wipe(out);
    if (!request || len < 32u || len > GWIR_APHTTP_REQUEST_MAX)
        return GWIR_APHTTP_BAD_REQUEST;
    if (line_end(request, 0u, len, &e) != 0 ||
        !equal_ascii(request, e, "POST /api/provision HTTP/1.1"))
        return GWIR_APHTTP_BAD_REQUEST;
    p = e + 2u;
    for (;;) {
        size_t colon, start, end, value_start, value_end;
        if (p + 2u > len || p > GWIR_APHTTP_HEADER_MAX ||
            line_end(request, p, len, &e) != 0 || e > GWIR_APHTTP_HEADER_MAX)
            return GWIR_APHTTP_BAD_REQUEST;
        if (e == p) { p += 2u; break; }
        if (++header_count > 24u) return GWIR_APHTTP_BAD_REQUEST;
        start = p;
        end = e;
        colon = start;
        while (colon < end && request[colon] != ':') {
            if (!header_name_char(request[colon])) return GWIR_APHTTP_BAD_REQUEST;
            ++colon;
        }
        if (colon == start || colon == end) return GWIR_APHTTP_BAD_REQUEST;
        value_start = colon + 1u;
        while (value_start < end && request[value_start] == ' ') ++value_start;
        value_end = end;
        while (value_end > value_start && request[value_end-1u] == ' ') --value_end;
        if (equal_ascii_ci(request + start, colon - start, "host")) {
            if (seen_host++ || !(equal_ascii(request + value_start, value_end - value_start, "192.168.4.1") ||
                                 equal_ascii(request + value_start, value_end - value_start, "192.168.4.1:80")))
                return GWIR_APHTTP_BAD_REQUEST;
        } else if (equal_ascii_ci(request + start, colon - start, "content-type")) {
            if (seen_ct++ || !equal_ascii_ci(request + value_start, value_end - value_start,
                                            "application/x-www-form-urlencoded"))
                return GWIR_APHTTP_BAD_REQUEST;
        } else if (equal_ascii_ci(request + start, colon - start, "content-length")) {
            if (seen_cl++ || value_start == value_end) return GWIR_APHTTP_BAD_REQUEST;
            for (size_t i = value_start; i < value_end; ++i) {
                size_t digit;
                if (request[i] < '0' || request[i] > '9') return GWIR_APHTTP_BAD_REQUEST;
                digit = (size_t)(request[i] - '0');
                if (content_length > (GWIR_PROVISION_BODY_MAX - digit) / 10u)
                    return GWIR_APHTTP_BAD_REQUEST;
                content_length = content_length * 10u + digit;
            }
        } else if (equal_ascii_ci(request + start, colon - start, "transfer-encoding") ||
                   equal_ascii_ci(request + start, colon - start, "content-encoding") ||
                   equal_ascii_ci(request + start, colon - start, "expect") ||
                   equal_ascii_ci(request + start, colon - start, "upgrade") ||
                   equal_ascii_ci(request + start, colon - start, "trailer")) {
            return GWIR_APHTTP_BAD_REQUEST;
        }
        p = e + 2u;
    }
    body_start = p;
    if (!seen_host || !seen_ct || !seen_cl || !content_length ||
        body_start > GWIR_APHTTP_HEADER_MAX || len - body_start != content_length)
        return GWIR_APHTTP_BAD_REQUEST;
    if (gwir_station_parse_form(request + body_start, content_length, out) != 0) {
        gwir_station_wipe(out);
        return GWIR_APHTTP_BAD_REQUEST;
    }
    return GWIR_APHTTP_OK;
}

int gwir_aphttp_apply(const uint8_t *request, size_t len,
                      const gwir_apcfg_session *session, int interface_is_ap,
                      const gwir_station_ops *ops)
{
    gwir_station_profile tmp;
    int ok;
    if (interface_is_ap != 1 || !gwir_apcfg_session_is_active(session))
        return GWIR_APHTTP_FORBIDDEN;
    if (!ops) return GWIR_APHTTP_BACKEND_FAILURE;
    if (gwir_aphttp_parse(request, len, &tmp) != GWIR_APHTTP_OK)
        return GWIR_APHTTP_BAD_REQUEST;
    ok = gwir_station_apply(&tmp, ops);
    gwir_station_wipe(&tmp);
    return ok == 0 ? GWIR_APHTTP_OK : GWIR_APHTTP_BACKEND_FAILURE;
}
