#include "gwir_apconfig_tcp_transport.h"

/* Adapter callbacks are deliberately injected instead of guessing Realtek
 * SDK socket APIs. Zero remote data from both stack and stream on exit. */

typedef struct {
    const gwir_aptcp_ops *tcp;
    unsigned closed;
} io_ctx;

static void zero(volatile void *p, size_t n)
{
    volatile uint8_t *b = (volatile uint8_t *)p;
    while (n--) *b++ = 0u;
}
static void close_once(void *context)
{
    io_ctx *ctx = (io_ctx *)context;
    if (!ctx->closed) {
        ctx->closed = 1u;
        ctx->tcp->close_client(ctx->tcp->ctx);
    }
}
static int send_all_bounded(void *context, const uint8_t *bytes, size_t size)
{
    io_ctx *ctx = (io_ctx *)context;
    uint32_t started = ctx->tcp->now_ms(ctx->tcp->ctx);
    size_t offset = 0u;
    unsigned steps = 0u;
    while (offset < size) {
        int n;
        if ((uint32_t)(ctx->tcp->now_ms(ctx->tcp->ctx) - started) >=
                 GWIR_APTCP_WRITE_BUDGET_MS || ++steps > GWIR_APTCP_MAX_STEPS)
            return -1;
        n = ctx->tcp->send_some(ctx->tcp->ctx, bytes + offset, size - offset,
                                GWIR_APTCP_IO_WAIT_MS);
        if (n <= 0 || (size_t)n > size - offset) return -1;
        offset += (size_t)n;
    }
    return 0;
}
static int safe_ops(const gwir_aptcp_ops *s)
{
    return s && s->listener_on_ap && s->accept_one && s->client_on_ap &&
           s->recv_some && s->send_some && s->close_client && s->now_ms;
}

int gwir_aptcp_serve_one(const gwir_aptcp_ops *tcp,
                         const gwir_apcfg_session *session,
                         const gwir_station_ops *station)
{
    gwir_apstream stream;
    uint8_t buffer[GWIR_APTCP_READ_CAP];
    gwir_apstream_io io;
    io_ctx context;
    int accepted, trusted, result;
    uint32_t started;
    unsigned steps;
    if (!safe_ops(tcp) || !station)
        return GWIR_APTCP_INVALID_CALL;
    if (!gwir_apcfg_session_is_active(session) || tcp->listener_on_ap(tcp->ctx) != 1)
        return GWIR_APTCP_UNAVAILABLE;

    accepted = tcp->accept_one(tcp->ctx, GWIR_APTCP_ACCEPT_WAIT_MS);
    if (accepted == 0) return GWIR_APTCP_IDLE;
    if (accepted != 1) return GWIR_APTCP_IO_FAILURE;
    context.tcp = tcp;
    context.closed = 0u;
    io.ctx = &context;
    io.write_all = send_all_bounded;
    io.close = close_once;
    trusted = (tcp->listener_on_ap(tcp->ctx) == 1 &&
               tcp->client_on_ap(tcp->ctx) == 1);
    started = tcp->now_ms(tcp->ctx);
    if (gwir_apstream_init(&stream, started, trusted ? 1 : 0) != 0) {
        close_once(&context);
        return GWIR_APTCP_IO_FAILURE;
    }
    if (!trusted) {
        result = gwir_apstream_poll(&stream, started, session, &io);
        if (!context.closed) close_once(&context);
        return result == GWIR_APSTREAM_CLOSED ? GWIR_APTCP_REJECTED :
               GWIR_APTCP_IO_FAILURE;
    }

    for (steps = 0u; steps < GWIR_APTCP_MAX_STEPS; ++steps) {
        int count;
        uint32_t now = tcp->now_ms(tcp->ctx);
        /* Re-attest on EVERY iteration: AP may be shut down asynchronously. */
        if (tcp->listener_on_ap(tcp->ctx) != 1 ||
            tcp->client_on_ap(tcp->ctx) != 1)
            stream.trusted_ap_interface = 0u;
        result = gwir_apstream_poll(&stream, now, session, &io);
        if (result != GWIR_APSTREAM_MORE) {
            if (!context.closed) close_once(&context);
            zero(buffer, sizeof(buffer));
            return result == GWIR_APSTREAM_CLOSED ? GWIR_APTCP_REPLIED :
                   GWIR_APTCP_IO_FAILURE;
        }
        count = tcp->recv_some(tcp->ctx, buffer, sizeof(buffer),
                               GWIR_APTCP_IO_WAIT_MS);
        now = tcp->now_ms(tcp->ctx);
        if (count > 0 && (unsigned)count <= sizeof(buffer)) {
            if (tcp->listener_on_ap(tcp->ctx) != 1 ||
                tcp->client_on_ap(tcp->ctx) != 1)
                stream.trusted_ap_interface = 0u;
            result = gwir_apstream_feed(&stream, buffer, (size_t)count,
                                        now, session, station, &io);
            zero(buffer, sizeof(buffer));
            if (result != GWIR_APSTREAM_MORE) {
                if (!context.closed) close_once(&context);
                return result == GWIR_APSTREAM_CLOSED ? GWIR_APTCP_REPLIED :
                       GWIR_APTCP_IO_FAILURE;
            }
        } else if (count == -2) {
            /* Bounded read timed out: poll on next iteration. */
        } else {
            /* EOF, bad count, socket fault: never apply partial credentials. */
            close_once(&context);
            gwir_apstream_discard(&stream);
            zero(buffer, sizeof(buffer));
            return count == 0 ? GWIR_APTCP_DISCONNECTED : GWIR_APTCP_IO_FAILURE;
        }
    }
    close_once(&context);
    gwir_apstream_discard(&stream);
    zero(buffer, sizeof(buffer));
    return GWIR_APTCP_IO_FAILURE;
}
