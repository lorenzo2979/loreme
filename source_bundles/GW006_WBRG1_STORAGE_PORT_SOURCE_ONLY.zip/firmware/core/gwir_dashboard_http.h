#ifndef GWIR_DASHBOARD_HTTP_H
#define GWIR_DASHBOARD_HTTP_H
#include <stddef.h>
#include <stdint.h>
/* Read-only dashboard HTTP/1.x responder. It cannot invoke IR commands or
 * modify Wi-Fi settings. A future board server must accept ONLY on STA LAN;
 * never publish this dashboard on the open APConfig interface. */
#define GWIR_DASH_HTTP_MAX_REQUEST 1024u
typedef struct {
    uint8_t request[GWIR_DASH_HTTP_MAX_REQUEST + 1u];
    size_t used;
    uint8_t ready;
    uint8_t failed;
} gwir_dash_http_connection;
/* Returns count actually sent (may be short), <=len; -1 on transport error. */
typedef int (*gwir_dash_http_write_fn)(void *ctx, const uint8_t *data, size_t len);
void gwir_dash_http_init(gwir_dash_http_connection *s);
/* Returns 1 complete; 0 need more; -1 malformed/too large/pipelined. */
int gwir_dash_http_feed(gwir_dash_http_connection *s, const uint8_t *data, size_t len);
/* Called only when feed returns 1. Success=0, socket failure=-1.
 * All responses are Connection: close; caller MUST close after this call. */
int gwir_dash_http_respond(const gwir_dash_http_connection *s, gwir_dash_http_write_fn writer, void *ctx);
#endif
