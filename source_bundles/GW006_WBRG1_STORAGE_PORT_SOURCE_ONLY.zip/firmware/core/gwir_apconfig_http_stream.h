#ifndef GWIR_APCONFIG_HTTP_STREAM_H
#define GWIR_APCONFIG_HTTP_STREAM_H
#include <stddef.h>
#include <stdint.h>
#include "gwir_apconfig_http.h"

/* Portable single-client APConfig TCP connection framing, NOT a socket API.
 * Caller must bind to AP local IP, attest the accepted socket's real netif,
 * enforce one active client, and close/stop AP at the 5 minute APConfig limit.
 * No dynamic allocations. Handles only ONE POST, always Connection: close. */
#define GWIR_APSTREAM_IDLE_MS 2000u
#define GWIR_APSTREAM_TOTAL_MS 10000u

typedef struct {
    void *ctx;
    /* Returns 0 only if ALL bytes were sent; actual socket implementation
       MUST loop on partial writes, handle EINTR, and obey send deadline. */
    int (*write_all)(void *ctx, const uint8_t *bytes, size_t size);
    /* Must close the accepted connection (even after failed writes). */
    void (*close)(void *ctx);
} gwir_apstream_io;

typedef struct {
    uint8_t request[GWIR_APHTTP_REQUEST_MAX];
    size_t len;
    size_t header_end;
    size_t expected_total;
    uint32_t opened_ms;
    uint32_t last_rx_ms;
    unsigned trusted_ap_interface;
    unsigned terminated;
    unsigned status; /* HTTP response sent; zero until terminal */
} gwir_apstream;

typedef enum {
    GWIR_APSTREAM_MORE = 0,       /* Keep reading this one connection. */
    GWIR_APSTREAM_CLOSED = 1,     /* Response attempted; closed connection. */
    GWIR_APSTREAM_IO_FAILURE = -1,
    GWIR_APSTREAM_INVALID_CALL = -2
} gwir_apstream_result;

/* trusted_ap_interface MUST be sourced from the bound socket/netif, not HTTP
   headers or client IP; false is accepted only to allow fail-closed rejection. */
int gwir_apstream_init(gwir_apstream *s, uint32_t opened_ms,
                       int trusted_ap_interface);

/* Feed a TCP read in exact order; may split anywhere including within CRLF.
   If a chunk contains even one byte beyond the request, reject it BEFORE
   applying credentials (prevents same-read HTTP request smuggling). */
int gwir_apstream_feed(gwir_apstream *s, const uint8_t *chunk, size_t count,
                       uint32_t now_ms, const gwir_apcfg_session *session,
                       const gwir_station_ops *ops, const gwir_apstream_io *io);

/* Called periodically when no bytes arrive; idle and absolute time limits.
   Also fails closed if APConfig stops while a partial request is buffered. */
int gwir_apstream_poll(gwir_apstream *s, uint32_t now_ms,
                       const gwir_apcfg_session *session,
                       const gwir_apstream_io *io);

/* For remote hangup or teardown: zero credentials without making any writes. */
void gwir_apstream_discard(gwir_apstream *s);
#endif
