#include "gwir_sta_gate.h"
#include <string.h>

int gwir_sta_gate_ip(const gwir_sta_snapshot *s, uint32_t *out)
{
    if (!s || !out || !s->sta_only || !s->associated || !s->netif_up || !s->link_up)
        return 0;
    /* Reject wildcard, loopback, broadcast, multicast and link-local IPs.
     * Once Wi-Fi is reconfigured, require a fresh complete snapshot. */
    if (s->ipv4[0] == 0 || s->ipv4[0] == 127 || s->ipv4[0] >= 224 ||
        (s->ipv4[0] == 169 && s->ipv4[1] == 254) ||
        (s->ipv4[0] == 255 && s->ipv4[1] == 255 &&
         s->ipv4[2] == 255 && s->ipv4[3] == 255)) return 0;
    /* memcpy avoids alignment and host-endianness errors with sin_addr.s_addr */
    memcpy(out, s->ipv4, sizeof(*out));
    return 1;
}

int gwir_sta_gate_match(const gwir_sta_snapshot *s, uint32_t expected)
{
    uint32_t actual;
    return gwir_sta_gate_ip(s, &actual) && actual == expected;
}
