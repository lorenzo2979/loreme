#ifndef GWIR_GWCD_STORE_H
#define GWIR_GWCD_STORE_H
#include <stdint.h>
#include <stddef.h>
#include "gwir_protocol.h"

/* AndroidCodeStore.kt GWCD v1, big endian. A reader can be backed by RAM,
 * file or read-only flash; do NOT allocate the whole record in a task stack.
 * Validation is essential; CRC32 only detects corruption, NOT forgery.
 * No flash write, erase or IR hardware access in this component. */
#define GWIR_GWCD_BUTTONS 96u
#define GWIR_GWCD_MIN_SIZE 36u /* 16 header + 12 frame + 4 pulse + 4 CRC */
#define GWIR_GWCD_MAX_SIZE (20u + GWIR_MAX_FRAMES_PER_BUTTON * (12u + 4u * GWIR_MAX_PULSES_PER_FRAME))

typedef int (*gwir_gwcd_read_fn)(void *ctx, uint32_t offset, void *dst, size_t bytes);

typedef struct {
    uint32_t carrier_hz;
    uint16_t duty_permille;
    uint16_t pulse_count;
    uint32_t gap_after_us;
    uint32_t pulse_offset;
} gwir_gwcd_frame_index;

typedef struct {
    uint8_t button;
    uint8_t frame_count;
    uint32_t serialized_bytes;
    gwir_gwcd_frame_index frame[GWIR_MAX_FRAMES_PER_BUTTON];
} gwir_gwcd_index;

/* expected_button must be 0..95. Returns 0 success, -1 bad arguments,
 * -2 I/O failure, -3 bad CRC, -4 bad format or pulse values. */
int gwir_gwcd_scan(gwir_gwcd_read_fn read, void *ctx, uint32_t size,
                   uint8_t expected_button, gwir_gwcd_index *out);

/* Read ONE previously verified frame into caller-owned pulse buffer;
 * re-check pulse ranges while reading. Caller must serialize writes/erase
 * against scan+read; this does not recheck the full CRC on each read. */
int gwir_gwcd_read_frame(gwir_gwcd_read_fn read, void *ctx,
                         const gwir_gwcd_index *index, uint8_t frame,
                         uint32_t *pulses, size_t pulse_capacity);

/* Total payload of 96 records at protocol maximum. Does not include
 * metadata, flash sector alignment, redundancy, firmware, bootloader, OTA. */
uint32_t gwir_gwcd_worst_case_bytes(void);
#endif
