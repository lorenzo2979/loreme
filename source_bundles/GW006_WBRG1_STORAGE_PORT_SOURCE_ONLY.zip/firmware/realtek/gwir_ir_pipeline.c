#include "gwir_ir_pipeline.h"
#include <limits.h>
#include <string.h>

static int pipe_tx(void *ctx, uint32_t carrier, uint16_t duty,
                   const uint32_t *durations, uint16_t count, uint32_t gap_us)
{
    gwir_ir_pipeline *p = (gwir_ir_pipeline *)ctx;
    uint64_t total = gap_us;
    unsigned steps;
    if (!p || !p->ready || !durations || !count ||
        count > GWIR_MAX_PULSES_PER_FRAME || !p->yield_one_ms) return -1;
    for (unsigned i = 0u; i < count; ++i) {
        if (!durations[i] || durations[i] > 30000000u) return -1;
        total += durations[i];
    }
    /* Worst-case 2048 * 30ms + 30s gap fits in 120s. Add bounded slack. */
    uint64_t ms = (total + 999u) / 1000u + 2000u;
    if (ms > 120000u) return -1;
    if (gwir_amebad_bus_start_tx(&p->bus, durations, count, carrier, duty,
                                 gap_us, (uint32_t)ms)) return -1;
    /* The yield callback must advance time; bounded loop also stops broken
     * clocks from spinning forever. No concurrent RX/TX is allowed. */
    for (steps = 0; steps < 120000u; ++steps) {
        int rc = gwir_amebad_bus_poll(&p->bus);
        if (rc == GWIR_BUS_FINISHED) return 0;
        if (rc < 0 || p->yield_one_ms(p->yield_ctx) != 0) break;
    }
    (void)gwir_amebad_bus_abort(&p->bus);
    return -1;
}

static int pipe_rx_arm(void *ctx)
{
    gwir_ir_pipeline *p = (gwir_ir_pipeline *)ctx;
    if (!p || !p->ready || p->receiving ||
        p->bus.ops.board_ir_ready(p->bus.ops.ctx) != 1) return -1;
    gwir_amebad_rx_queue_init(&p->rx_queue);
    if (gwir_amebad_rx_worker_init(&p->rx_worker, &p->rx_queue, p->engine,
           p->rx_worker.lock, p->rx_worker.sample_hz,
           p->rx_worker.active_mark_level, p->rx_worker.builder.carrier_guess_hz,
           p->rx_worker.builder.duty_guess_permille,
           p->rx_worker.builder.frame_gap_threshold_us)) return -1;
    /* Software bind, NOT InterruptRegister or InterruptEn. */
    if (gwir_amebad_rx_irq_bind(&p->rx_queue,
           p->rx_worker.builder.frame_gap_threshold_us, &p->irq_stats)) return -1;
    if (gwir_amebad_bus_start_rx(&p->bus)) {
        gwir_amebad_rx_irq_unbind();
        return -1;
    }
    p->receiving = 1u;
    return 0;
}

static int pipe_rx_disarm(void *ctx)
{
    gwir_ir_pipeline *p = (gwir_ir_pipeline *)ctx;
    if (!p || !p->ready || !p->receiving) return -1;
    /* Stop hardware before software unbind. Capture remains queued until
     * Android RX_ACK; a tail without measured idle is never fabricated. */
    if (gwir_amebad_bus_stop_rx(&p->bus)) {
        (void)gwir_ir_pipeline_stop(p); /* no half-open RX after stop error */
        return -1;
    }
    int pumped = gwir_amebad_rx_worker_step(&p->rx_worker,
                                            GWIR_AMEBAD_RX_SW_DEPTH);
    gwir_amebad_rx_irq_unbind();
    p->receiving = 0u;
    return pumped < 0 ? -1 : 0;
}

int gwir_ir_pipeline_init(gwir_ir_pipeline *p, gwir_engine *engine,
                          const gwir_ir_pipeline_config *c)
{
    if (!p || !engine || !c || !c->yield_one_ms ||
        !c->irq_lock.lock_ir_irq || !c->irq_lock.unlock_ir_irq ||
        !c->bus.board_ir_ready || c->bus.board_ir_ready(c->bus.ctx) != 1)
        return -1;
    /* No peripheral configuration occurs in init. Caller must allocate
     * zeroed, non-overlapping long-lived objects and own one serialized task. */
    memset(p, 0, sizeof(*p));
    if (gwir_amebad_bus_init(&p->bus, &c->bus) != 0) return -1;
    gwir_amebad_rx_queue_init(&p->rx_queue);
    if (gwir_amebad_rx_worker_init(&p->rx_worker, &p->rx_queue, engine,
             c->irq_lock, c->sample_hz, c->active_mark_level,
             c->carrier_guess_hz, c->duty_guess_permille,
             c->gap_threshold_us) != 0) return -1;
    p->engine = engine;
    p->yield_one_ms = c->yield_one_ms;
    p->yield_ctx = c->yield_ctx;
    gwir_ir_hal hal = {pipe_tx, pipe_rx_arm, pipe_rx_disarm, p};
    gwir_engine_init(engine, hal);
    p->ready = 1u;
    return 0;
}

int gwir_ir_pipeline_pump(gwir_ir_pipeline *p, uint32_t max_events)
{
    if (!p || !p->ready || !p->receiving || !p->engine ||
        !p->engine->rx_armed) return -1;
    if (p->bus.ops.board_ir_ready(p->bus.ops.ctx) != 1) {
        (void)gwir_ir_pipeline_stop(p);
        return -1;
    }
    return gwir_amebad_rx_worker_step(&p->rx_worker, max_events);
}

int gwir_ir_pipeline_stop(gwir_ir_pipeline *p)
{
    if (!p || !p->ready) return -1;
    int rc = gwir_amebad_bus_abort(&p->bus);
    gwir_amebad_rx_irq_unbind();
    p->receiving = 0u;
    p->ready = 0u;
    /* Never leave a usable HAL on an aborted physical pipeline. */
    if (p->engine) {
        gwir_ir_hal disabled = {0};
        p->engine->hal = disabled;
        p->engine->rx_armed = 0u;
    }
    return rc ? -1 : 0;
}
