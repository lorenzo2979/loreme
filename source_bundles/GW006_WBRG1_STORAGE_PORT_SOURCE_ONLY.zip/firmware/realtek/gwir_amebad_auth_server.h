#ifndef GWIR_AMEBAD_AUTH_SERVER_H
#define GWIR_AMEBAD_AUTH_SERVER_H
#include <stdint.h>
#include "../core/gwir_runtime_owner.h"

/* Real TCP/lwIP socket transport for the CP31 authenticated owner.
 * This adapter NEVER provisions keys, creates a boot nonce or enables IR.
 * The caller MUST initialize the owner with device-specific secrets and a
 * freshly generated unpredictable per-boot nonce BEFORE calling either API.
 * No listener is created for uninitialized owners, wildcard addresses or
 * non-STA network conditions; only one accepted client is served at a time.
 * A board-specific service must arrange lifecycle, STA interface isolation,
 * credential storage and verified flash/IR hardware before enabling it.
 */
typedef int (*gwir_auth_sta_check_fn)(void *ctx, uint32_t expected_ip);
typedef struct {
    gwir_runtime_owner *owner;
    uint32_t sta_ip_network_order; /* exact IPv4 socket representation */
    uint16_t port;
    volatile int *stop;
    gwir_auth_sta_check_fn check_sta;
    void *ctx;
    /* Optional, same-owner-task IR FIFO pump; never from ISR. When installed,
       the listener uses 20ms socket timeouts to prevent raw capture overflow. */
    int (*pump_ir)(void *ctx, uint32_t max_events);
    void *ir_ctx;
} gwir_amebad_auth_server_config;

/* Runs one connection on a socket already accepted by a single owner task.
 * Always closes the authenticated session, but the socket stays caller-owned.
 * Socket recv/send timeout configuration MUST succeed; no blocking fallback. */
int gwir_amebad_auth_handle_client(int fd, const gwir_amebad_auth_server_config *cfg);

/* Binds ONLY the verified STA IP (never 0.0.0.0). This method is synchronous;
 * call from a dedicated FreeRTOS task AFTER a verified boot initialization.
 * Fails closed if owner is not initialized or STA changes. */
int gwir_amebad_auth_server_run(const gwir_amebad_auth_server_config *cfg);
#endif
