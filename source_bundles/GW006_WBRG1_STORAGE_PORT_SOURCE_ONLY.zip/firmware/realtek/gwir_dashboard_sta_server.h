#ifndef GWIR_DASHBOARD_STA_SERVER_H
#define GWIR_DASHBOARD_STA_SERVER_H
#include <stdint.h>
typedef int (*gwir_sta_check_fn)(void *, uint32_t);
typedef struct {
    uint32_t sta_ip_network_order;
    uint16_t port;
    volatile int *stop;
    gwir_sta_check_fn check_sta;
    void *ctx;
} gwir_dashboard_server_config;
int gwir_dashboard_server_run(const gwir_dashboard_server_config *cfg);
#endif
