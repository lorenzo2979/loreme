#ifndef GWIR_WBRG1_FLASH_PORT_H
#define GWIR_WBRG1_FLASH_PORT_H
#include "../core/gwir_flash_journal.h"

/* PROPOSED layout for a future standalone 8-MiB AmebaD image, NOT an
 * observation of the owner's physical flash. Offsets from flash origin.
 * Must NOT be used while OpenBeken or Tuya firmware is installed.
 * 0x000000-0x1FFFFF reserved for boot, dual applications and SDK FTL.
 * 0x200000-0x6FFFFF proposed exclusive GWIR IR journal (5 MiB).
 * 0x700000-0x7FFFFF not touched by this port (calibration/user data unknown).
 * Real device partition map, backup AND recovery must be verified before
 * GWIR_WBRG1_STORAGE_APPROVED may be enabled in an authorized target build.
 */
#define GWIR_WBRG1_FLASH_BYTES 0x00800000u
#define GWIR_WBRG1_IR_START    0x00200000u
#define GWIR_WBRG1_IR_BYTES    0x00500000u

#ifndef GWIR_WBRG1_STORAGE_APPROVED
#define GWIR_WBRG1_STORAGE_APPROVED 0
#endif

/* Fill flash IO only when a board-specific firmware build EXPLICITLY grants
 * use of this region, the 8MiB JEDEC density is confirmed and it accommodates
 * 96 maximum-size codes + one full atomic rewrite. Default returns -7.
 * Does not open the journal, write, erase, or change any pin.
 * This port itself is not a hardware-approval mechanism. */
int gwir_wbrg1_flash_port_attach(gwir_fj_io *out);

#endif
