#ifndef GWIR_AMEBAD_BOARD_PINS_H
#define GWIR_AMEBAD_BOARD_PINS_H
#include <stdint.h>

/* GW006 / WBRG1 proposed configurations. Pin policy is metadata ONLY:
 * NO pinmux/GPIO writes, no board enable, no permission to flash.
 * GWIR_UNUSED_PIN is a logical declaration; it does not electrically isolate
 * the LED on an assembled PCB. Isolate and measure PA25 before any use. */
#define GWIR_UNUSED_PIN UINT8_MAX

typedef struct {
    uint8_t ir_tx, ir_rx;
    uint8_t ap_button;
    uint8_t red_led, blue_led;
} gwir_board_pins;

/* Preferred AFTER the red-LED circuitry on PA25 is proven electrically
 * isolated: PA25 hardware IR TX, PA26 hardware IR RX. Not yet approved. */
gwir_board_pins gwir_board_pins_candidate(void);

/* Original alternative preserved for reference only: PB31 candidate TX
 * conflicts with labels in the SDK sample, awaiting physical pinmux test. */
gwir_board_pins gwir_board_pins_pb31_legacy_candidate(void);

/* Checks only permitted metadata profiles and GPIO collisions; NOT a board
 * continuity test, pinmux proof, a firmware authorization, or an electrical
 * safety assessment. */
int gwir_board_pins_validate(const gwir_board_pins *pins);

/* The physical board has not passed a verified backup/recovery + IR test.
 * This returns 0 unconditionally; firmware must stay fail-closed. */
int gwir_board_ir_enable_authorized(void);
#endif
