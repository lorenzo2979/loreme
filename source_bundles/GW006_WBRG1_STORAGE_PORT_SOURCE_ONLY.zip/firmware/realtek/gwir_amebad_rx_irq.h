#ifndef GWIR_AMEBAD_RX_IRQ_H
#define GWIR_AMEBAD_RX_IRQ_H
#include <stdint.h>
#include "gwir_amebad_rx_fifo.h"
/* Realtek IRQ bridge: no pinmux, clocks, interrupt enable or board flash.
 * Board-specific code MUST validate pins before registering entry with IR_IRQ.
 * IR FIFO is 32 words; ISR only queues events. Worker consumes outside IRQ. */
typedef struct {
    uint32_t invocations;
    uint32_t fifo_words;
    uint32_t hardware_errors;
    uint32_t fifo_drops;
    uint32_t idle_events;
} gwir_amebad_rx_irq_stats;

/* Returns number of FIFO words drained or negative on invalid/error.
 * Handles threshold/end/error IRQ flags in ONE bounded ISR service call. */
int gwir_amebad_rx_irq_service(gwir_amebad_rx_queue *queue,
                               uint32_t idle_us,
                               gwir_amebad_rx_irq_stats *stats);
/* Software binding only; never registers/enables interrupt or touches GPIO. */
int gwir_amebad_rx_irq_bind(gwir_amebad_rx_queue *queue,
                            uint32_t idle_us,
                            gwir_amebad_rx_irq_stats *stats);
void gwir_amebad_rx_irq_unbind(void);
/* Optional SDK InterruptRegister callback AFTER the board pins are validated. */
void gwir_amebad_rx_irq_entry(void);
#endif
