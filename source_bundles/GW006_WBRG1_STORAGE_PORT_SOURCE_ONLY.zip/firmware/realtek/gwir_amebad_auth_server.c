#include "gwir_amebad_auth_server.h"
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>

#if defined(GWIR_USE_LWIP)
#include <lwip/sockets.h>
#define GWIR_AUTH_CLOSE lwip_close
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <unistd.h>
#define GWIR_AUTH_CLOSE close
#endif

/* Refuse to run without per-boot, strongly provisioned owner state. */
static int allowed(const gwir_amebad_auth_server_config *c)
{
    return c && c->owner && c->owner->initialized &&
        c->owner->rx.active && c->owner->tx.active &&
        c->stop && !*c->stop && c->check_sta &&
        c->sta_ip_network_order && c->sta_ip_network_order != UINT32_MAX &&
        c->port && c->check_sta(c->ctx, c->sta_ip_network_order) == 1;
}
static int set_deadline(int fd, int which, int ms)
{
#if defined(GWIR_USE_LWIP) && defined(LWIP_SO_SNDRCVTIMEO_NONSTANDARD) && LWIP_SO_SNDRCVTIMEO_NONSTANDARD
    return setsockopt(fd, SOL_SOCKET, which, (const char *)&ms, sizeof(ms));
#else
    struct timeval tv;
    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 1000;
    return setsockopt(fd, SOL_SOCKET, which, (const char *)&tv, sizeof(tv));
#endif
}
typedef struct {
    int fd;
    const gwir_amebad_auth_server_config *cfg;
} writer_ctx;
static int send_whole_signed(void *context, const uint8_t *data, size_t len)
{
    writer_ctx *w = (writer_ctx *)context;
    size_t pos = 0u;
    if (!data || !len || len > GWIR_AUTH_MAX_PACKET) return -1;
    while (pos < len) {
        int count;
        if (!allowed(w->cfg)) return -1;
        count = (int)send(w->fd, (const char *)data + pos, len - pos, 0);
        if (count <= 0 || (size_t)count > len - pos) return -1;
        pos += (size_t)count;
    }
    return 0;
}
int gwir_amebad_auth_handle_client(int fd, const gwir_amebad_auth_server_config *cfg)
{
    writer_ctx w;
    uint8_t incoming[256];
    unsigned reads;
    int result = -1;
    if (fd < 0 || !allowed(cfg) ||
        set_deadline(fd, SO_RCVTIMEO, cfg->pump_ir ? 20 : 500) != 0 ||
        set_deadline(fd, SO_SNDTIMEO, 500) != 0) return -1;
    if (gwir_runtime_owner_connect(cfg->owner) != 0) return -1;
    w.fd = fd;
    w.cfg = cfg;
    /* Limit a client to 64 reads, even if valid packets arrive continuously.
     * This keeps a connected client from monopolizing the owner indefinitely. */
    /* With active capture, pump often enough to avoid RX FIFO loss, and
       bound idle session lifetime to 256 * 20ms. Non-IR retains legacy. */
    for (reads = 0u; reads < (cfg->pump_ir ? 256u : 64u) && allowed(cfg); ++reads) {
        if (cfg->pump_ir && cfg->owner->engine->rx_armed &&
            cfg->pump_ir(cfg->ir_ctx, 128u) < 0) break;
        int n = (int)recv(fd, (char *)incoming, sizeof(incoming), 0);
        if (n < 0 && cfg->pump_ir &&
            (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR))
            continue; /* bounded 20ms idle, keep pumping RX */
        if (n <= 0) break; /* disconnect or I/O error */
        int fed = gwir_runtime_owner_feed(cfg->owner, incoming, (size_t)n,
                                          send_whole_signed, &w);
        if (fed < 0) break;
        if (fed > 0) result = 0; /* only authenticated, answered records */
    }
    memset(incoming, 0, sizeof(incoming));
    gwir_runtime_owner_disconnect(cfg->owner);
    return result;
}
int gwir_amebad_auth_server_run(const gwir_amebad_auth_server_config *cfg)
{
    struct sockaddr_in addr;
    int listener, client, one = 1;
    if (!allowed(cfg) || cfg->owner->connected) return -1;
    listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listener < 0) return -2;
    if (set_deadline(listener, SO_RCVTIMEO, cfg->pump_ir ? 20 : 500) != 0) {
        GWIR_AUTH_CLOSE(listener);
        return -3;
    }
    (void)setsockopt(listener, SOL_SOCKET, SO_REUSEADDR,
                     (const char *)&one, sizeof(one));
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = cfg->sta_ip_network_order;
    addr.sin_port = htons(cfg->port);
    if (bind(listener, (struct sockaddr *)&addr, sizeof(addr)) != 0 ||
        listen(listener, 1) != 0) {
        GWIR_AUTH_CLOSE(listener);
        return -4;
    }
    while (allowed(cfg)) {
        if (cfg->pump_ir && cfg->owner->engine->rx_armed &&
            cfg->pump_ir(cfg->ir_ctx, 128u) < 0) break;
        client = accept(listener, NULL, NULL);
        if (client < 0) continue; /* bounded accept timeout */
        if (allowed(cfg)) (void)gwir_amebad_auth_handle_client(client, cfg);
        GWIR_AUTH_CLOSE(client);
    }
    GWIR_AUTH_CLOSE(listener);
    return 0;
}
