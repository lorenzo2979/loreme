#include "gwir_dashboard_sta_server.h"
#include "../core/gwir_dashboard_http.h"
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#if defined(GWIR_USE_LWIP)
#include <lwip/sockets.h>
#define GWIR_CLOSE lwip_close
#else
#define GWIR_CLOSE close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#endif

/* AmebaD sets LWIP_SO_SNDRCVTIMEO_NONSTANDARD=1: lwIP expects
 * timeout options as an int of MILLISECONDS, not struct timeval.
 * Native POSIX uses struct timeval. Stop listening if the timeout cannot
 * be set; silently running a blocking listener would trap the task. */
static int set_socket_timeout_ms(int fd, int option, int ms) {
#if defined(GWIR_USE_LWIP) && defined(LWIP_SO_SNDRCVTIMEO_NONSTANDARD) && LWIP_SO_SNDRCVTIMEO_NONSTANDARD
    return setsockopt(fd, SOL_SOCKET, option, (const char *)&ms, sizeof(ms));
#else
    struct timeval timeout;
    timeout.tv_sec = ms / 1000;
    timeout.tv_usec = (ms % 1000) * 1000;
    return setsockopt(fd, SOL_SOCKET, option, (const char *)&timeout, sizeof(timeout));
#endif
}

typedef struct {
    int fd;
    const gwir_dashboard_server_config *cfg;
} guarded_writer;
static int sta_valid(const gwir_dashboard_server_config *cfg) {
    return !*cfg->stop && cfg->check_sta(cfg->ctx, cfg->sta_ip_network_order);
}
static int write_socket(void *ctx, const uint8_t *buf, size_t len) {
    guarded_writer *w = (guarded_writer *)ctx;
    /* Revalidate at every short write. A transition to STA_AP must not
     * finish serving a dashboard response on an open socket. */
    if (!sta_valid(w->cfg)) return -1;
    return (int)send(w->fd, (const char *)buf, len, 0);
}
static void handle_client(int fd, const gwir_dashboard_server_config *cfg) {
    guarded_writer writer = { fd, cfg };
    gwir_dash_http_connection req;
    uint8_t buf[256];
    int n, i;
    if (set_socket_timeout_ms(fd, SO_RCVTIMEO, 2000) != 0 ||
        set_socket_timeout_ms(fd, SO_SNDTIMEO, 2000) != 0)
        return; /* Fail closed: cannot enforce bounded I/O. */
    gwir_dash_http_init(&req);
    for (i = 0; i < 6 && sta_valid(cfg); i++) {
        int status;
        n = (int)recv(fd, (char *)buf, sizeof(buf), 0);
        if (n <= 0) break;
        status = gwir_dash_http_feed(&req, buf, (size_t)n);
        if (status == 1) {
            (void)gwir_dash_http_respond(&req, write_socket, &writer);
            break;
        }
        if (status < 0) break;
    }
    memset(&req, 0, sizeof(req));
}
int gwir_dashboard_server_run(const gwir_dashboard_server_config *cfg) {
    struct sockaddr_in bind_addr;
    int server, fd, one = 1;
    if (!cfg || !cfg->stop || !cfg->check_sta || !cfg->port ||
        !cfg->sta_ip_network_order ||
        cfg->sta_ip_network_order == 0xffffffffu ||
        !cfg->check_sta(cfg->ctx, cfg->sta_ip_network_order)) return -1;
    server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (server < 0) return -2;
    (void)setsockopt(server, SOL_SOCKET, SO_REUSEADDR, (const char *)&one, sizeof(one));
    if (set_socket_timeout_ms(server, SO_RCVTIMEO, 1000) != 0) {
        GWIR_CLOSE(server);
        return -4; /* Do not accept without an enforced network timeout. */
    }
    memset(&bind_addr, 0, sizeof(bind_addr));
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = htons(cfg->port);
    bind_addr.sin_addr.s_addr = cfg->sta_ip_network_order;
    if (bind(server, (struct sockaddr *)&bind_addr, sizeof(bind_addr)) != 0 ||
        listen(server, 2) != 0) {
        GWIR_CLOSE(server);
        return -3;
    }
    while (sta_valid(cfg)) {
        fd = accept(server, NULL, NULL);
        if (fd < 0) continue;
        if (!sta_valid(cfg)) {
            GWIR_CLOSE(fd);
            break;
        }
        handle_client(fd, cfg);
        GWIR_CLOSE(fd);
    }
    GWIR_CLOSE(server);
    return 0;
}
