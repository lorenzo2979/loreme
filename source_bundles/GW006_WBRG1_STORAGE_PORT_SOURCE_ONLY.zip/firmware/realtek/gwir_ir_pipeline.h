#ifndef GWIR_IR_PIPELINE_H
#define GWIR_IR_PIPELINE_H
#include "gwir_amebad_bus.h"
#include "gwir_amebad_rx_fifo.h"
#include "gwir_amebad_rx_irq.h"

/* Task-context bridge between serialized GWIR engine and half-duplex bus.
 * NOT a board port: no GPIO, IRQ or pinmux setup; caller must separately
 * verify and install its physical IR IRQ handler and supply working IRQ locks.
 * ~20KB pipeline + ~50KB engine must be static, never task stack locals.
 */
typedef struct {
    gwir_amebad_bus_ops bus;
    gwir_amebad_rx_lock irq_lock;
    uint32_t sample_hz;
    uint32_t carrier_guess_hz;
    uint32_t gap_threshold_us;
    uint16_t duty_guess_permille;
    uint8_t active_mark_level;
    /* Called from the single owner task after each bounded poll. 0 means OK.
     * Must yield at least one millisecond of monotonic time, never from ISR. */
    int (*yield_one_ms)(void *ctx);
    void *yield_ctx;
} gwir_ir_pipeline_config;

typedef struct {
    gwir_amebad_bus bus;
    gwir_amebad_rx_queue rx_queue;
    gwir_amebad_rx_worker rx_worker;
    gwir_amebad_rx_irq_stats irq_stats;
    gwir_engine *engine;
    int (*yield_one_ms)(void *ctx);
    void *yield_ctx;
    uint8_t ready;
    uint8_t receiving;
} gwir_ir_pipeline;

/* Refuses unapproved hardware and never writes registers during init.
 * Initializes the engine HAL, bus and RX decoder; a verified board driver
 * still must actually configure pinmux and register IR IRQ separately. */
int gwir_ir_pipeline_init(gwir_ir_pipeline *p, gwir_engine *engine,
                          const gwir_ir_pipeline_config *config);
/* Drain RX events only on same serialized owner task that processes TCP
 * messages; never from IRQ. Returns number of completed captured frames. */
int gwir_ir_pipeline_pump(gwir_ir_pipeline *p, uint32_t max_events);
/* Shut down safely before releasing board authorization. */
int gwir_ir_pipeline_stop(gwir_ir_pipeline *p);
#endif
