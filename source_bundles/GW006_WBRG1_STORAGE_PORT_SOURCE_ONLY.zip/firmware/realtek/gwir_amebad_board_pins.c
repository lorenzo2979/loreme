#include "ameba_soc.h"
#include "gwir_amebad_board_pins.h"
#include <stddef.h>

/* PA25/PA26 are listed as hardware IR TX/RX in the vendor SDK examples.
 * PA25 currently shares the GW006 red LED net and MUST be isolated on the
 * physical board before this candidate can be activated. The logical red
 * LED assignment below is deliberately UNUSED, not electrically removed. */
gwir_board_pins gwir_board_pins_candidate(void)
{
    gwir_board_pins pins = {
        (uint8_t)_PA_25, (uint8_t)_PA_26,
        (uint8_t)_PB_23, GWIR_UNUSED_PIN, (uint8_t)_PB_22
    };
    return pins;
}

/* PB31 is unoccupied per owner continuity measurements, but Realtek source
 * comments disagree on its IR TX/RX direction. Not hardware-approved. */
gwir_board_pins gwir_board_pins_pb31_legacy_candidate(void)
{
    gwir_board_pins pins = {
        (uint8_t)_PB_31, (uint8_t)_PA_26,
        (uint8_t)_PB_23, (uint8_t)_PA_25, (uint8_t)_PB_22
    };
    return pins;
}

int gwir_board_pins_validate(const gwir_board_pins *p)
{
    if (!p) return -1;
    if (p->ir_rx != (uint8_t)_PA_26 ||
        p->ap_button != (uint8_t)_PB_23 ||
        p->blue_led != (uint8_t)_PB_22) return -2;
    if (p->ir_tx == (uint8_t)_PA_25) {
        /* Red LED MUST be absent from the logical profile, and physically
         * disconnected before any activation (not checked by this function). */
        if (p->red_led != GWIR_UNUSED_PIN) return -3;
    } else if (p->ir_tx == (uint8_t)_PB_31) {
        if (p->red_led != (uint8_t)_PA_25) return -4;
    } else {
        return -5;
    }
    if (p->ir_tx == p->ir_rx || p->ir_tx == p->ap_button ||
        p->ir_tx == p->blue_led ||
        p->ir_rx == p->ap_button || p->ir_rx == p->blue_led ||
        p->ap_button == p->blue_led) return -6;
    if (p->red_led != GWIR_UNUSED_PIN &&
        (p->red_led == p->ir_tx || p->red_led == p->ir_rx ||
         p->red_led == p->ap_button || p->red_led == p->blue_led)) return -7;
    return 0;
}

int gwir_board_ir_enable_authorized(void)
{
    /* Never derive authorization from metadata alone. No live pinmux until:
     * 1) full backup and proven recovery; 2) red LED PA25 isolation + GND/
     *    voltage checks; 3) native SDK firmware build; 4) controlled IR TX/RX
     *    bench measurements using verified driver with separate 5V supply.
     */
    return 0;
}
