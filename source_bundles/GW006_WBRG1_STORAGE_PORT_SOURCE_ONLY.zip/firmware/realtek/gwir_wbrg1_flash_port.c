#include "gwir_wbrg1_flash_port.h"
#include "objects.h"
#include "flash_api.h"
#include "device_lock.h"
#include <string.h>

/* AmebaD flash_api.h addresses are relative to 0x08000000. */
#define PORT_CHUNK 256u
_Static_assert(GWIR_WBRG1_IR_START >= 0x00200000u, "IR journal may overlap SDK firmware/FTL");
_Static_assert(GWIR_WBRG1_IR_START + GWIR_WBRG1_IR_BYTES <= GWIR_WBRG1_FLASH_BYTES,
               "IR partition exceeds 8 MiB");
_Static_assert(GWIR_WBRG1_IR_START % GWIR_FJ_SECTOR == 0u, "partition alignment");
_Static_assert(GWIR_WBRG1_IR_BYTES % GWIR_FJ_SECTOR == 0u, "partition size alignment");

static int in_partition(uint32_t offset, size_t length) {
    return length != 0u && offset <= GWIR_WBRG1_IR_BYTES &&
           length <= GWIR_WBRG1_IR_BYTES - offset;
}

static int port_read(void *ctx, uint32_t offset, void *dst, size_t length) {
    flash_t flash;
    (void)ctx;
    if (!dst || !in_partition(offset, length)) return -1;
    device_mutex_lock(RT_DEV_LOCK_FLASH);
    int ok = flash_stream_read(&flash, GWIR_WBRG1_IR_START + offset,
                               (uint32_t)length, (uint8_t *)dst);
    device_mutex_unlock(RT_DEV_LOCK_FLASH);
    return ok == 1 ? 0 : -1;
}

static int port_program(void *ctx, uint32_t offset, const void *src, size_t length) {
    flash_t flash;
    uint8_t before[PORT_CHUNK], check[PORT_CHUNK];
    const uint8_t *data = (const uint8_t *)src;
    int status = -1;
    (void)ctx;
    if (!data || !in_partition(offset, length)) return -1;
    device_mutex_lock(RT_DEV_LOCK_FLASH);
    /* Preflight the complete programmed span before touching NOR:
     * a write must NEVER attempt to change a programmed zero to one. */
    for (size_t i=0; i<length;) {
        uint32_t n=(uint32_t)((length-i > PORT_CHUNK) ? PORT_CHUNK : length-i);
        if (flash_stream_read(&flash,GWIR_WBRG1_IR_START+offset+(uint32_t)i,n,before)!=1)
            goto done;
        for (uint32_t j=0;j<n;j++)
            if (((uint8_t)~before[j] & data[i+j]) != 0u) goto done;
        i += n;
    }
    /* Write within 256-byte chunks, and verify each one immediately. */
    for (size_t i=0; i<length;) {
        uint32_t n=(uint32_t)((length-i > PORT_CHUNK) ? PORT_CHUNK : length-i);
        memcpy(before,data+i,n);
        if (flash_stream_write(&flash,GWIR_WBRG1_IR_START+offset+(uint32_t)i,n,before)!=1)
            goto done;
        if (flash_stream_read(&flash,GWIR_WBRG1_IR_START+offset+(uint32_t)i,n,check)!=1)
            goto done;
        if (memcmp(check,before,n)!=0) goto done;
        i += n;
    }
    status=0;
done:
    memset(before,0,sizeof(before));
    device_mutex_unlock(RT_DEV_LOCK_FLASH);
    return status;
}

static int port_erase(void *ctx, uint32_t offset) {
    flash_t flash;
    uint8_t check[PORT_CHUNK];
    int status = -1;
    (void)ctx;
    if ((offset % GWIR_FJ_SECTOR)!=0u ||
        !in_partition(offset,GWIR_FJ_SECTOR)) return -1;
    device_mutex_lock(RT_DEV_LOCK_FLASH);
    /* flash_erase_sector returns void in the pinned Realtek SDK;
     * a full readback is mandatory before reporting success. */
    flash_erase_sector(&flash,GWIR_WBRG1_IR_START+offset);
    for (uint32_t i=0;i<GWIR_FJ_SECTOR;i+=PORT_CHUNK) {
        if (flash_stream_read(&flash,GWIR_WBRG1_IR_START+offset+i,
                              PORT_CHUNK,check)!=1) goto done;
        for (uint32_t j=0;j<PORT_CHUNK;j++) if(check[j]!=0xFFu) goto done;
    }
    status=0;
done:
    device_mutex_unlock(RT_DEV_LOCK_FLASH);
    return status;
}

int gwir_wbrg1_flash_port_attach(gwir_fj_io *out) {
    flash_t flash;
    uint8_t jedec[3] = {0};
    if (!out) return -1;
    memset(out,0,sizeof(*out));
    if (GWIR_WBRG1_STORAGE_APPROVED != 1) return -7;
    if (gwir_fj_worst_case_rewrite_bytes()>GWIR_WBRG1_IR_BYTES) return -2;
    device_mutex_lock(RT_DEV_LOCK_FLASH);
    int result=flash_read_id(&flash,jedec,3u);
    device_mutex_unlock(RT_DEV_LOCK_FLASH);
    /* Third JEDEC capacity byte 0x17 means 2^23 bytes = 8MiB.
     * Unknown flash ID, geometry or manufacturer must fail closed. */
    if (result == -1 || jedec[0]==0u || jedec[0]==0xFFu || jedec[2]!=0x17u)
        return -3;
    out->ctx=NULL;
    out->read=port_read;
    out->program=port_program;
    out->erase_sector=port_erase;
    out->region_size=GWIR_WBRG1_IR_BYTES;
    return 0;
}
