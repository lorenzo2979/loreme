#include "gwir_flash_journal.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t record[GWIR_GWCD_MAX_SIZE], *chip;
static uint32_t len_record, chip_size;
static int fail_after = -1;
static uint32_t fail_read_at = UINT32_MAX;
static uint32_t writes, erases;

static int flash_read(void *ctx, uint32_t off, void *dst, size_t n) {
    (void)ctx;
    if(off>chip_size || n>chip_size-off || off>=fail_read_at) return -1;
    memcpy(dst,chip+off,n);
    return 0;
}
static int flash_program(void *ctx, uint32_t off, const void *src, size_t n) {
    const uint8_t *p=(const uint8_t*)src;
    (void)ctx;
    if(off>chip_size || n>chip_size-off) return -1;
    for(size_t i=0;i<n;i++) {
        if(fail_after==0) return -1;
        if(fail_after>0) --fail_after;
        if((chip[off+i]&p[i])!=p[i]) return -1; /* NOR cannot set 0->1 */
        chip[off+i]&=p[i];
    }
    ++writes;
    return 0;
}
static int flash_erase(void *ctx, uint32_t off) {
    (void)ctx;
    if(off%GWIR_FJ_SECTOR || off>chip_size || chip_size-off<GWIR_FJ_SECTOR) return -1;
    memset(chip+off,0xff,GWIR_FJ_SECTOR);
    ++erases;
    return 0;
}
static int source_read(void *ctx,uint32_t off, void *dst,size_t n) {
    (void)ctx;
    if(off>len_record || n>len_record-off) return -1;
    memcpy(dst,record+off,n);
    return 0;
}
static void create_record(uint32_t button,uint32_t version,uint16_t pulses,uint32_t frames) {
    uint32_t p=0;
    memcpy(record,"GWCD",4);p=4;
    gwir_write_u32be(record+p,1);p+=4;
    gwir_write_u32be(record+p,button);p+=4;
    gwir_write_u32be(record+p,frames);p+=4;
    for(uint32_t f=0;f<frames;f++) {
        gwir_write_u32be(record+p,38000u);p+=4;
        gwir_write_u16be(record+p,333u);p+=2;
        gwir_write_u16be(record+p,pulses);p+=2;
        gwir_write_u32be(record+p,40000u);p+=4;
        for(uint32_t i=0;i<pulses;i++) {
            gwir_write_u32be(record+p,560u+version+i%100);p+=4;
        }
    }
    uint32_t crc=gwir_crc32_continue(0xffffffffu,record,p)^0xffffffffu;
    gwir_write_u32be(record+p,crc);p+=4;
    len_record=p;
}
static int stored(gwir_fj_store *s,uint32_t button,uint32_t expect_len) {
    uint32_t off=0,n=0;
    int rc=gwir_fj_lookup(s,(uint8_t)button,&off,&n);
    if(expect_len==0) return rc==1;
    if(rc!=0 || n!=expect_len) return 0;
    uint8_t buf[20];
    if(flash_read(NULL,off,buf,sizeof(buf))) return 0;
    return memcmp(buf,"GWCD",4)==0 && gwir_read_u32be(buf+8)==button;
}
static gwir_fj_io io(void) {
    gwir_fj_io a={NULL,flash_read,flash_program,flash_erase,chip_size};
    return a;
}
static void reset_flash(uint32_t bytes) {
    free(chip);
    chip=malloc(bytes);
    assert(chip!=NULL);
    memset(chip,0xff,bytes);
    chip_size=bytes;
    fail_after=-1;
    fail_read_at=UINT32_MAX;
    writes=erases=0;
}
static void exhaustive_cut_test(void) {
    gwir_fj_store s,boot;
    gwir_fj_io f;
    uint8_t *baseline;
    uint32_t old_len,new_len;
    reset_flash(256u*1024u); f=io();
    assert(gwir_fj_open(&s,&f)==0);
    create_record(7,1,2,1);
    old_len=len_record;
    assert(gwir_fj_put(&s,7,source_read,NULL,len_record)==0);
    baseline=malloc(chip_size);assert(baseline);
    memcpy(baseline,chip,chip_size);
    create_record(7,2,7,1);
    new_len=len_record;
    /* Inject an abrupt loss of power after EVERY possible byte programmed:
     * the visible file after reboot must always be the old or the new full
     * valid record, never torn bytes or a corrupted index. */
    for(uint32_t cut=0;cut<=new_len+16u+8u*96u+8u;cut++) {
        memcpy(chip,baseline,chip_size);
        assert(gwir_fj_open(&s,&f)==0);
        fail_after=(int)cut;
        int result=gwir_fj_put(&s,7,source_read,NULL,new_len);
        fail_after=-1;
        assert(result==0 || result==-2);
        assert(gwir_fj_open(&boot,&f)==0);
        assert(stored(&boot,7,old_len) || stored(&boot,7,new_len));
    }
    free(baseline);
    puts("PASS CP18: byte-by-byte interruption matrix across payload, metadata CRC and final commit marker");
}

static void rewrite_manifest_crc(uint32_t bank) {
    /* Host-only adversarial mutation: simulate an internally inconsistent
     * but CRC-correct manifest. No device NOR is written by this test. */
    uint32_t base=bank*GWIR_FJ_SECTOR;
    uint32_t crc=gwir_crc32_continue(0xffffffffu,chip+base,16u+8u*GWIR_FJ_RECORDS)^0xffffffffu;
    gwir_write_u32be(chip+base+16u+8u*GWIR_FJ_RECORDS,crc);
}
static void mount_integrity_test(void) {
    gwir_fj_store s, reboot;
    reset_flash(128u*1024u);
    gwir_fj_io f=io();
    assert(gwir_fj_open(&s,&f)==0);
    create_record(2,1,6,1);
    assert(gwir_fj_put(&s,2,source_read,NULL,len_record)==0);
    uint32_t live=s.entry[2].offset;
    uint32_t prev_writes=writes,prev_erases=erases;
    /* Corrupt a committed payload: fail CLOSED during mount, no writes. */
    chip[live+26u]^=0x01u;
    assert(gwir_fj_open(&reboot,&f)==-3);
    assert(!reboot.ready && writes==prev_writes && erases==prev_erases);
    chip[live+26u]^=0x01u;
    assert(gwir_fj_open(&reboot,&f)==0);
    /* A read failure in a live record is a separate I/O error. */
    fail_read_at=GWIR_FJ_DATA_START;
    assert(gwir_fj_open(&reboot,&f)==-2 && !reboot.ready);
    fail_read_at=UINT32_MAX;
    assert(gwir_fj_open(&reboot,&f)==0);
    /* Old garbage not referenced by newest commit must not brick boot. */
    create_record(2,2,8,1);
    assert(gwir_fj_put(&reboot,2,source_read,NULL,len_record)==0);
    chip[live+26u]^=0x01u;
    assert(gwir_fj_open(&reboot,&f)==0);
    /* Mutate older bank to reference the same flash sector twice. The
     * newer bank must still boot; older bank cannot override new one. */
    uint32_t old_bank=(uint32_t)(1-reboot.active_bank);
    uint32_t base=old_bank*GWIR_FJ_SECTOR;
    memcpy(chip+base+16u+8u*1u,chip+base+16u+8u*2u,8u);
    rewrite_manifest_crc(old_bank);
    assert(gwir_fj_open(&reboot,&f)==0);
    /* A bad CURRENT manifest with a good old fallback must fail closed if
     * the old manifest would resurrect a deleted/changed record. The older
     * bank now points at corrupt data, so both mounts are rejected. */
    base=(uint32_t)reboot.active_bank*GWIR_FJ_SECTOR;
    memcpy(chip+base+16u+8u*1u,chip+base+16u+8u*2u,8u);
    rewrite_manifest_crc((uint32_t)reboot.active_bank);
    assert(gwir_fj_open(&reboot,&f)==-3 && !reboot.ready);

    reset_flash(128u*1024u);f=io();
    assert(gwir_fj_open(&s,&f)==0);
    create_record(2,1,5,1);
    assert(gwir_fj_put(&s,2,source_read,NULL,len_record)==0);
    /* Both manifests individually valid but with exactly half-range
     * generation separation: neither bank can be ordered safely. */
    memcpy(chip+GWIR_FJ_SECTOR,chip,GWIR_FJ_SECTOR);
    gwir_write_u32be(chip+GWIR_FJ_SECTOR+8u,s.generation+0x80000000u);
    rewrite_manifest_crc(1);
    assert(gwir_fj_open(&reboot,&f)==-3 && !reboot.ready);
    puts("PASS CP20: mount verifies payload CRC, read failures, overlap, stale data and generation ambiguity");
}

int main(void) {
    exhaustive_cut_test();
    mount_integrity_test();
    gwir_fj_store s,recovered;
    gwir_fj_io f;
    uint32_t oldoff=0,oldlen=0;
    assert(gwir_fj_worst_case_bytes()==4333568u);
    reset_flash(1u<<20);f=io();
    assert(gwir_fj_open(&s,&f)==0);
    assert(s.active_bank==-1);
    create_record(2,1,8,1);
    assert(gwir_fj_put(&s,2,source_read,NULL,len_record)==0);
    assert(s.generation==1 && s.active_bank==0 && stored(&s,2,len_record));
    assert(gwir_fj_lookup(&s,2,&oldoff,&oldlen)==0);
    assert(gwir_fj_open(&recovered,&f)==0 && stored(&recovered,2,oldlen));
    assert(recovered.generation==1);

    /* Power loss in the payload: previous manifest stays valid, and a retry
       must skip the dirty, uncommitted sector instead of overwriting it. */
    create_record(2,2,18,1);
    fail_after=7;
    assert(gwir_fj_put(&recovered,2,source_read,NULL,len_record)==-2);
    fail_after=-1;
    assert(gwir_fj_open(&s,&f)==0 && stored(&s,2,oldlen));
    assert(gwir_fj_put(&s,2,source_read,NULL,len_record)==0);
    assert(s.entry[2].offset>oldoff+GWIR_FJ_SECTOR);
    assert(stored(&s,2,len_record));
    uint32_t new_len=len_record;

    /* Power loss in next manifest body: old commit must remain authoritative. */
    create_record(2,3,23,1);
    fail_after=(int)len_record+93;
    assert(gwir_fj_put(&s,2,source_read,NULL,len_record)==-2);
    fail_after=-1;
    assert(gwir_fj_open(&recovered,&f)==0 && stored(&recovered,2,new_len));
    assert(recovered.generation==2);
    assert(gwir_fj_put(&recovered,2,source_read,NULL,len_record)==0);
    assert(gwir_fj_open(&s,&f)==0 && stored(&s,2,len_record));

    /* A torn 4-byte commit marker must not publish an incomplete update. */
    new_len=len_record;
    create_record(2,4,30,1);
    fail_after=(int)len_record+16+8*GWIR_FJ_RECORDS+4+2;
    assert(gwir_fj_put(&s,2,source_read,NULL,len_record)==-2);
    fail_after=-1;
    assert(gwir_fj_open(&recovered,&f)==0 && stored(&recovered,2,new_len));
    assert(gwir_fj_put(&recovered,2,source_read,NULL,len_record)==0);
    assert(stored(&recovered,2,len_record));

    /* Invalid source is rejected before touching flash. */
    create_record(3,7,8,1);
    record[31]^=1u;
    uint32_t beforewrites=writes,beforeerases=erases;
    assert(gwir_fj_put(&recovered,3,source_read,NULL,len_record)==-5);
    assert(writes==beforewrites && erases==beforeerases);

    assert(gwir_fj_delete(&recovered,2)==0);
    assert(gwir_fj_open(&s,&f)==0 && stored(&s,2,0));
    assert(gwir_fj_delete(&s,2)==0); /* idempotent */

    /* Metadata corruption on both banks cannot be mistaken for an empty chip. */
    chip[0]=0x13;chip[GWIR_FJ_SECTOR]=0x13;
    assert(gwir_fj_open(&s,&f)==-3);

    /* Reserve 96 maximum-size records: 4,333,568 bytes minimum plus
       firmware/bootloader/OTA and wear management — NOT available by assumption. */
    reset_flash(gwir_fj_worst_case_bytes());f=io();
    assert(gwir_fj_open(&s,&f)==0);
    for(uint32_t b=0;b<96;b++) {
        create_record(b,0,2048,5);
        assert(gwir_fj_put(&s,(uint8_t)b,source_read,NULL,len_record)==0);
    }
    assert(s.highwater==chip_size && s.generation==96);
    assert(gwir_fj_open(&recovered,&f)==0);
    for(uint32_t b=0;b<96;b++) assert(stored(&recovered,b,GWIR_GWCD_MAX_SIZE));
    create_record(0,1,7,1);
    assert(gwir_fj_put(&recovered,0,source_read,NULL,len_record)==-4);
    free(chip);
    puts("PASS CP18: 96 max records, dual-manifest NOR journal, reboot, torn payload/metadata/marker, CRC, no-space and delete");
    return 0;
}
