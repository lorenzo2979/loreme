#!/usr/bin/env python3
"""CP26 host-only map and ELF test fixtures; NOT a native Realtek build."""
from __future__ import annotations

import os
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from verify_native_km4_link_map import analyze_map, verify_arm_linked_elf, safe_build_artifact

NAMES = {f'gwir_test_{n:02d}' for n in range(35)}


def bad(fn, expected):
    try:
        fn()
    except ValueError as ex:
        assert expected in str(ex), (expected, str(ex))
    else:
        raise AssertionError('Expected failure: ' + expected)


def fake_map(names, *, with_loads=True, with_sections=True):
    lines = ['Discarded input sections',
             ' .text.gwir_dropped  0x0  0x100 ./build/ram/gwir_dropped.o',
             'Memory Configuration', 'Linker script and memory map', '']
    if with_loads:
        lines.extend(f'LOAD ./build/ram/{n}.o' for n in sorted(names))
    if with_sections:
        lines.extend(f' .text.{n}   0x08000000  0x10 ./build/ram/{n}.o' for n in sorted(names))
    return '\n'.join(lines) + '\n'


full = fake_map(NAMES)
assert analyze_map(full, NAMES)['modules_with_allocated_sections'] == 35
bad(lambda: analyze_map(full.replace('Linker script and memory map', 'No link section'), NAMES), 'memory-map')
bad(lambda: analyze_map(full + 'Linker script and memory map', NAMES), 'Repeated')
bad(lambda: analyze_map(fake_map(NAMES - {'gwir_test_14'}), NAMES), 'not_loaded')
bad(lambda: analyze_map(fake_map(NAMES, with_loads=False), NAMES), 'not_loaded')
bad(lambda: analyze_map(fake_map(NAMES, with_sections=False), NAMES), 'no_allocated_sections')
bad(lambda: analyze_map(full.replace(' .text.gwir_test_08   0x08000000  0x10 ',
                                    ' .text.gwir_test_08   0x08000000  0x0 '), NAMES), 'no_allocated_sections')
bad(lambda: analyze_map(full.replace('LOAD ./build/ram/gwir_test_12.o',
                                    'LOAD lib.a(gwir_test_12.o)'), NAMES), 'not_loaded')
bad(lambda: analyze_map(full.replace(' .text.gwir_test_09   0x08000000  0x10 ./build/ram/',
                                    ' .text.gwir_test_09   0x08000000  0x10 ./other/'), NAMES), 'no_allocated_sections')
bad(lambda: analyze_map('Discarded input sections\n' +
                        '\n'.join(f'.text {n} ./build/ram/{n}.o' for n in NAMES) +
                        '\nLinker script and memory map\n', NAMES), 'not_loaded')
print('PASS CP26: 35 allocated modules; missing LOAD/allocation, wrong dir, discarded-only, zero size and archive aliases rejected')

# Real host binutils map grammar regression (intentionally *not* ARM/Realtek).
if shutil.which('cc'):
    with tempfile.TemporaryDirectory(prefix='gw006_cp26_map_host_') as td:
        p = Path(td)
        names = {'gwir_real_map_a', 'gwir_real_map_b'}
        for n in names:
            (p / (n + '.c')).write_text(f'int {n}(void) {{return 7;}}\n')
            subprocess.run(['cc', '-ffunction-sections', '-c', str(p / (n + '.c')),
                            '-o', str(p / (n + '.o'))], check=True, capture_output=True)
        (p / 'main.c').write_text('int gwir_real_map_a(void); int gwir_real_map_b(void); '
                                   'int main(void) {return gwir_real_map_a()+gwir_real_map_b();}\n')
        cmd = ['cc', '-ffunction-sections', '-Wl,-Map=' + str(p / 'real.map'),
               '-Wl,--gc-sections', '-o', str(p / 'a.out'), str(p / 'main.c'),
               str(p / 'gwir_real_map_a.o'), str(p / 'gwir_real_map_b.o')]
        subprocess.run(cmd, cwd=p, check=True, capture_output=True)
        # Translate genuine GNU ld object paths to the Realtek build/ram path
        # without touching allocation fields, solely to exercise the grammar.
        text = (p / 'real.map').read_text()
        for n in names:
            text = text.replace(str(p / (n + '.o')), './build/ram/' + n + '.o')
        summary = analyze_map(text, names)
        assert summary['modules_with_allocated_sections'] == 2
        bad(lambda: analyze_map(text.replace(' .text.gwir_real_map_a',
                                             ' .comment.gwir_real_map_a'), names), 'no_allocated_sections')
    print('PASS CP26: real GNU ld host linker map allocation grammar accepted; HOST ONLY')
else:
    print('SKIP CP26 optional host GNU ld fixture: cc unavailable')

# Synthetic linked ELF32 ARM with one valid PT_LOAD. This is NOT vendor output.
elf = bytearray(84)
elf[:16] = b'\x7fELF\x01\x01\x01' + b'\x00' * 9
struct.pack_into('<HHI', elf, 16, 2, 40, 1)
struct.pack_into('<I', elf, 28, 52)
struct.pack_into('<H', elf, 40, 52)
struct.pack_into('<HH', elf, 42, 32, 1)
struct.pack_into('<I', elf, 52, 1)
verify_arm_linked_elf(bytes(elf))
corrupt = bytearray(elf)
struct.pack_into('<H', corrupt, 16, 1)
bad(lambda: verify_arm_linked_elf(bytes(corrupt)), 'not linked')
corrupt = bytearray(elf)
struct.pack_into('<H', corrupt, 18, 62)
bad(lambda: verify_arm_linked_elf(bytes(corrupt)), 'not linked')
corrupt = bytearray(elf)
struct.pack_into('<I', corrupt, 52, 0)
bad(lambda: verify_arm_linked_elf(bytes(corrupt)), 'no loadable')
bad(lambda: verify_arm_linked_elf(bytes(elf[:55])), 'program headers')
with tempfile.TemporaryDirectory() as td:
    p = Path(td) / 'a.map'
    p.write_text(full)
    ns = p.stat().st_mtime_ns
    assert safe_build_artifact(p, 100, ns).decode() == full
    os.utime(p, ns=(ns-1_000_000_000, ns-1_000_000_000))
    bad(lambda: safe_build_artifact(p, 100, ns), 'Stale')
    p.unlink()
    p.symlink_to('/etc/passwd')
    bad(lambda: safe_build_artifact(p, 100, 1), 'Missing/unsafe')
print('PASS CP26: linked ARM ELF32 basic shape, safe build artifacts, symlinks and stale maps rejected; NO FLASH')

# Integration fixture: locked source copies + Makefile + 36 synthetic ARM
# relocatable objects + synthetic final AXF/link map. Does NOT run vendor SDK.
from verify_native_km4_link_map import inspect, IMAGE_DIR
from verify_native_km4_objects import VENDOR_MAKE, VENDOR_C, OBJECT_ROOT
import json
import time


def synthetic_arm_object():
    data = bytearray(52)
    data[:16] = b'\x7fELF\x01\x01\x01' + b'\x00' * 9
    struct.pack_into('<HHIIIIIHHHHHH', data, 16,
                     1, 40, 1, 0, 0, 112, 0x05000000, 52, 0, 0, 40, 4, 0)
    data += b'\x00\xbf\x00\xbf' + b'\x00test_func\x00'
    data += b'\x00' * 16 + struct.pack('<IIIBBH', 1, 0, 4, 0x12, 0, 1)
    data += b'\x00' * (112 - len(data))
    for section in [
        (0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        (0, 1, 0x6, 0, 52, 4, 0, 0, 2, 0),
        (0, 3, 0, 0, 56, 11, 0, 0, 1, 0),
        (0, 2, 0, 0, 67, 32, 2, 0, 4, 16),
    ]:
        data += struct.pack('<IIIIIIIIII', *section)
    return bytes(data)


with tempfile.TemporaryDirectory(prefix='gw006_cp26_complete_mock_sdk_') as tmp:
    sdk = Path(tmp)
    makefile = sdk / VENDOR_MAKE
    makefile.parent.mkdir(parents=True)
    objects = sdk / OBJECT_ROOT
    objects.mkdir(parents=True, exist_ok=True)
    recs = json.loads((ROOT / 'docs/CP21_SOURCE_MANIFEST.json').read_text())['files']
    srcs = [r['path'] for r in recs if r['path'].startswith('firmware/') and r['path'].endswith('.c')]
    assert len(srcs) == 36
    lines = []
    for rel in srcs:
        _, group, name = rel.split('/')
        copied = sdk / VENDOR_C / group / name
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / rel, copied)
        lines.append('CSRC += $(GWIR_DIR)/' + group + '/' + name)
        (objects / (Path(name).stem + '.o')).write_bytes(synthetic_arm_object())
    makefile.write_text('\n'.join(lines))
    image = sdk / IMAGE_DIR
    image.mkdir(parents=True, exist_ok=True)
    (image / 'text_image2_ns.map').write_text(fake_map({Path(r).stem for r in srcs}))
    (image / 'target_img2.axf').write_bytes(elf)
    marker = sdk / 'km4_start'
    marker.write_text('start')
    past = time.time_ns() - 10_000_000_000
    os.utime(marker, ns=(past, past))
    assert inspect(sdk, marker)['modules_with_allocated_sections'] == 36
    image_map = image / 'text_image2_ns.map'
    original = image_map.read_text()
    image_map.write_text(original.replace('LOAD ./build/ram/gwir_engine.o', 'LOAD ./build/ram/bad.o'))
    bad(lambda: inspect(sdk, marker), 'not_loaded')
    image_map.write_text(original)
    (image / 'target_img2.axf').write_bytes(b'not an ARM image' + b'\x00' * 72)
    bad(lambda: inspect(sdk, marker), 'AXF')
print('PASS CP26: full mocked SDK 36-object + linked-map gate and negative cases; SYNTHETIC only')
